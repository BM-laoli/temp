import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "优惠信息发布",
    routerUrl: "/Preferential",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./Preferential")),
    children: [
      {
        needLogin: true,
        resourceName: "新增优惠信息",
        routerUrl: "/PreferentialForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./PreferentialForm")),
      },
      //$MORE$
    ],
  },
];
