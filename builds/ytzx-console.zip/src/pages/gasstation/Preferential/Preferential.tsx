import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import PreferentialFormModal from './PreferentialFormModal';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface PreferentialProps extends RouteChildrenProps {}

const Preferential: React.FC<PreferentialProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  const btns = [
    <Button onClick={() => searchFrom.submit()}>查询</Button>,
    // <Button style={{ marginLeft: '15px' }} type={'primary'} onClick={() => history.push('Preferential/PreferentialForm')}>
    //   新增
    // </Button>,
    <Button style={{ marginLeft: '15px' }} type={'primary'} onClick={() => modal.open()}>
      新增
    </Button>,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="油站名称" name="stationName">
                <Input autoComplete={'off'} placeholder="请输入油站名称关键字" allowClear />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="优惠信息列表"
          className={'full-table'}
          rowKeyIndex={'stationId'}
          api={API.resStationPromotion.resStationPromotionPage.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            let params: any = {
              where: { ...data },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
        >
          <DataColumn title="发布时间" dataIndex="addTime" />
          <DataColumn title="油站名称" dataIndex="stationName" />
          <DataColumn title="优惠信息" dataIndex="content" ellipsis />
          <DataColumn title="优惠时限" width={400} render={(item) => item.activityStartTime && item.activityEndTime && `${item.activityStartTime} 至 ${item.activityEndTime}`} />
          <DataColumn
            title="操作"
            fixed="right"
            width={220}
            render={(item) => {
              return (
                <>
                  <Button size="small" onClick={() => modal.open({ item })}>
                    编辑
                  </Button>
                  <Button size="small" onClick={() => modal.open({ item, readonly: true })}>
                    预览
                  </Button>
                  {item.id !== null && (
                    <Button size="small" onClick={() => MLModal.openDeleteModal({ id: item.id }, API.resStationPromotion.delResStationPromotionById.request, listQuery)}>
                      删除
                    </Button>
                  )}
                </>
              );
            }}
          />
        </DataTable>
      </div>
      <PreferentialFormModal modal={modal} query={listQuery} />
    </PageWrapper>
  );
};

export default Preferential;
