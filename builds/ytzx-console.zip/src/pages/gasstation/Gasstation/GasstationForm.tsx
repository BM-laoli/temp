import React, { useEffect, useState, useMemo, useRef } from 'react';
import { Modal, Form, Input, notification, Select, Card, Radio, Space, Button, Divider, Checkbox, message, Spin, Row, Col } from 'antd';
import _, { fromPairs } from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import Rules from '@/utils/rules';
import DetailWrapper from '@/components/DetailWrapper';
import { useHistory } from '@cyber-ccx/lib';
import { CloseOutlined, MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import FormUploadImage from '@/components/form-components/form-upload-image';
import FormMapAddress from '@/components/form-components/form-map-address';
import AreaSelect from '@/components/AreaSelect';
import OilSelect from '@/components/OilSelect';
import { useStore } from '@/models';
import { observer } from 'mobx-react-lite';
import useSimpleReducer from '@/utils/hooks/useSimpleReducer';
import useOnlyAsync from '@/utils/hooks/useOnlyAsync';
import QiaoOilSelect from '@/components/QiaoOilSelect';
import { mobileRegExp } from '@/utils/regex';

const { Option } = Select;
const FormItem = Form.Item;

interface GasstationFormProps extends RouteChildrenProps {}

const GasstationForm: React.FC<GasstationFormProps> = observer(({ ...props }) => {
  const { global } = useStore();
  const [form] = Form.useForm();
  const [{ loading, submit }, dispatchState] = useSimpleReducer({ loading: false, submit: false });
  const history = useHistory();
  const { id, readonly } = history.getQuery();
  const [detail, setDetail] = useState<defs.ResPetrolStationSaveParams>();
  const [oilSelect, setOilSelect] = useState<any>([])

  useEffect(() => {
    if (id) loadDetail();
  }, []);

  const loadDetail = async () => {
    dispatchState({ loading: true });
    const res: API.resPetrolStation.getResPetrolStationById.Response = await API.resPetrolStation.getResPetrolStationById.request({ id: Number(id) });
    if (res.success) {
      const detail = res.data || {};
      setDetail(detail);
      setIsWanJinYou(detail.stationSource === 2);
      form.setFieldsValue({
        ...detail,
        rebateRate: detail.rebateRate ? detail.rebateRate / 100 : null,
        stationImgList: detail.stationImgList?.map((v, i) => ({ resourceId: v.bigImgId || i.toString(), fileUrl: v.bigImgAddr })),
        areas: [detail.provinceCode, detail.cityCode, detail.regionCode],
        petrolIds: detail.station2PetrolList?.map((v) => v.petrolId),
      });
      // setOilSelect(detail.station2PetrolList)
    }
    dispatchState({ loading: false });
  };

  const handleChangeLngLat = (point: any) => {
    const pointData = { stationLng: point?.lng, stationLat: point?.lat };
    form.setFieldsValue(pointData);

    if (point?.adcode) {
      API.dictionary.findProCityRegionByRegion.request({ regionCode: point.adcode }).then((res) => {
        if (res.success) {
          form.setFieldsValue(res.data);
        }
      });
    }
  };

  const handleChangeCardType = (e) => {
    console.log(e);
    
    form.setFieldsValue({ stationSource: undefined, tradeType: 0 });
    if(e.target.value === 1) {
      form.setFieldsValue({ calWay: 2 });
    }
  };

  const handleSubmit = useOnlyAsync(async () => {
    const formData = await form.validateFields();
    dispatchState({ submit: true });
    const station2PetrolList = global.oils.filter((v) => (formData.petrolIds || []).some((o) => o === v.id)).map((v) => ({ petrolId: v.id, petrolName: v.petrolName, ...v }));
    const data = {
      ...formData,
      rebateRate: Math.round(formData.rebateRate * 10000) / 100,
      station2PetrolList,
      stationImgList: formData.stationImgList.map((v) => ({ bigImgAddr: v.fileUrl, bigImgId: v.resourceId })),
      petrolIds: (formData.petrolIds || []).join(','),
    };
    const res: API.resPetrolStation.save.Response = await API.resPetrolStation.save.request(data);
    dispatchState({ submit: false });
    if (res.success) {
      message.success('保存成功');
      history.goBack();
    }
  });

  const oilOptions = useMemo(() => global.oils.map((v) => ({ label: v.petrolName || '', value: v.id ?? '', ...v })), [global.oils]);
  const carTypeOptions = useMemo(() => global.cardTypes.map((v, i) => ({ label: v.desc || '', value: Number(v.code) ?? '', disabled: i == 2 })), [global.cardTypes]);
  // const isWanJinYou = useMemo(() => {
  //   // detail?.stationSource === 2
  //   const aaa = form.getFieldValue('stationSource')
  //   return Number(aaa) === 2
  // }, []);
  const GunList = useMemo(() => oilOptions?.map((v) => ({ ...v })), [oilOptions]);

  const [isWanJinYou, setIsWanJinYou] = useState<boolean>(false);
  const handleInput = (e) => {
    // e.persist();
    const val = e.target.value
      const value: any = (val.match(/^\d*(\.?\d{0,2})/g)[0])|| null
      console.log('ssss', value);
      form.setFieldsValue({ rebateRate: value });
  }
  const checkChange = (e, value, label) => {
    const list: any = _.cloneDeep(oilOptions);
    const Datas: any = oilSelect
    list.find((item) => {
      if (e.target.checked) {
        if (item.value === e.target.value) {
          Datas.push({...item})
        }
      } else {
        if (item.value === e.target.value) {
          Datas.splice(Datas.findIndex(tem => tem.value === e.target.value),1)
        }
      }
    });
    setOilSelect(Datas)
    console.log('选中状态',e.target, oilSelect);

  }
console.log('GunList',oilSelect.length, GunList);
  return (
    <DetailWrapper title={!id ? '新增加油站' : readonly ? '预览' : '编辑加油站'} btns={!readonly && <Button type="primary" loading={submit} onClick={handleSubmit} children="提交" />}>
      <Spin spinning={loading}>
        <Form form={form} labelCol={{ span: 3 }} wrapperCol={{ span: 21 }}>
          <FormItem name="id" hidden>
            <Input autoComplete={'off'} />
          </FormItem>
          <FormItem name="unionWay" hidden>
            <Input autoComplete={'off'} />
          </FormItem>
          <FormItem label="油站编码" name="stationCode">
            <Input autoComplete={'off'} placeholder="自动生成，不允许修改" disabled />
          </FormItem>
          <FormItem label="油站名称" name="stationName" {...Rules('required')}>
            <Input autoComplete={'off'} placeholder="请填写" disabled={!!readonly || isWanJinYou} />
          </FormItem>
          <FormItem label="油站图片" name="stationImgList" rules={[{ type: 'array', min: 1, required: true }]}>
            <FormUploadImage crop disabled={!!readonly || isWanJinYou} />
          </FormItem>
          <FormItem label="适用油卡" name="petrolCardType" {...Rules('required')}>
            <Radio.Group options={carTypeOptions} disabled={!!id } onChange={(e) => handleChangeCardType(e)} />
          </FormItem>
            
          <FormItem shouldUpdate noStyle>
            {({ getFieldValue }) => {
              const petrolCardType = getFieldValue('petrolCardType');
              const d1 = petrolCardType === 0
              return (
                <FormItem label="支付方式" name="tradeType" {...Rules('required')}>
                  <Radio.Group
                    disabled={!!id}
                    options={[
                      { label: '扫码支付', value: 0 },
                      { label: '主动支付', value: 1, disabled:  d1  },
                    ]}
                    onChange={(e) => {
                      console.log(e.target);
                      form.setFieldsValue({ calWay: 2 });
                    }}
                  />
                </FormItem>
              );
          }}
            
            {/* <Checkbox.Group disabled={!!readonly}>
              <Checkbox value={1} children="主动支付" />
              <Checkbox value={0} children="扫码支付" />
              <Checkbox value={2} children="刷卡支付" />
            </Checkbox.Group> */}
          </FormItem>
          <FormItem shouldUpdate noStyle>
            {({ getFieldValue }) => {
              const petrolCardType = getFieldValue('petrolCardType');
              const trType = getFieldValue('tradeType');
              const d1 = petrolCardType === 0;
              const tr = trType === 1
              return (
              <FormItem label="计费模式" name={'calWay'}>
                <Radio.Group
                  disabled={!!id || d1 || !tr}
                >
                  <Radio value={1} children="加油量" disabled={true}/>
                  <Radio value={0} children="加油金额" disabled={true}/>
                  <Radio value={2} children="加油量&金额" />
                </Radio.Group>
              </FormItem> );
            }}
          </FormItem>

          <FormItem label="高速油站" name={'isHighSpeed'} {...Rules('required')}>
            <Radio.Group
              disabled={!!readonly}
              options={[
                { label: '是', value: 1 },
                { label: '否', value: 0 },
              ]}
            />
          </FormItem>
          <FormItem shouldUpdate noStyle>
            {({ getFieldValue }) => {
              const lng = getFieldValue('stationLng');
              const lat = getFieldValue('stationLat');
              return (
                <FormItem label="油站地址" name="detailAddr" {...Rules('required')}>
                  <FormMapAddress placeholder="请选择" disabled={!!readonly || isWanJinYou} pointValue={{ lat, lng }} onChange={(_v, point) => handleChangeLngLat(point)} />
                </FormItem>
              );
            }}
          </FormItem>
          
          <FormItem name="stationLng" hidden>
            <Input autoComplete={'off'} />
          </FormItem>
          <FormItem name="stationLat" hidden>
            <Input autoComplete={'off'} />
          </FormItem>
          <FormItem name="provinceCode" hidden>
            <Input autoComplete={'off'} />
          </FormItem>
          <FormItem name="provinceName" hidden>
            <Input autoComplete={'off'} />
          </FormItem>
          <FormItem name="cityCode" hidden>
            <Input autoComplete={'off'} />
          </FormItem>
          <FormItem name="cityName" hidden>
            <Input autoComplete={'off'} />
          </FormItem>
          <FormItem name="regionCode" hidden>
            <Input autoComplete={'off'} />
          </FormItem>
          <FormItem name="regionName" hidden>
            <Input autoComplete={'off'} />
          </FormItem>
          <FormItem label="所属区域" shouldUpdate={(prev, next) => prev.provinceName !== next.provinceName || prev.cityName !== next.cityName || prev.regionName !== next.regionName}>
            {({ getFieldValue }) => {
              const provinceName = getFieldValue('provinceName');
              const cityName = getFieldValue('cityName');
              const regionName = getFieldValue('regionName');
              if (provinceName && cityName && regionName) return <Input autoComplete={'off'} disabled value={`${provinceName}/${cityName}/${regionName}`} placeholder="请地图选点" />;
              return <Input autoComplete={'off'} disabled placeholder="请地图选点" />;
            }}
          </FormItem>
          <FormItem shouldUpdate={(prev, next) => prev.petrolCardType !== next.petrolCardType} noStyle>
            {({ getFieldValue }) => {
              const petrolCardType = getFieldValue('petrolCardType');
              const d0 = petrolCardType === 0;
              const d1 = petrolCardType === 1;
              const d2 = petrolCardType === 2;
              const stationSource = detail?.stationSource;
              return !id ? (
                <FormItem label="油站来源" name="stationSource" {...Rules('required')}>
                  <Radio.Group disabled={!!readonly}>
                    <Radio value={0} disabled={!d0} children="自有加油撬" />
                    <Radio value={1} disabled={!d1} children="自有加盟" />
                    <Radio value={2} disabled children="万金油" />
                    <Radio value={3} disabled={!d2} children="传化" />
                    <Radio value={4} disabled={!d2} children="路歌" />
                    <Radio value={5} disabled={!d2} children="G7" />
                    <Radio value={6} disabled={!d2} children="星油" />
                    <Radio value={7} disabled={!d2} children="团油" />
                  </Radio.Group>
                </FormItem>
              ) : (
                <FormItem label="油站来源" name="stationSource" {...Rules('required')}>
                  <Radio.Group
                    onChange={(e) => {
                      setIsWanJinYou(e.target.value === 2);
                    }}
                  >
                    <Radio value={0} disabled children="自有加油撬" />
                    <Radio value={1} disabled={stationSource !== 2} children="自有加盟" />
                    <Radio value={2} disabled={stationSource !== 2} children="万金油" />
                    <Radio value={3} disabled children="传化" />
                    <Radio value={4} disabled children="路歌" />
                    <Radio value={5} disabled children="G7" />
                    <Radio value={6} disabled children="星油" />
                    <Radio value={7} disabled children="团油" />
                  </Radio.Group>
                </FormItem>
              );
            }}
          </FormItem>

          <FormItem label={<></>} colon={false} shouldUpdate={(prev, next) => prev.stationSource !== next.stationSource} noStyle>
            {({ getFieldValue }) => {
              const stationSource = Number(getFieldValue('stationSource'));
              return stationSource === 0 ? (
                <Form.Item label={<></>} colon={false}>
                  <Form.List name="stationDeviceList">
                    {(fields, { add, remove }) => (
                      <>
                        {fields.map(({ key, name, fieldKey, ...restField }, i) => (
                          <Space key={key} style={{ display: 'flex', marginBottom: 8 }} align="baseline">
                            <Form.Item {...restField} label="加油撬编号" name={[name, 'deviceCode']} {...Rules('required')}>
                              <Input autoComplete={'off'} disabled={!!readonly} placeholder="请输入加油撬编号" />
                            </Form.Item>
                            <Form.Item {...restField} label="油品" name={[name, 'petrolId']} {...Rules('required')}>
                              <QiaoOilSelect disabled={!!readonly} placeholder="请选择油品" style={{ width: 200 }} />
                            </Form.Item>
                            <Form.Item {...restField} name={[name, 'isSelfDevice']} initialValue={1} rules={[{ required: true, message: '请选择' }]}>
                              <Radio.Group disabled={!!readonly} style={{ width: 200 }}>
                                <Radio value={1}>自有</Radio>
                                <Radio value={0}>租用</Radio>
                              </Radio.Group>
                            </Form.Item>
                            {i > 0 && !readonly && <Button danger icon={<CloseOutlined />} onClick={() => remove(name)} />}
                          </Space>
                        ))}
                        {!readonly && (
                          <Form.Item noStyle>
                            <Button type="dashed" onClick={() => add()} block icon={<PlusOutlined />} children="添加加油撬" />
                          </Form.Item>
                        )}
                      </>
                    )}
                  </Form.List>
                </Form.Item>
              ) : (
                <FormItem label="油品" name="petrolIds" {...Rules('required')}>
                  <Checkbox.Group disabled={!!readonly || isWanJinYou}>
                    <Row gutter={16}>
                      {oilOptions.map((o) => (
                        <Col span={4} key={`petrol-item-${o.value}`}>
                          <Checkbox value={o.value} children={o.label} onChange={(v) => {
                            checkChange(v, o.value, o.label)
                            
                          }} />
                        </Col>
                      ))}
                    </Row>
                  </Checkbox.Group>
                </FormItem>
              );
            }}
          </FormItem>
          {!!readonly && detail?.resStation2GunList && detail?.resStation2GunList?.length > 0 && (
            <FormItem label="油枪" name="" >
              <div style={{ border: 1, borderColor: '#ddd', background:'#f5f5f5', width: 160, padding: 10 }}>
                {detail?.resStation2GunList?.map((_v, i) => {
                  return <Row key={i} style={{ flexDirection: 'row', justifyContent: 'space-between' }}><label>{_v.gunCode}</label> {_v.petrolName}</Row>
                })}
              </div>
            </FormItem>
          )}
          {!readonly ? (
              <FormItem shouldUpdate={(prev, next) => prev.tradeType !== next.tradeType} noStyle>
              {({ getFieldValue }) => {
                    const petrolCardType = getFieldValue('petrolCardType');
                    const trType = getFieldValue('tradeType');
                    const Gun = getFieldValue('petrolIds');
                    const d1 = petrolCardType === 1;
                    const tr = trType === 1

                    return  tr ? (
                      <FormItem label="增加油枪" >
                        <div style={{ border: 1, borderColor: '#ddd', background:'#f5f5f5', width: 560, padding: 10 }}>
                          <Form.List name="resStation2GunList">
                            {(fields, { add, remove }) => (
                              <>
                                {fields.map(field => (
                                  <Space key={field.key} align="baseline">
                                    <Form.Item
                                      {...field}
                                      label="油枪编号"
                                      name={[field.name, 'gunCode']}
                                    >
                                      <Input style={{ width: 80 }} suffix="号"/>
                                    </Form.Item>
                                    <Form.Item
                                      {...field}
                                      label="加油油品"
                                      name={[field.name, 'petrolId']}
                                    >
                                      <Select style={{ width: 180 }}  options={oilOptions}  onChange={(v, o: any) => {
                                        console.log(v, o);
                                        form.getFieldValue('resStation2GunList')[field.key].petrolName = o.petrolName
                                        form.getFieldValue('resStation2GunList')[field.key].petrolType = o.petrolType
                                      }}>
                                        {/* {(oilSelect)?.map(item => (
                                          <Option key={item.value} value={item.value}>
                                            {item.label}
                                          </Option>
                                        ))} */}
                                      </Select>
                                    </Form.Item>
                                    <Form.Item
                                      {...field}
                                      label="油枪编号"
                                      name={[field.name, 'petrolName']}
                                      hidden
                                    >
                                      <Input style={{ width: 80 }} suffix="号"/>
                                    </Form.Item>
                                    <Form.Item
                                      {...field}
                                      label="油枪编号"
                                      name={[field.name, 'petrolType']}
                                      hidden
                                    >
                                      <Input style={{ width: 80 }} suffix="号"/>
                                    </Form.Item>                                    
                                    <MinusCircleOutlined onClick={() => remove(field.name)} />
                                  </Space>
                                ))}
                                <Form.Item>
                                  <Button type="dashed" onClick={() => add()} block icon={<PlusOutlined />}>
                                    添加油枪
                                  </Button>
                                </Form.Item>
                              </>
                            )}
                          </Form.List>
                        </div>
                    </FormItem>
                    ): null 
                  }
                }
            </FormItem>
          ) : null}
        
          <FormItem label={<></>} colon={false} shouldUpdate={(prev, next) => prev.stationSource !== next.stationSource} noStyle>
            {({ getFieldValue }) => {
                const petrolCardType = getFieldValue('petrolCardType');
                const d0 = petrolCardType === 0;
                const d1 = petrolCardType === 1;                
                const stationSource = detail?.stationSource;
                return ( d1 ) ? (
                  <FormItem label="自有油站加油返点" name="rebateRate" {...Rules('priceTwo')} >
                    <Input autoComplete={'off'} disabled={!!readonly} style={{ width: 200 }} onChange={ e => handleInput(e)} placeholder="请填写" addonAfter="元/L" />
                  </FormItem>
                ): null 
              }
            }
          </FormItem>
          <FormItem label="油站状态" name="isEnabled" initialValue={1} {...Rules('required')}>
            <Radio.Group
              disabled={true}
              options={[
                { label: '开启', value: 1 },
                { label: '关闭', value: 0 },
              ]}
            />
          </FormItem>
          <FormItem label="是否显示" name="isShow" initialValue={1} {...Rules('required')}>
            <Radio.Group
              disabled={!!id || isWanJinYou}
              options={[
                { label: '是', value: 1 },
                { label: '否', value: 0 },
              ]}
            />
          </FormItem>
          <FormItem label="油站联系人" name="contactName" {...Rules('required')}>
            <Input autoComplete={'off'} disabled={!!readonly || isWanJinYou} placeholder="请填写" />
          </FormItem>
          <FormItem label="手机号" name="contactPhone" rules={[{ required: true }, { pattern: mobileRegExp, message: '手机号码格式错误' }]}>
            <Input autoComplete={'off'} disabled={!!readonly || isWanJinYou} placeholder="请填写" maxLength={11} />
          </FormItem>

          <Divider />

          <FormItem label="开户银行" name="openBank">
            <Input autoComplete={'off'} disabled={!!readonly || isWanJinYou} placeholder="请填写" />
          </FormItem>
          <FormItem label="开户地址" name="openAddr">
            <Input autoComplete={'off'} disabled={!!readonly || isWanJinYou} placeholder="请填写" />
          </FormItem>
          <FormItem label="银行账号" name="bankAccount">
            <Input autoComplete={'off'} disabled={!!readonly || isWanJinYou} placeholder="请填写" />
          </FormItem>
        </Form>
      </Spin>
    </DetailWrapper>
  );
});

export default GasstationForm;
