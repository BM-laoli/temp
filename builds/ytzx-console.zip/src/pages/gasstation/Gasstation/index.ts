import loadable from '@loadable/component';
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: '加油站管理',
    routerUrl: '/Gasstation',
    resourceIcon: 'TeamOutlined',
    type: '0',
    buttons: [],
    noparent: true,
    component: loadable(() => import('./Gasstation')),
    children: [
      {
        needLogin: true,
        resourceName: '新增加油站',
        routerUrl: '/GasstationForm',
        resourceIcon: '',
        type: '2',
        buttons: [],
        component: loadable(() => import('./GasstationForm')),
      },
      //$MORE$
    ],
  },
];
