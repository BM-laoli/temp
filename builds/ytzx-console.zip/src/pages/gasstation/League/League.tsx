import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import LeagueFormModal from './LeagueFormModal';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface LeagueProps extends RouteChildrenProps {}

const League: React.FC<LeagueProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  const btns = [
    <Button onClick={() => searchFrom.submit()}>查询</Button>,
    // <Button style={{ marginLeft: '15px' }} type={'primary'} onClick={() => history.push('League/LeagueForm')}>
    //   新增
    // </Button>,
    // <Button style={{ marginLeft: '15px' }} type={'primary'} onClick={() => modal.open()}>
    //   新增(弹窗)
    // </Button>,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="申请时间" name="time">
                <RangePicker style={{ width: '100%' }} allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="油站名称" name="stationName">
                <Input autoComplete={'off'} placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="联系电话" name="contactPhone">
                <Input autoComplete={'off'} placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="审核状态" name="checkStatus">
                <Select placeholder="请选择状态" allowClear style={{ width: '100%' }}>
                  <Option value={0}>待审核</Option>
                  <Option value={1}>审核通过</Option>
                  <Option value={2}>审核不通过</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="加盟信息列表"
          className={'full-table'}
          rowKeyIndex={'id'}
          api={API.resPetrolStation.auditPageList.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const [startTimeStr, endTimeStr] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
            let params: any = {
              where: { startTimeStr, endTimeStr, ...data },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
        >
          <DataColumn title="申请时间" dataIndex="addTime" />
          <DataColumn title="油站名称" dataIndex="stationName" />
          <DataColumn title="所属区域" dataIndex="merName" />
          <DataColumn title="油品" dataIndex="petrolNames" />
          <DataColumn title="油站联系人" dataIndex="contactName" />
          <DataColumn title="联系电话" dataIndex="contactPhone" />
          <DataColumn title="审核状态" dataIndex="checkStatusStr" />
          <DataColumn
            title="操作"
            fixed="right"
            width={220}
            render={(item) => {
              return (
                <>
                  <Button size="small" onClick={() => history.push(`League/LeagueForm?id=${item.id}`)}>
                    注册信息
                  </Button>
                  {item.checkStatus === 0 && (
                    <Button size="small" onClick={() => history.push(`League/LeagueForm?id=${item.id}&check=1`)}>
                      审核
                    </Button>
                  )}
                </>
              );
            }}
          />
        </DataTable>
      </div>
      <LeagueFormModal modal={modal} />
    </PageWrapper>
  );
};

export default League;
