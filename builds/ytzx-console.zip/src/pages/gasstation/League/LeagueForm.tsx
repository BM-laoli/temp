import React, { useEffect, useState, useMemo } from 'react';
import { Modal, Form, Input, notification, Select, Card, Descriptions, Image, Space, Divider, Radio, Button, Spin, message } from 'antd';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import Rules from '@/utils/rules';
import DetailWrapper from '@/components/DetailWrapper';
import { useHistory } from '@cyber-ccx/lib';
import mockjs from 'mockjs';
import useSimpleReducer from '@/utils/hooks/useSimpleReducer';
import { useStore } from '@/models';
import { observer } from 'mobx-react-lite';
import useOnlyAsync from '@/utils/hooks/useOnlyAsync';

const FormItem = Form.Item;

interface LeagueFormProps extends RouteChildrenProps {}

const LeagueForm: React.FC<LeagueFormProps> = observer(({ ...props }) => {
  const { global } = useStore();
  const [form] = Form.useForm();
  const [{ loading, submit }, dispatchState] = useSimpleReducer({ loading: false, submit: false });
  const history = useHistory();
  const { id, check } = history.getQuery();
  const [detail, setDetail] = useState<defs.ResPetrolStationSaveParams>();

  useEffect(() => {
    loadDetail();
  }, []);

  const loadDetail = async () => {
    dispatchState({ loading: true });
    const res: API.resPetrolStation.getResPetrolStationById.Response = await API.resPetrolStation.getResPetrolStationById.request({ id: Number(id) });
    if (res.success) {
      setDetail(res.data);
    }
    dispatchState({ loading: false });
  };

  const handleSubmit = useOnlyAsync(async () => {
    const formData = await form.validateFields();
    const data = {
      id,
      ...formData,
      checkId: global.userInfo?.id,
      checkName: global.userInfo?.userName,
    };
    dispatchState({ submit: true });
    const res: API.resPetrolStation.resPetrolStationAudit.Response = await API.resPetrolStation.resPetrolStationAudit.request(data);
    dispatchState({ submit: false });
    if (res.success) {
      message.success('审核提交成功');
      history.goBack();
    }
  });

  // const oils = useMemo(() => {
  //   const list = detail?.stationSource === 0 ? detail?.stationDeviceList || [] : detail?.station2PetrolList || [];
  //   return list.map((v) => ({ petrolId: v.petrolId, petrolName: v.petrolName }));
  // }, [detail]);

  return (
    <DetailWrapper title={!!check ? '加盟审核' : '注册信息'}>
      <Spin spinning={loading}>
        <Descriptions column={2} labelStyle={{ width: '10em' }} bordered>
          <Descriptions.Item label="油站名称">{detail?.stationName}</Descriptions.Item>
          <Descriptions.Item label="油站状态">{detail?.isEnabled ? '启用' : '停用'}</Descriptions.Item>
          <Descriptions.Item label="油站联系人">{detail?.contactName}</Descriptions.Item>
          <Descriptions.Item label="联系电话">{detail?.contactPhone}</Descriptions.Item>
          <Descriptions.Item label="油站地址">{detail?.detailAddr}</Descriptions.Item>
          <Descriptions.Item label="所属区域">{detail?.merName}</Descriptions.Item>
          <Descriptions.Item label="开户银行">{detail?.openBank}</Descriptions.Item>
          <Descriptions.Item label="开户地址">{detail?.openAddr}</Descriptions.Item>
          <Descriptions.Item label="银行账号">{detail?.bankAccount}</Descriptions.Item>
          <Descriptions.Item label="油品">{detail?.petrolNames}</Descriptions.Item>
          <Descriptions.Item label="油站图片">
            {detail?.stationImgList && detail.stationImgList.length > 0 && (
              <Image.PreviewGroup>
                <Space>
                  {detail?.stationImgList.map((v, i) => (
                    <Image width={100} height={100} src={v.bigImgAddr} key={`images-${v.bigImgId}-${i}`} />
                  ))}
                </Space>
              </Image.PreviewGroup>
            )}
          </Descriptions.Item>
        </Descriptions>

        {!!check && (
          <>
            <Divider />
            <Form form={form} labelCol={{ span: 3 }} wrapperCol={{ span: 6 }}>
              <FormItem label="审核意见" name="checkStatus" {...Rules('required')}>
                <Radio.Group>
                  <Radio value={1}>审核通过</Radio>
                  <Radio value={2}>审核不通过</Radio>
                </Radio.Group>
              </FormItem>
              <FormItem label={<></>} colon={false}>
                <Button type="primary" loading={submit} onClick={handleSubmit}>
                  提交
                </Button>
              </FormItem>
            </Form>
          </>
        )}
      </Spin>
    </DetailWrapper>
  );
});

export default LeagueForm;
