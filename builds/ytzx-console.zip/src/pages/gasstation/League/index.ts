import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "油站加盟管理",
    routerUrl: "/League",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./League")),
    children: [
      {
        needLogin: true,
        resourceName: "注册信息",
        routerUrl: "/LeagueForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./LeagueForm")),
      },
      //$MORE$
    ],
  },
];
