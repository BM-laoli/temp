import React, { useEffect, useState } from 'react';
import { Descriptions, Typography, Table, TablePaginationConfig } from 'antd';
import _ from 'lodash';
import { RouteChildrenProps, useLocation } from 'react-router-dom';
import DetailWrapper from '@/components/DetailWrapper';
import { yuan } from '@/utils';
import useSimpleReducer from '@/utils/hooks/useSimpleReducer';
import { Random } from 'mockjs';

interface CommissionFormProps extends RouteChildrenProps {}

const CommissionForm: React.FC<CommissionFormProps> = () => {
  const [loading, setLoading] = useState(false);
  const location = useLocation<any>();

  const [{ curPage, pageSize, count }, dispatchPage] = useSimpleReducer({ curPage: 1, pageSize: 10, count: 0 });
  const [dataSource, setDataSource] = useState<defs.ExtractTheCommissionRecord[]>([]);

  useEffect(() => {
    loadPage(1, pageSize);
  }, []);

  const loadPage = async (curPage: number, size?: number) => {
    const s = size ?? pageSize;
    dispatchPage({ curPage, pageSize: s });
    setLoading(true);
    const res = await API.commissionManage.findCashOutPageList.request({ curPage, pageSize: s, where: { referee: location.state.userId } });
    if (res.success) {
      dispatchPage({ count: res.count });
      setDataSource(res.data || []);
    }
    setLoading(false);
  };

  const pagination: TablePaginationConfig = {
    current: curPage,
    pageSize: pageSize,
    total: count,
    showTotal: (t) => `共 ${t} 条`,
    onChange: loadPage,
    showSizeChanger: true,
  };

  return (
    <DetailWrapper title="提现明细">
      <Descriptions column={2} bordered labelStyle={{ width: '10em' }}>
        <Descriptions.Item label="加油员">
          <Typography.Text strong>{location.state?.userName}</Typography.Text>
        </Descriptions.Item>
        <Descriptions.Item label="油站名称">{location.state?.stationName}</Descriptions.Item>
        <Descriptions.Item label="佣金总额">{yuan(location.state?.totalCommissionMoney)}元</Descriptions.Item>
        <Descriptions.Item label="已提现金额">{yuan(location.state?.totalCashOut)}元</Descriptions.Item>
      </Descriptions>

      <Table dataSource={dataSource} rowKey={() => Random.guid()} loading={loading} pagination={pagination} tableLayout="fixed" size="small" style={{ marginTop: 20 }} bordered>
        <Table.Column title="提现时间" dataIndex="addTime" />
        <Table.Column title="提现金额（元）" dataIndex="cashOutCommision" render={(item) => yuan(item)} />
        <Table.Column title="操作人" dataIndex="operatorName" />
      </Table>
    </DetailWrapper>
  );
};

export default CommissionForm;
