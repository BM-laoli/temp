import React, { useState, useEffect, useRef, useMemo } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import CompanyBillFormModal from './CompanyBillFormModal';
import { useStore } from '@/models';
import CompanySelect from '@/components/CompanySelect';
import CardTypeSelect from '@/components/CardTypeSelect';
import { yuan } from '@/utils';
import { Random } from 'mockjs';
import ExportButton from '@/components/ExportButton';
import moment from 'moment';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface CompanyBillProps extends RouteChildrenProps {}

const CompanyBill: React.FC<CompanyBillProps> = observer((props) => {
  const { global } = useStore();
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  const btns = [
    <Button key={1} onClick={() => searchFrom.submit()}>查询</Button>,
    <ExportButton
      style={{ marginLeft: '15px' }}
      key={2}
      type={'primary'}
      query={listQuery}
      formFormat={(data) => {
        const where: any = {};
        if (data.time) {
          where.year = data.time.year();
          where.month = data.time?.month() + 1;
        } else {
          data.time = moment(new Date().toLocaleDateString(), 'YYYY-MM')
          where.year = data.time.year();
          where.month = data.time?.month() + 1;
        }
        const params: any = { ...where, companyId: data.companyId, cardType: data.cardType };
        return params;
      }}
      url="/fuel/fee/exportCompanyReconciliation"
      title="公司加油对账"
      children="导出"
    />,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="对账月份" name="time">
                <DatePicker picker="month" placeholder="请选择" defaultValue={moment(new Date().toLocaleDateString(), 'YYYY-MM')} allowClear style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="公司名称" name="companyId">
                <CompanySelect placeholder="请选择" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="适用油卡" name="cardType">
                <CardTypeSelect placeholder="请选择适用油卡" allowClear />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="数据列表"
          className={'full-table'}
          rowKeyIndex={'resourceId'}
          rowKey={() => Random.guid()}
          api={API.fuelFee.companyReconciliationPageList.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const where: any = {};
            if (data.time) {
              where.year = data.time.year();
              where.month = data.time?.month() + 1;
            } else {
              data.time = moment(new Date().toLocaleDateString(), 'YYYY-MM')
              where.year = data.time.year();
              where.month = data.time?.month() + 1;
            }
            const params: any = {
              where: { ...where, companyId: data.companyId, cardType: data.cardType },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
        >
          <DataColumn title="对账月份" dataIndex="dateTime" />
          <DataColumn title="公司名称" dataIndex="companyName" />
          <DataColumn title="适用油卡" dataIndex="cardTypeName" />
          <DataColumn title="加油型号" dataIndex="petrolNames" />
          <DataColumn title="加油金额/抵扣运费（元）" dataIndex="actTotalPrice" render={(item) => yuan(item)} />
          <DataColumn title="退款金额" dataIndex="refundTotalPrice" render={(item) => item ? yuan(item) : '-' } />
          <DataColumn title="对账金额" dataIndex="billMoney" render={(item) => yuan(item)} />
          <DataColumn
            title="操作"
            fixed="right"
            width={220}
            render={(item) => (
              <>
                <Button size="small" onClick={() => history.push(`CompanyBill/CompanyBillForm`, { ...item })}>
                  对账单
                </Button>
              </>
            )}
          />
        </DataTable>
      </div>
      <CompanyBillFormModal modal={modal} />
    </PageWrapper>
  );
});

export default CompanyBill;
