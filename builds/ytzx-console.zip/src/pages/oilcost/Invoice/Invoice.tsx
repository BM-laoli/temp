import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import InvoiceFormModal from './InvoiceFormModal';
import { yuan } from '@/utils';
import ExportButton from '@/components/ExportButton';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface InvoiceProps extends RouteChildrenProps {}

const Invoice: React.FC<InvoiceProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  const btns = [
    <Button onClick={() => searchFrom.submit()}>查询</Button>,
    <ExportButton
      style={{ marginLeft: '15px' }}
      type={'primary'}
      query={listQuery}
      formFormat={(data) => {
        const [applyStartTime, applyEndTime] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
        const params: any = { isDeal: data.isDeal, title: data.title, applyStartTime, applyEndTime };
        return params;
      }}
      url="/invoice/exportOpenInvoiceList"
      title="开票管理"
      children="导出"
    />,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="申请日期" name="time">
                <RangePicker allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="开票状态" name="isDeal">
                <Select placeholder={'全部'} allowClear>
                  <Option value={0}>未开票</Option>
                  <Option value={1}>已开票</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="开票抬头" name="title">
                <Input placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
           
          className={'full-table'}
          rowKeyIndex={'id'}
          api={API.cardOpenInvoice.pageList.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const [applyStartTime, applyEndTime] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
            const params: any = {
              where: { isDeal: data.isDeal, title: data.title, applyStartTime, applyEndTime },
              curPage: data.page,
              pageSize: data.rows,
            };

            return params;
          }}
        >
          <DataColumn title="申请时间" dataIndex="applyTime" />
          <DataColumn title="申请人" dataIndex="applicantName" />
          <DataColumn title="申请金额（元）" dataIndex="totalMoney" render={(t) => yuan(t)} />
          <DataColumn title="开票抬头" dataIndex="title" />
          <DataColumn title="开票状态" dataIndex="isDealDesc" />
          <DataColumn
            title="操作"
            fixed="right"
            width="220px"
            render={(item) => {
              return (
                <>
                  <Button size="small" onClick={() => modal.open({ item })}>
                    开票详情
                  </Button>
                  <Button size="small" onClick={() => history.push('Invoice/InvoiceForm', { item })}>
                    开票明细
                  </Button>
                </>
              );
            }}
          />
        </DataTable>
      </div>
      <InvoiceFormModal modal={modal} query={listQuery} />
    </PageWrapper>
  );
};

export default Invoice;
