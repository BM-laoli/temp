import React, { useEffect, useState, useMemo } from 'react';
import { Modal, Form, Input, notification, Select, Descriptions, Spin, Space, Button, message } from 'antd';
import _ from 'lodash';
import { MLModal, useHistory } from '@cyber-ccx/lib';
import { yuan } from '@/utils';
import useOnlyAsync from '@/utils/hooks/useOnlyAsync';

const { Option } = Select;
const FormItem = Form.Item;

interface InvoiceFormModalProps extends MLModal.FormModalComponent {}

const InvoiceFormModal: React.FC<InvoiceFormModalProps> = ({ query, ...props }) => {
  const { modal } = props;
  const isNew = !modal.params;
  const params = modal.params;
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [submiting, setSubmiting] = useState(false);
  const [detail, setDetail] = useState<defs.TheInformationOfMakeOutInvoice>();

  useEffect(() => {
    if (modal.isShow) {
      loadDetail();
    }
  }, [modal.isShow]);

  const loadDetail = async () => {
    try {
      setLoading(true);
      const res = await API.cardOpenInvoice.findOpenInvoiceById.request({ id: params?.item?.id });
      if (res.success) {
        setDetail(res.data);
      }
    } catch (error) {
      // error
    } finally {
      setLoading(false);
    }
  };

  const submit = useOnlyAsync(async () => {
    try {
      setSubmiting(true);
      const res = await API.cardOpenInvoice.agreeInvoice.request({ id: detail?.id ?? -1 });
      if (res.success) {
        message.success('确认成功');
        cancel();
        query?.refresh()
      }
    } catch (error) {
      // error
    } finally {
      setSubmiting(false);
    }
  });

  const cancel = () => {
    modal.close();
  };

  return (
    <Modal
      title={`开票详情`}
      width={1000}
      visible={modal.isShow}
      onCancel={cancel}
      className="form-page"
      footer={
        detail?.isDeal === 0 ? (
          <Space>
            <Button type="primary" loading={submiting} onClick={submit} children="确认开票" />
          </Space>
        ) : null
      }
    >
      <Spin spinning={loading}>
        <Descriptions title="发票详情" column={1} labelStyle={{ width: '10em' }} bordered>
          <Descriptions.Item label="抬头类型" children={detail?.titleTypeDesc} />
          <Descriptions.Item label="公司名称" children={detail?.title} />
          <Descriptions.Item label="公司税号" children={detail?.companyTaxNum} />
          <Descriptions.Item label="总金额(元)" children={yuan(detail?.totalMoney)} />
        </Descriptions>

        <Descriptions title="邮寄地址" column={1} labelStyle={{ width: '10em' }} style={{ marginTop: 16 }} bordered>
          <Descriptions.Item label="收件人" children={detail?.userName} />
          <Descriptions.Item label="手机号码" children={detail?.contactPhone} />
          <Descriptions.Item label="所在地区" children={`${detail?.provinceName}${detail?.cityName}${detail?.regionName}`} />
          <Descriptions.Item label="详细地址" children={detail?.detailAddr} />
        </Descriptions>
      </Spin>
    </Modal>
  );
};

export default InvoiceFormModal;
