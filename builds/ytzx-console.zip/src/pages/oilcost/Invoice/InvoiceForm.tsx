import React, { useEffect, useState, useMemo } from 'react';
import { Modal, Form, Input, notification, Select, Card, Spin, Table, Space } from 'antd';
import _ from 'lodash';
import { RouteChildrenProps, useLocation } from 'react-router-dom';
import Rules from '@/utils/rules';
import DetailWrapper from '@/components/DetailWrapper';
import { useHistory } from '@cyber-ccx/lib';
import { yuan } from '@/utils';
import ExportButton from '@/components/ExportButton';

interface InvoiceFormProps extends RouteChildrenProps {}

const InvoiceForm: React.FC<InvoiceFormProps> = ({ ...props }) => {
  const [loading, setLoading] = useState(false);
  const { state } = useLocation<any>();
  const [datas, setDatas] = useState<defs.DetailedListOfMakeOutInvoice[]>();

  React.useEffect(() => {
    loadList();
  }, []);

  const loadList = async () => {
    try {
      setLoading(true);
      const res = await API.cardOpenInvoice.findOpenDetailListById.request({ id: state?.item?.id });
      if (res.success) {
        setDatas(res.data || []);
      }
    } catch (error) {
      // error
    } finally {
      setLoading(false);
    }
  };

  return (
    <DetailWrapper title={'开票明细'}>
      <Table
        dataSource={datas}
        title={() => (
          <Space style={{ width: '100%', justifyContent: 'flex-end' }}>
            <ExportButton type={'primary'} method="GET" url={`/invoice/exportDetailList?id=${state?.item?.id}`} title="开票管理" children="导出" />
          </Space>
        )}
        rowKey="id"
        loading={loading}
        pagination={false}
        size="small"
        tableLayout="fixed"
        bordered
      >
        <Table.Column title="申请日期" dataIndex="applyTime" />
        <Table.Column title="申请人" dataIndex="applicantName" />
        <Table.Column title="车牌号码" dataIndex="vehicleNum" />
        <Table.Column title="车型" dataIndex="vehicleTypeName" />
        <Table.Column title="加油时间" dataIndex="orderTime" />
        <Table.Column title="油品" dataIndex="petrolName" />
        <Table.Column title="加油金额" dataIndex="actTotalPrice" render={(t) => yuan(t)} />
        <Table.Column title="加油站名称" dataIndex="stationName" />
      </Table>
    </DetailWrapper>
  );
};

export default InvoiceForm;
