import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "加油撬对账",
    routerUrl: "/QiaoBill",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./QiaoBill")),
    children: [
      {
        needLogin: true,
        resourceName: "对账单",
        routerUrl: "/QiaoBillForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./QiaoBillForm")),
      },
      //$MORE$
    ],
  },
];
