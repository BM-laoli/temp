import React, { useEffect, useState, useMemo } from 'react';
import { Modal, Form, Input, notification, Select, Card, Button, Col, Row, Table } from 'antd';
import _ from 'lodash';
import { RouteChildrenProps, useLocation } from 'react-router-dom';
import DetailWrapper from '@/components/DetailWrapper';
import { DataColumn, SearchForm, useFormModal, useHistory, useQuery, useSearchForm } from '@cyber-ccx/lib';
import CardTypeSelect from '@/components/CardTypeSelect';
import CompanySelect from '@/components/CompanySelect';
import OilSelect from '@/components/OilSelect';
import { PageBlock } from '@/components/PageWrapper';
import QiaoBillFormModal from './QiaoBillFormModal';
import { Random } from 'mockjs';
import ExportButton from '@/components/ExportButton';
import { DataTable } from '@/components/table-wy';

interface QiaoBillFormProps extends RouteChildrenProps {}

const QiaoBillForm: React.FC<QiaoBillFormProps> = ({ ...props }) => {
  const [loading, setLoading] = useState(false);
  const modal = useFormModal();
  const searchFrom = useSearchForm();
  const listQuery = useQuery();
  const location = useLocation<any>();
  const [dataSource, setDataSource] = useState<defs.TheReconciliationSubsidiaryEntities[]>([]);

  // React.useEffect(() => {
  //   loadDetail(listQuery.get());
  // }, [listQuery.get()]);

  const loadDetail = async (formData: any) => {
    setLoading(true);
    const data = {
      ...formData,
      deviceId: location?.state?.deviceId,
      dateTime: location?.state?.dateTime,
    };
    const res: API.fuelFee.refuelingSkidReconciliationDetail.Response = await API.fuelFee.refuelingSkidReconciliationDetail.request(data);
    if (res.success) {
      setDataSource(res.data || []);
    }
    setLoading(false);
  };

  const btns = [
    <Button key={1} onClick={() => searchFrom.submit()}>查询</Button>,
    <ExportButton
      key={2}
      style={{ marginLeft: '15px' }}
      type={'primary'}
      query={listQuery}
      formFormat={(data) => {
        const params: any = {
          ...data,
          deviceId: location?.state?.deviceId,
          dateTime: location?.state?.dateTime,
        };
        return params;
      }}
      url="/fuel/fee/exportRefuelingSkidReconciliationDetail"
      title={`加油撬：${location?.state?.deviceCode || ''}-${location?.state?.dateTime}月份对账单`}
      children="导出"
    />,
  ];

  return (
    <DetailWrapper title={`加油撬：${location?.state?.deviceCode || ''} ${location?.state?.dateTime}月份对账单`}>
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="车牌号" name="vehicleNum">
                <Input autoComplete={'off'} placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="加油型号" name="petrolId">
                <OilSelect placeholder="请选择" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="油卡类型" name="cardType">
                <CardTypeSelect placeholder="请选择" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="所属公司" name="companyId">
                <CompanySelect placeholder="请选择" allowClear />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <DataTable
        title="加油撬数据列表"
        className={'full-table'}
        rowKeyIndex={'resourceId'}
        rowKey={() => Random.guid()}
        api={API.fuelFee.refuelingSkidReconciliationDetailPageList.request}
        query={listQuery}
        dataFormat={(res) => ({
          rows: res.data,
          total: res.count,
        })}
        formFormat={(data) => {
          const where: any = {
            ...data,
            deviceId: location?.state?.deviceId,
            dateTime: location?.state?.dateTime,
          };
          delete where.page
          delete where.rows
          const params: any = {
            where: { ...where },
            curPage: data.page,
            pageSize: data.rows,
          };
          return params;
        }}
      >
        <DataColumn title="加油日期" dataIndex="dateTime" />
        <DataColumn title="所属公司" dataIndex="companyName" width={200} ellipsis />
        <DataColumn title="车牌号" dataIndex="vehicleNum" />
        <DataColumn title="驾驶员" dataIndex="driverName" />
        <DataColumn title="加油型号" dataIndex="petrolNames" />
        <DataColumn title="油卡类型" dataIndex="cardTypeName" />
        <DataColumn title="加油量（升）" dataIndex="petrolCount" />
        <DataColumn title="获取方式" dataIndex="detailSource" />
        <DataColumn title="是否确认" dataIndex="isConfirm" />
        <DataColumn title="加油员" dataIndex="stationEmpName" />
        <DataColumn
          title="操作"
          fixed="right"
          render={(item) => {
            return (
              <>
                <Button size="small" type="link" onClick={() => modal.open({ item, deviceCode: location?.state?.deviceCode })} children="详情" />
              </>
            );
          }}
        />
      </DataTable>
      {/* <Table dataSource={dataSource} rowKey={() => Random.guid()} loading={loading} pagination={false} size="small" tableLayout="fixed" bordered>
        <Table.Column title="加油日期" dataIndex="dateTime" />
        <Table.Column title="所属公司" dataIndex="companyName" width={200} ellipsis />
        <Table.Column title="车牌号" dataIndex="vehicleNum" />
        <Table.Column title="驾驶员" dataIndex="driverName" />
        <Table.Column title="加油型号" dataIndex="petrolNames" />
        <Table.Column title="油卡类型" dataIndex="cardTypeName" />
        <Table.Column title="加油量（升）" dataIndex="petrolCount" />
        <Table.Column title="获取方式" dataIndex="detailSource" />
        <Table.Column title="是否确认" dataIndex="isConfirm" />
        <Table.Column title="加油员" dataIndex="stationEmpName" />
        <DataColumn
          title="操作"
          fixed="right"
          render={(item) => {
            return (
              <>
                <Button size="small" type="link" onClick={() => modal.open({ item, deviceCode: location?.state?.deviceCode })} children="详情" />
              </>
            );
          }}
        />
      </Table> */}

      <QiaoBillFormModal modal={modal} />
    </DetailWrapper>
  );
};

export default QiaoBillForm;
