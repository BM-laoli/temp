import React, { useMemo } from 'react';
import { Modal, Descriptions, Space, Image } from 'antd';
import { MLModal } from '@cyber-ccx/lib';
import mockjs from 'mockjs';
import _ from 'lodash';

interface QiaoBillFormModalProps extends MLModal.FormModalComponent {}

const QiaoBillFormModal: React.FC<QiaoBillFormModalProps> = ({ query, ...props }) => {
  const { modal } = props;
  const params = modal.params;
  const data = useMemo(() => ({ ...params?.item }), [params]);

  const cancel = () => {
    modal.close();
  };

  return (
    <Modal title={`加油详情`} width={1200} visible={modal.isShow} footer={false} onCancel={cancel} className="form-page">
      <Descriptions column={1} bordered labelStyle={{ width: '10em' }}>
        <Descriptions.Item label="加油日期">{data?.dateTime}</Descriptions.Item>
        <Descriptions.Item label="加油撬编号">{data?.deviceCode}</Descriptions.Item>
        <Descriptions.Item label="加油量">{data?.petrolCount}</Descriptions.Item>
        <Descriptions.Item label="获取方式">{data?.detailSource}</Descriptions.Item>
        <Descriptions.Item label="是否确认">{data?.isConfirm}</Descriptions.Item>
        <Descriptions.Item label="提交图片">
          {!!data?.imgBigPaths && (
            <Image.PreviewGroup>
              <Space>
                {data?.imgBigPaths?.split(',').map((v, i) => (
                  <Image width={100} height={100} src={v} key={`images-${i}`} />
                ))}
              </Space>
            </Image.PreviewGroup>
          )}
        </Descriptions.Item>
      </Descriptions>
    </Modal>
  );
};

export default QiaoBillFormModal;
