import Agreement from './Agreement'; //$IMPORT$
import Help from './Help'; //$IMPORT$
import Notice from './Notice';
import BannerAD from './BannerAD';

export default () => [
  {
    resourceName: 'h5',
    routerUrl: '/h5',
    resourceIcon: '',
    type: '0',
    buttons: [],
    children: [
      Agreement(), //$MORE$
      Help(),
      Notice(),
      BannerAD(),
    ],
  },
];
