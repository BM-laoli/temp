/* eslint-disable react/jsx-key */
import React, { FC, useEffect, useState } from 'react';
import './style.less';
import axios from 'axios';

interface InterPageData {
  title: string;
  content: string;
  imgs: Array<string>;
  imgType: 'one' | 'two'; // html 分几个栏位
}

const newAxios = axios.create({ baseURL: 'http://18.208.174.187:3000', responseType: 'json' });

const getApi = async (): Promise<InterPageData> => {
  const data = await newAxios.get('/api/detail');
  return data.data?.data;
};

const Notice: FC<any> = () => {
  // 获取 页面所需要的所有数据
  const [loading, setLoading] = useState(true);
  const [pageData, setPageData] = useState<InterPageData>({
    title: '',
    content: '',
    imgs: [],
    // imgType: 'one',
    imgType: 'two',
  });

  const init = async () => {
    setLoading(true);
    const data = await getApi();
    console.log(data);
    setPageData(data);
    setLoading(false);
    (window as any)?.ReactNativeWebView?.postMessage?.('success');
  };

  useEffect(() => {
    init();
  }, []);

  const imgCls = pageData.imgType === 'one' ? 'img-80 ' : 'img-45';
  const imgWrap = pageData.imgType === 'one' ? 'h5_notice_content_imgWrap' : 'h5_notice_content_imgWrap h5_notice_content_imgWrap-wrap';
  return (
    <div className="h5_notice_wrap">
      <div className="h5_notice_wrap_card">
        {/* title */}
        <div className="h5_notice_wrap_card_title">
          <p>关于某某问题的解决方案</p>
        </div>
        <div className="content">
          <div className="video-iframe">
            <iframe
              src="//player.bilibili.com/player.html?aid=407862237&bvid=BV1fG411C7Cm&cid=1317154539&p=1&danmaku=0&as_wide=1&high_quality=1"
              scrolling="no"
              frameBorder="no"
              allowFullScreen={true}
            ></iframe>
          </div>
          {/* link list */}
          <div className="link-wrap">
            <a href="#">点击我前往A处Page</a>
          </div>
          <div className="h5_notice_content_body">
            {/* 文案区域 */}
            <div className="h5_notice_content_wrap">
              <p dangerouslySetInnerHTML={{ __html: pageData.content || '' }}></p>
            </div>

            {/* 多图片区域 */}
            <div className={imgWrap}>
              {pageData.imgs.map((item, index) => {
                return <img className={imgCls} src={item} alt="" />;
              })}
            </div>
          </div>
        </div>
        {/*video and link */}
      </div>
    </div>
  );
};

export default Notice;
