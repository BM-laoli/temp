/* eslint-disable react/jsx-key */
import React, { FC, useEffect, useLayoutEffect, useState } from 'react';
import './style.less';
import axios from 'axios';

const newAxios = axios.create({ baseURL: 'http://18.208.174.187:3000', responseType: 'json' });

const getApi = async (): Promise<any> => {
  const data = await newAxios.get('/api/detail');
  return data.data?.data;
};

const PowerBank: FC<any> = () => {
  const init = async () => {
    (window as any)?.ReactNativeWebView?.postMessage?.('success');
  };

  useLayoutEffect(() => {
    init();
  }, []);

  return (
    <div className="h5_content_body">
      <img src={require('@/assets/images/ad/power_bank.png')} alt="" />
    </div>
  );
};

export default PowerBank;
