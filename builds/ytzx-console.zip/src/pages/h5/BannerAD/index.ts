import loadable from '@loadable/component';

export default () => [
  {
    needLogin: false,
    resourceName: '/Logistics',
    routerUrl: '/Logistics',
    resourceIcon: 'TeamOutlined',
    type: '0',
    buttons: [],
    noparent: true,
    component: loadable(() => import('./Logistics')),
    children: [
      //$MORE$
    ],
  },
  {
    needLogin: false,
    resourceName: '/PowerBank',
    routerUrl: '/PowerBank',
    resourceIcon: 'TeamOutlined',
    type: '0',
    buttons: [],
    noparent: true,
    component: loadable(() => import('./PowerBank')),
    children: [
      //$MORE$
    ],
  },
];
