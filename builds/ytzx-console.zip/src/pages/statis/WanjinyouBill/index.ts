/*
 * @Author: TigerLord
 * @Date: 2022-09-06 15:30:55
 * @LastEditTime: 2022-09-26 14:00:15
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/pages/statis/WanjinyouBill/index.ts
 */
import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "订单查询",
    routerUrl: "/WanjinyouBill",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./WanjinyouBill")),
    children: [
      {
        needLogin: true,
        resourceName: "新增WanjinyouBill",
        routerUrl: "/WanjinyouBillForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./WanjinyouBillForm")),
      },
      //$MORE$
    ],
  },
];
