import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import WanjinyouBillFormModal from './WanjinyouBillFormModal';
import { Random } from 'mockjs';
import { ml2litre, yuan } from '@/utils';
import StationSourceSelect from '@/components/StationSourceSelect';
import ExportButton from '@/components/ExportButton';
import GasStationSelect from '@/components/GasStationSelect';
import OilSelect from '@/components/OilSelect';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface WanjinyouBillProps extends RouteChildrenProps {}

const WanjinyouBill: React.FC<WanjinyouBillProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  const btns = [
    <Button key={1} onClick={() => searchFrom.submit()}>查询</Button>,
    <ExportButton
      key={2}
      style={{ marginLeft: '15px' }}
      type={'primary'}
      query={listQuery}
      formFormat={(data) => {
        const [startDate, endDate] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
        const [startRefundFinishedDate,endRefundFinishedDate] = [data.refundTime?.[0]?.format('YYYY-MM-DD 00:00:00'), data.refundTime?.[1]?.format('YYYY-MM-DD 23:59:59')];
        const [startPayFinishedDate,endPayFinishedDate] = [data.payTime?.[0]?.format('YYYY-MM-DD 00:00:00'), data.payTime?.[1]?.format('YYYY-MM-DD 23:59:59')];
        
        const params: any = { startDate, endDate, startRefundFinishedDate,endRefundFinishedDate,startPayFinishedDate,endPayFinishedDate, ...data };
        return params;
      }}
      url="/statistics/exportWJY"
      title="订单查询"
      children="导出"
    />,
    <Button key={3} style={{ marginLeft: '15px', background: '#000', border: 0 }} type={'primary'} onClick={() => modal.open()}>
      补单
    </Button>,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={6}>
              <Form.Item label="交易日期" name="time">
                <RangePicker allowClear style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="油站查询" name="stationName">
                <Input placeholder="请输入" allowClear />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="加油型号" name="petrolId">
                <OilSelect placeholder="请选择" allowClear />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="加油站来源" name="stationSource">
                <StationSourceSelect placeholder="请选择加油站来源" allowClear />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="车牌号" name="vehicleNum">
                <Input placeholder="请输入" allowClear />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="油卡卡号" name="cardNum">
                <Input placeholder="请输入" allowClear />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="三方平台订单号" name="thirdSerialNo">
                <Input placeholder="请输入" allowClear />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="订单号" name="orderSerialNo">
                <Input placeholder="请输入" allowClear />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="支付日期" name="payTime">
                <RangePicker allowClear style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="退款日期" name="refundTime">
                <RangePicker allowClear style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="油卡类型" name="cardType">
                <Select placeholder="请选择油卡类型" allowClear>
                  <Option value={0}>车队油卡</Option>
                  <Option value={1}>云途油卡</Option>
                  <Option value={2}>实体油卡</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="订单状态" name="orderStatus">
                <Select placeholder="请选择订单状态" allowClear>
                  <Option value={0}>待支付</Option>
                  <Option value={1}>已完成</Option>
                  <Option value={3}>已退款</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="核销状态" name="checkStatus">
                <Select placeholder="请选择核销状态" allowClear>
                  <Option value={0}>未核销</Option>
                  <Option value={1}>已核销</Option>
                  <Option value={2}>无需核销</Option>
                </Select>
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="支付方式" name="tradeType">
                <Select placeholder="请选择支付方式" allowClear>
                  <Option value={0}>扫码支付</Option>
                  <Option value={1}>主动支付</Option>
                  <Option value={3}>补单</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="数据列表"
          className={'full-table'}
          rowKeyIndex={'resourceId'}
          rowKey={() => Random.guid()}
          api={API.statistics.getStationStatisticsPage.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const [startDate, endDate] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
            const [startRefundFinishedDate,endRefundFinishedDate] = [data.refundTime?.[0]?.format('YYYY-MM-DD 00:00:00'), data.refundTime?.[1]?.format('YYYY-MM-DD 23:59:59')];
            const [startPayFinishedDate,endPayFinishedDate] = [data.payTime?.[0]?.format('YYYY-MM-DD 00:00:00'), data.payTime?.[1]?.format('YYYY-MM-DD 23:59:59')];
            
            const params: any = {
              where: { startDate, endDate, startRefundFinishedDate, endRefundFinishedDate, startPayFinishedDate, endPayFinishedDate, ...data },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
        >
          <DataColumn title="交易日期" dataIndex="dateTime" />
          <DataColumn title="加油站来源" dataIndex="stationSourceDesc" />
          <DataColumn title="用户" dataIndex="driverName" />
          <DataColumn title="操作人" dataIndex="supOpName" />
          <DataColumn title="油站名称" dataIndex="stationName" />
          <DataColumn title="油枪号" dataIndex="gunCode" />
          <DataColumn title="三方平台订单号" dataIndex="thirdSerialNo" />
          <DataColumn title="加油订单号" dataIndex="orderSerialNo" />
          <DataColumn title="订单实付总额" dataIndex="actTotalPrice" render={(item) => yuan(item)} />
          <DataColumn title="加油量（升）" dataIndex="petrolCount" render={(item) => ml2litre(item) + 'L'} />
          <DataColumn title="车牌号" dataIndex="vehicleNum" />
          <DataColumn title="支付方式" dataIndex="tradeTypeDesc" />
          <DataColumn title="支付状态" dataIndex="payStatus" />
          <DataColumn title="支付完成时间" dataIndex="payFinishedTime" />
          <DataColumn title="退款完成时间" dataIndex="refundFinishedTime" />
          <DataColumn title="订单状态" dataIndex="orderStatus" />
          <DataColumn title="油卡类型" dataIndex="cardTypeName" />
          <DataColumn title="油卡卡号" dataIndex="petrolCardNum" />
          <DataColumn title="加油型号" dataIndex="petrolNames" />
          <DataColumn title="核销状态" dataIndex="isVerificationDesc" />
        </DataTable>
      </div>
      <WanjinyouBillFormModal modal={modal} query={listQuery} />
    </PageWrapper>
  );
};

export default WanjinyouBill;
