/*
 * @Author: TigerLord
 * @Date: 2022-09-06 15:28:29
 * @LastEditTime: 2023-01-30 17:55:13
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/pages/statis/WanjinyouBill/WanjinyouBillFormModal.tsx
 */
import React, { useEffect, useState, useMemo } from "react";
import { Modal, Form, Input, notification, Select, message, Col } from 'antd';
import _ from "lodash";
import { MLModal, useHistory } from "@cyber-ccx/lib";
import Rules from "@/utils/rules";
import CompanySelect from "@/components/CompanySelect";
import CarsToSelect from "@/components/CarsToSelect";
import GasStationSelect from "@/components/GasStationSelect";
import StationSourceSelect from "@/components/StationSourceSelect";
import OilSelect from "@/components/OilSelect";
import CardTypeSelect from "@/components/CardTypeSelect";
import { ml2litre, yuan } from "@/utils";
import OrgSelect from "@/components/OrgSelect";
import CarsSelect from "@/components/CarsSelect";

const { Option } = Select;
const FormItem = Form.Item;

interface WanjinyouBillFormModalProps extends MLModal.FormModalComponent {}

const WanjinyouBillFormModal: React.FC<WanjinyouBillFormModalProps> = ({ query, ...props }) => {
  const [form] = Form.useForm();
  const { modal } = props;
  const isNew = !modal.params;
  const params = modal.params;
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [orgId, setOrgId] = useState<number>();
  const [deptId, setDeptId] = useState<number>()
  const [carId , setCarId] = useState<number>(0)
  const [cardData, setCardData] = useState<Array<defs.CloudElectronicOilClipCardObjects>>()
  const [carType ,setCarType] = useState<defs.CloudElectronicOilClipCardObjects>()
  const [station , setStation] = useState<any>()
  const [petrolList, setPetrolList] = useState<Array<defs.ResStation2GunObject>>() // 加油枪
  const [oliList,setOliList] = useState<any>()
  const [deviceList ,setDeviceList] = useState<any>()

  useEffect(() => {
    if (modal.isShow) {
      setCarType({})
    }
    if (modal.isShow && !isNew) {
      form.setFieldsValue(params.item);
    } else {
      form.resetFields();
    }
  }, [modal.isShow]);
  useEffect(() => {
    if (modal.isShow) {
      loadCard()
    }
  }, [carId])
  const loadCard = async () => {
    const res: API.statistics.cardInfoListByVehicleId.Response = await API.statistics.cardInfoListByVehicleId.request({
      id: carId
    })
    if (res.success) {
     setCardData(res.data)
    }
  };
  useEffect(() => {
    if (modal.isShow && station?.id) {
      loadOli()
    }
  }, [station?.id])
  // 查询油品信息
  const loadOli = async () => {
    const res: API.statistics.getResPetrolListById.Response = await API.statistics.getResPetrolListById.request({
      id: station?.id
    })
    if (res.success) {
      console.log('---刘琦珂---', res.data);
      
     if (res.data?.type === 0) {
      setOliList(res.data?.station2PetrolList)
      setDeviceList([])
      setPetrolList([])
     } else if(res.data?.type === 1) {
      setDeviceList(res.data?.stationDeviceList)
      setPetrolList([])
      setOliList([])
     } else {
      setPetrolList(res.data?.resStation2GunList)
      setDeviceList([])
      setOliList([])
     }
    }
  }

  const handleInput = (e) => {
    // e.persist();
    const val = e.target.value
    const value: any = (val.match(/^[-]?\d*(\.?\d{0,2})/g)[0]) || null
    form.setFieldsValue({ price: value });
  }
  const submit = async () => {
    form
      .validateFields()
      .then(async (formData) => {
        console.log('---ssssss---', formData);
        
        const data = {
          ...formData,
          price: Math.round(formData.price * 10000) / 100,
          petrolCount: Number(formData.petrolCount) * 1000,
        };
      setLoading(true);
      const res: API.statistics.supplementOrder.Response = await API.statistics.supplementOrder.request(data);
      setLoading(false);
      if (res.success) {
        message.success(`设置成功`);
        query?.refresh();
        cancel();
      }
    })
  };

  const cancel = () => {
    modal.close();
  };
  // 油卡
  const optionsCard = useMemo(() => cardData?.map((v) => ({ label: v.petrolCardNum || '', value: Number(v.id) ?? '', ...v })), [cardData]);
  // 油枪
  const resStation2GunList = useMemo(() => petrolList?.map((v) => ({ label: v.gunCode + '号枪 ' + v.petrolName || '', value: Number(v.id) ?? '', ...v })), [petrolList]);
  // 油品
  const OilSelect = useMemo(() => oliList?.map((v) => ({ label: v.petrolName || '', value: Number(v.petrolId) ?? '', ...v })), [oliList]);
  // 加油撬
  
  const deviceSelect = useMemo(() => deviceList?.map((v) => ({ label: v.deviceCode+ '  ' + v.petrolName || '' , value: Number(v.id) ?? '', ...v })), [deviceList]);

  console.log('222222222', deviceList);
  
  return (
    <Modal
      title={`${isNew ? "新增" : "修改"}补单`}
      width={600}
      visible={modal.isShow}
      onOk={submit}
      confirmLoading={loading}
      onCancel={cancel}
      className="form-page"
    >
      <Form form={form} labelCol={{ span: 7 }} wrapperCol={{ span: 12 }}>
        <FormItem label="选择公司" name="resourceName" {...Rules("required")}>
          <CompanySelect onChange={(v) => {
            setOrgId(v)
            form.setFieldsValue({deptId: null });
          }} />
        </FormItem>
        <FormItem label="选择部门" name={'deptId'} {...Rules('required')}>
          <OrgSelect orgId={orgId} placeholder="请先选择公司" allowClear onChange={(v) => {
            setDeptId(v)
            form.setFieldsValue({carId: null });
          }} />
        </FormItem>
        <FormItem label="选择车辆" name="carId">
          <CarsToSelect placeholder="请先选公司再选择车辆" companyId={orgId}  deptId={deptId} onChange={(v) => setCarId(v)} />
          {/* <CarsSelect
            companyId={orgId}
            deptId={deptId}
            placeholder="请先选部门再选择车辆"
            onChange={(v) => setCarId(v)} 
          /> */}
        </FormItem>
        <Col>
          <FormItem label="选择油卡" name="cardId" {...Rules("required")}>
            <Select placeholder="请先选车辆再选择油卡" options={optionsCard} onChange={(v, o: any ) => setCarType(o)} />
          </FormItem>
          {carType?.petrolCardType === 0 ? (
            <div style={{ position: 'absolute', left: '31%', top:'110%', color: 'red', fontSize: 12 }}>
              <span>剩余油量：{ carType?.remaining2PetrolSum !== undefined? '-35#柴油 ' + ml2litre(carType?.remaining2PetrolSum) + 'L' : null }   { carType?.remainingPetrolSum !== undefined ? '0#柴油 ' +  ml2litre(carType?.remainingPetrolSum) + 'L' : null }</span>
            </div>
          ): (
            carType?.remainingSum !== undefined && (
              <div style={{ position: 'absolute', left: '31%', top:'110%', color: 'red', fontSize: 12 }}>
                <span>当前余额：￥{ carType?.remainingSum !== undefined ? yuan(carType?.remainingSum) : 0}</span>
              </div>
            ) 
          )}          
        </Col>
        <FormItem label="选择油站" name="stationId" {...Rules("required")}>
          <GasStationSelect placeholder="请输入所属油站关键字" allowClear onChange={(v, o) => setStation(o)} />
        </FormItem>
        <FormItem
          label="油站来源"
        >
          {station?.stationSourceDesc}
        </FormItem>
        {petrolList && petrolList?.length > 0 && (
          <>
            <FormItem label="选择油枪" name="gunId">
              <Select placeholder="请输入所属油站关键字" options={resStation2GunList}  allowClear  onChange={(v, o: any) => { 
                form.setFieldsValue(o)
              }} />
            </FormItem>
            <FormItem label="选择油品" name="petrolId" hidden>
              <Input />
            </FormItem>
            
          </>
         
        )}
        {deviceList && deviceList?.length > 0 && (
          <>
            <FormItem label="选择加油撬" name="deviceId">
              <Select placeholder="选择加油撬" options={deviceSelect} allowClear  onChange={(v, o: any) => { 
                  form.setFieldsValue(o)
                }} />
            </FormItem>
            <FormItem label="选择油品" name="petrolId" hidden>
              <Input />
            </FormItem>
          </>
        )}
        <FormItem label="选择油品" name="petrolName" hidden>
          <Input disabled />
        </FormItem>
        {oliList && oliList?.length > 0  && (
          <>
            <FormItem label="选择油品" name="petrolId">
              <Select placeholder="请选择油品" options={OilSelect} onChange={(v, o: any) => { form.setFieldsValue(o) }}  />
              {/* <OilSelect mode="multiple" /> */}
            </FormItem>
            <FormItem label="选择油品" name="petrolName" hidden>
              <Input   />
            </FormItem>
          </>
        )}
       {/* 'number', */}
        <FormItem label="加油量" name="petrolCount" {...Rules( "required")}>
          <Input autoComplete={'off'} />
        </FormItem>
        { carType?.petrolCardType !== 0 || station?.stationSource !== 0 ? (
          // 'priceTwo',
          <FormItem label="加油金额" name="price" {...Rules("required")}>
            <Input autoComplete={'off'}  onChange={ e => handleInput(e)}/>
          </FormItem>
        ): null }
        
      </Form>
    </Modal>
  );
};

export default WanjinyouBillFormModal;
