import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import GasstationFormModal from './GasstationFormModal';
import AreaSelect from '@/components/AreaSelect';
import CompanySelect from '@/components/CompanySelect';
import CardTypeSelect from '@/components/CardTypeSelect';
import StationSourceSelect from '@/components/StationSourceSelect';
import { yuan } from '@/utils';
import { Random } from 'mockjs';
import ExportButton from '@/components/ExportButton';
import OilSelect from '@/components/OilSelect';
import GasStationSelect from '@/components/GasStationSelect';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface GasstationProps extends RouteChildrenProps {}

const Gasstation: React.FC<GasstationProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  const btns = [
    <Button key={1} onClick={() => searchFrom.submit()}>查询</Button>,
    <ExportButton
      key={2}
      style={{ marginLeft: '15px' }}
      type={'primary'}
      query={listQuery}
      formFormat={(data) => {
        const [startTime, endTime] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
        const [provinceCode, cityCode, regionCode] = data.areas || [];
        const params: any = { startTime, endTime, provinceCode, cityCode, regionCode, companyId: data.companyId, cardType: data.cardType, ...data };
        return params;
      }}
      url="/statistics/exportCompany"
      title="加油统计"
      children="导出"
    />,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="加油日期" name="time">
                <RangePicker allowClear style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="公司名称" name="companyId">
                <CompanySelect placeholder="请选择" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="所属区域" name="areas">
                <AreaSelect placeholder="请选择" changeOnSelect allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="油卡类型" name="cardType">
                <CardTypeSelect placeholder="请选择" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="油站名称" name="stationId">
                <GasStationSelect placeholder="请输入油站名称关键字" allowClear 
                  onChange={(_e, option: any) => {
                    // listQuery.set({stationName: option.stationName})
                  }}
                /> 
              </Form.Item>
              <Form.Item name="stationName" hidden>
                <Input autoComplete={'off'} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="加油站来源" name="stationSource">
                <StationSourceSelect placeholder="请选择加油站来源" allowClear />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="数据列表"
          rowKeyIndex={Random.guid()}
          className={'full-table'}
          rowKey={() => Random.guid()}
          api={API.statistics.getCompanyPetrolStatPage.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const [startTime, endTime] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
            const [provinceCode, cityCode, regionCode] = data.areas || [];
            const params: any = {
              where: { startTime, endTime, provinceCode, cityCode, regionCode, ...data },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
        >
          <DataColumn title="加油日期" dataIndex="dateStr" width={200} />
          <DataColumn title="公司名称" dataIndex="companyName" ellipsis />
          <DataColumn title="加油站" dataIndex="stationName" />
          <DataColumn title="加油站来源" dataIndex="stationSourceDesc" />
          <DataColumn title="加油型号" dataIndex="petrolName" ellipsis />
          <DataColumn title="油卡类型" dataIndex="cardTypeDesc" />
          <DataColumn title="加油量（升）" dataIndex="petrolCount" render={(t) => (t / 1000).toFixed(2)} />
          <DataColumn title="加油金额（元）" dataIndex="actTotalPrice" width={200} render={(item) => yuan(item)} />
          <DataColumn title="操作" fixed="right" width={220} render={(_t, item) => <Button type="link" size="small" onClick={() => modal.open(item)} children="加油明细" />} />
        </DataTable>
      </div>
      <GasstationFormModal modal={modal} />
    </PageWrapper>
  );
};

export default Gasstation;
