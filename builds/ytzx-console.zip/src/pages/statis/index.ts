/*
 * @Author: TigerLord
 * @Date: 2022-09-06 15:28:29
 * @LastEditTime: 2022-10-17 16:14:19
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/pages/statis/index.ts
 */
import Gasstation from "./Gasstation";
import Company from "./Company";
import Vehicle from "./Vehicle";
import Commission from "./Commission";
import CompanyBill from "./CompanyBill";
import WanjinyouBill from "./WanjinyouBill";
import Transfer from "./Transfer";
import UnusualOrder from "./UnusualOrder"; //$IMPORT$

export default () => [
  {
    resourceName: "统计查询",
    routerUrl: "/statis",
    resourceIcon: "",
    type: "0",
    buttons: [],
    children: [
      Gasstation(),
      // Company(),
      // Vehicle(),
      WanjinyouBill(),
      UnusualOrder(), //$MORE$
      // CompanyBill(),
      Commission(),
      Transfer(),
    ],
  },
];
