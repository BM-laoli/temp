/*
 * @Author: TigerLord
 * @Date: 2022-10-17 14:41:58
 * @LastEditTime: 2022-10-17 16:24:28
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/pages/statis/UnusualOrder/UnusualOrder.tsx
 */
import React, { useState, useEffect, useRef } from "react";
import { observer } from "mobx-react-lite";
import _ from "lodash";
import { RouteChildrenProps } from "react-router-dom";
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag } from "antd";
import PageWrapper, { PageBlock } from "@/components/PageWrapper";
import {
  DataTable,
  DataColumn,
  useHistory,
  SearchForm,
  useSearchForm,
  useFormModal,
  MLModal,
  useQuery,
} from "@/components/table-wy";
import UnusualOrderFormModal from "./UnusualOrderFormModal";
import { ml2litre, yuan } from "@/utils";
import { Random } from "mockjs";
import OilSelect from "@/components/OilSelect";
import StationSourceSelect from "@/components/StationSourceSelect";
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface UnusualOrderProps extends RouteChildrenProps {}

const UnusualOrder: React.FC<UnusualOrderProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  return (
    <PageWrapper className="list-page">
      <div className="list-content">
        <DataTable
          title="数据列表"
          className={'full-table'}
          rowKeyIndex={'resourceId'}
          rowKey={() => Random.guid()}
          api={API.statistics.getStationStatisticsPage.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const params: any = {
              where: {payStatus: 1, ...data },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
        >
          <DataColumn title="交易日期" dataIndex="dateTime" />
          <DataColumn title="加油站来源" dataIndex="stationSourceDesc" />
          <DataColumn title="用户" dataIndex="driverName" />
          <DataColumn title="操作人" dataIndex="supOpName" />
          <DataColumn title="油站名称" dataIndex="stationName" />
          <DataColumn title="油枪号" dataIndex="gunCode" />
          <DataColumn title="三方平台订单号" dataIndex="thirdSerialNo" />
          <DataColumn title="加油订单号" dataIndex="orderSerialNo" />
          <DataColumn title="订单实付总额" dataIndex="actTotalPrice" render={(item) => yuan(item)} />
          <DataColumn title="加油量（升）" dataIndex="petrolCount" render={(item) => ml2litre(item) + 'L'} />
          <DataColumn title="车牌号" dataIndex="vehicleNum" />
          <DataColumn title="支付方式" dataIndex="tradeTypeDesc" />
          <DataColumn title="支付状态" dataIndex="payStatus" />
          <DataColumn title="支付完成时间" dataIndex="payFinishedTime" />
          <DataColumn title="退款完成时间" dataIndex="refundFinishedTime" />
          <DataColumn title="订单状态" dataIndex="orderStatus" />
          <DataColumn title="油卡类型" dataIndex="cardTypeName" />
          <DataColumn title="油卡卡号" dataIndex="petrolCardNum" />
          <DataColumn title="加油型号" dataIndex="petrolNames" />
          <DataColumn title="核销状态" dataIndex="isVerificationDesc" />
        </DataTable>
      </div>
    </PageWrapper>
  );
};

export default UnusualOrder;
