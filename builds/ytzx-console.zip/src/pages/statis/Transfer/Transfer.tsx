import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag, message } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import TransferFormModal from './TransferFormModal';
import CompanySelect from '@/components/CompanySelect';
import { yuan } from '@/utils';
import { requestUpload } from '@/utils/request';
import config from '@/config';
import excel from '@/utils/excel';

const RangePicker = DatePicker.RangePicker;

interface TransferProps extends RouteChildrenProps {}

const Transfer: React.FC<TransferProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();

  const handleExport = async () => {
    const data = listQuery.get();
    const [startTime, endTime] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
    const search = { zcCompanyId: data.zcCompanyId, zrCompanyId: data.zrCompanyId, startTime, endTime };

    try {
      const res: Blob = await requestUpload({
        url: config.API_HOST + '/elecCard/yuTu/exportTransferFile',
        data: search,
        method: 'POST',
        credentials: 'include',
        timeout: 180 * 1000,
      });
      if (res && res instanceof Blob) {
        excel.downloadExcel(res, '转账明细');
      } else {
        message.error('导出失败');
      }
    } catch (error) {
      message.error('导出失败');
    }
  };

  const btns = [
    <Button onClick={() => searchFrom.submit()}>查询</Button>,
    <Button style={{ marginLeft: '16px' }} type={'primary'} onClick={handleExport}>
      导出
    </Button>,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="转账时间" name="time">
                <RangePicker allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="转出公司" name="zcCompanyId">
                <CompanySelect placeholder="请选择转出公司" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="转入公司" name="zrCompanyId">
                <CompanySelect placeholder="请选择转入公司" allowClear />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="转账明细"
          className={'full-table'}
          rowKeyIndex={'id'}
          api={API.elecYutuCard.getCardTransferLogByPage.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const [startTime, endTime] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
            let params: any = {
              where: { zcCompanyId: data.zcCompanyId, zrCompanyId: data.zrCompanyId, startTime, endTime },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
        >
          <DataColumn title="转账时间" dataIndex="operateTime" />
          <DataColumn title="转出公司" dataIndex="zcCompanyName" />
          <DataColumn title="转出卡号" dataIndex="zcCardNum" />
          <DataColumn title="转出司机" dataIndex="zcDriverName" />
          <DataColumn title="转入公司" dataIndex="zrCompanyName" />
          <DataColumn title="转入卡号" dataIndex="zrCardNum" />
          <DataColumn title="转入司机" dataIndex="zrDriverName" />
          <DataColumn title="转账金额" dataIndex="changeMoney" render={(t) => yuan(t)} />
        </DataTable>
      </div>
      <TransferFormModal modal={modal} />
    </PageWrapper>
  );
};

export default Transfer;
