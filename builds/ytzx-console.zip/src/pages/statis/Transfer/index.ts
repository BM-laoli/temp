import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "转账明细",
    routerUrl: "/Transfer",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./Transfer")),
    children: [
      {
        needLogin: true,
        resourceName: "新增Transfer",
        routerUrl: "/TransferForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./TransferForm")),
      },
      //$MORE$
    ],
  },
];
