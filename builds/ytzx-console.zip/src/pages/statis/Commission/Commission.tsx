/*
 * @Author: TigerLord
 * @Date: 2022-10-08 13:55:44
 * @LastEditTime: 2022-10-21 09:39:08
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/pages/statis/Commission/Commission.tsx
 */
import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import CommissionFormModal from './CommissionFormModal';
import { Random } from 'mockjs';
import { yuan } from '@/utils';
import ExportButton from '@/components/ExportButton';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface CommissionProps extends RouteChildrenProps {}

const Commission: React.FC<CommissionProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  const btns = [
    <Button key={1} onClick={() => searchFrom.submit()}>查询</Button>,
    <ExportButton key={2} style={{ marginLeft: '15px' }} type={'primary'} query={listQuery} url="/stat/export" title="佣金统计" children="导出" />,
    // <Button style={{ marginLeft: '20px' }} type={'primary'} onClick={() => history.push('Commission/CommissionForm')}>
    //   新增
    // </Button>,
    // <Button style={{ marginLeft: '20px' }} type={'primary'} onClick={() => modal.open()}>
    //   新增(弹窗)
    // </Button>,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="加油员" name="userName">
                <Input autoComplete={'off'} placeholder="请输入关键字" />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="数据列表"
          className={'full-table'}
          rowKeyIndex={'resourceId'}
          rowKey={() => Random.guid()}
          api={API.commissionStat.pageList.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const params: any = {
              where: { userName: data.userName },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
        >
          <DataColumn title="加油员" dataIndex="userName" />
          <DataColumn title="所属油站" dataIndex="stationName" />
          <DataColumn title="推荐人数" dataIndex="refereeNum" />
          <DataColumn title="累计加油金额（元）" dataIndex="totalOilMoney" render={(item) => yuan(item)} />
          <DataColumn title="佣金总额（元）" dataIndex="totalCommissionMoney" render={(item) => yuan(item)} />
          <DataColumn title="提现金额（元）" dataIndex="totalCashOut" render={(item) => yuan(item)} />
          <DataColumn title="剩余金额（元）" dataIndex="remainingCommision" render={(item) => yuan(item)} />
        </DataTable>
      </div>
      <CommissionFormModal modal={modal} />
    </PageWrapper>
  );
};

export default Commission;
