/**
 * @description 系统设置-字典管理
 */
import * as findById from './findById'
import * as pageList from './pageList'
import * as updateById from './updateById'

export { findById, pageList, updateById }
