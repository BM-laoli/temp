/**
     * @desc 查询公司主卡余额信息
切换主卡类型时调用
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PrincipalCardTopUpParameterClass): Promise<BaseResponse<defs.ResultBean<defs.PrincipalCardTopUpParameterClass>>> {
  return fetch({
    url: config.API_HOST + '/base/company/card/getMainCardBalanceInfo',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
