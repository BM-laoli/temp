/**
     * @desc 查询公司余额信息
查询公司余额信息
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.QueryParameterClassPrincipalCardAccount): Promise<BaseResponse<defs.ResultBean<defs.CardInfoExtObject>>> {
  return fetch({
    url: config.API_HOST + '/base/company/card/getMainCardAccountInfo',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
