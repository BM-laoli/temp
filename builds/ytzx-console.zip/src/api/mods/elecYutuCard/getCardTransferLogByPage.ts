/**
 * @desc 云途油卡转账列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.OilCardTransferDetailedQuery>): Promise<BaseResponse<defs.PageBean<Array<defs.CardTransferLogObject>>>> {
  return fetch({
    url: config.API_HOST + '/elecCard/yuTu/cardTransferByPage',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
