/*
 * @Author: TigerLord
 * @Date: 2022-10-08 13:55:44
 * @LastEditTime: 2022-12-27 16:51:16
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/api/mods/thirdOrgSet/findEnabledBindList.ts
 */
/**
 * @desc 查询未绑定的TheThirdPartyInstitution列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(): Promise<BaseResponse<defs.ResultBean<Array<defs.TheThirdPartyInstitution>>>> {
  return fetch({
    url: config.API_HOST + '/base/resThirdOrg/findEnabledBindList',
    data: undefined,
    method: 'POST',
    credentials: 'include',
    timeout: 180 * 1000,
  })
}
