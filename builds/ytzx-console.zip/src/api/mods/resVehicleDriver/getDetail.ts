/**
     * @desc 获取驾驶员Details
id
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 唯一id */
  id: number
}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean<defs.ThePilotOfNewParameterObject>>> {
  return fetch({
    url: config.API_HOST + '/base/driver/getDetail',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
