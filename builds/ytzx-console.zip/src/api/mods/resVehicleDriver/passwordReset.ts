/**
     * @desc 重置密码
重置驾驶员密码
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.UserIDParameter): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/base/driver/passwordReset',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
