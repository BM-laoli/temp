/**
 * @desc 加油橇对账Details接口
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<defs.ResultBean<Array<defs.TheReconciliationSubsidiaryEntities>>>> {
  return fetch({
    url: config.API_HOST + '/fuel/fee/refuelingSkidReconciliationDetail',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
