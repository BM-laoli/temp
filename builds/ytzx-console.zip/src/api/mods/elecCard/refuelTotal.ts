/**
 * @desc 油卡总览-ComeOnStatisticalchart
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.OilCardStatisticalQueryParameters): Promise<BaseResponse<defs.ResultBean<Array<defs.ComeOnStatistical>>>> {
  return fetch({
    url: config.API_HOST + '/card/overview/refuelTotal',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
