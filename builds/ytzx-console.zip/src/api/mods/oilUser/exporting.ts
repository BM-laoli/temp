/**
 * @desc 导出加油员列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: QueryParams): Promise<BaseResponse<any>> {
  return fetch({
    url: config.API_HOST + '/base/oilDriver/export',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
