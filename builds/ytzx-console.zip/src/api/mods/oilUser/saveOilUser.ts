/**
 * @desc 新增
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.TheOperatorsOfNewParameters): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/base/oilDriver/save',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
