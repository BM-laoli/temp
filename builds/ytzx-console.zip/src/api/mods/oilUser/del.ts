/**
 * @desc 删除
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.UserIDParameter): Promise<BaseResponse<defs.ResultBean<defs.TheNewCooperationCompanyParameters>>> {
  return fetch({
    url: config.API_HOST + '/base/oilDriver/del',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
