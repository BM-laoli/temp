/**
     * @desc 删除车辆信息
车辆id
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.IdParameter): Promise<BaseResponse<defs.ResultBean<defs.CompanyVehicleInformation>>> {
  return fetch({
    url: config.API_HOST + '/base/vehicle/del',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
