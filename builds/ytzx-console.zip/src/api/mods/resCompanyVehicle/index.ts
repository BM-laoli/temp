/**
 * @description 车辆管理
 */
import * as add from './add'
import * as del from './del'
import * as exporting from './exporting'
import * as getDetail from './getDetail'
import * as getListByCompanyIdOrDeptId from './getListByCompanyIdOrDeptId'
import * as getVehicleListByDeptId from './getVehicleListByDeptId'
import * as importFile from './importFile'
import * as pageList from './pageList'
import * as update from './update'

export { add, del, exporting, getDetail, getListByCompanyIdOrDeptId, getVehicleListByDeptId, importFile, pageList, update }
