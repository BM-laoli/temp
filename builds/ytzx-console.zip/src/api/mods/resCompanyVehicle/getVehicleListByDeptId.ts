/**
     * @desc 根据部门id查询无油卡的有驾驶员的车辆信息
id 部门id
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.AccordingToTheOrganizationOrDepartment): Promise<BaseResponse<defs.ResultBean<Array<defs.CompanyVehicleInformation>>>> {
  return fetch({
    url: config.API_HOST + '/base/vehicle/getVehicleListByDeptId',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
