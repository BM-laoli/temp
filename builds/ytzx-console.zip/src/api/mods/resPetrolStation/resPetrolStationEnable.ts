/**
 * @desc 加油站启用停用
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.ResPetrolStationEnableParams): Promise<BaseResponse<defs.ResultBean<number>>> {
  return fetch({
    url: config.API_HOST + '/base/resPetrolStation/resPetrolStationEnable',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
