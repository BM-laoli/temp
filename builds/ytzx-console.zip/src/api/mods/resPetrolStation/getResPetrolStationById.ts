/**
 * @desc 加油站Details
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 油站id */
  id?: number
}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean<defs.ResPetrolStationSaveParams>>> {
  return fetch({
    url: config.API_HOST + '/base/resPetrolStation/getDetail',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
