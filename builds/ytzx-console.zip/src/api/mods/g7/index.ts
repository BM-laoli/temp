/**
 * @description G 7 Controller
 */
import * as syncPetrolStations from './syncPetrolStations'

export { syncPetrolStations }
