/**
 * @desc manualNotify
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** gasId */
  gasId?: string
}

export function request(): Promise<BaseResponse<string>> {
  return fetch({
    url: config.API_HOST + '/groupOil/manualNotify',
    data: undefined,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
