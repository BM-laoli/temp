/**
 * @description Models信息管理
 */
import * as del from './del'
import * as getDetail from './getDetail'
import * as pageList from './pageList'
import * as save from './save'

export { del, getDetail, pageList, save }
