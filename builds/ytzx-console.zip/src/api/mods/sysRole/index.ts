/**
 * @description 系统设置-角色管理
 */
import * as remove from './remove'
import * as info from './info'
import * as pageList from './pageList'
import * as save from './save'
import * as select from './select'
import * as update from './update'

export { remove, info, pageList, save, select, update }
