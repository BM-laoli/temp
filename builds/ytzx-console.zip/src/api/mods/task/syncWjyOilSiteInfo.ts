/*
 * @Author: TigerLord
 * @Date: 2022-10-08 13:55:44
 * @LastEditTime: 2022-12-27 16:51:32
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/api/mods/task/syncWjyOilSiteInfo.ts
 */
/**
 * @desc 同步万金油  油站信息   全量
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/task/syncWjyOilSiteInfo',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 180 * 1000,
  })
}
