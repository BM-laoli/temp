/**
     * @desc 根据公司id查询车辆信息集合
公司id
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.AccordingToTheOrganizationOrDepartment): Promise<BaseResponse<defs.ResultBean<Array<defs.CompanyVehicleInformation>>>> {
  return fetch({
    url: config.API_HOST + '/statistics/getVehicleListByCompanyId',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
