/**
 * @desc 根据加油站名称模糊查询   查询加油站列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 加油站名称 */
  stationName?: string
}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean<Array<defs.PetrolStationNameEntity>>>> {
  return fetch({
    url: config.API_HOST + '/statistics/findPetrolListByFuzzyStationName',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
