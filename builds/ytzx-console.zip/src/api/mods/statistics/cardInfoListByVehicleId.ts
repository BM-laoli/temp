/**
     * @desc 根据车辆id查询油卡集合
车辆id
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.IdParameter): Promise<BaseResponse<defs.ResultBean<Array<defs.CloudElectronicOilClipCardObjects>>>> {
  return fetch({
    url: config.API_HOST + '/statistics/cardInfoListByVehicleId',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
