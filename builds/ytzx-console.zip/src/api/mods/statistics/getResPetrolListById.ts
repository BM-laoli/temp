/**
     * @desc 根据加油站id查询Oil集合
加油站id
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.IdParameter): Promise<BaseResponse<defs.ResultBean<defs.GasOil>>> {
  return fetch({
    url: config.API_HOST + '/statistics/getResPetrolListById',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
