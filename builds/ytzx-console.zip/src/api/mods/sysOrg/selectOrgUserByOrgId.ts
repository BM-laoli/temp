/**
 * @desc 选择公司人员(添加、修改菜单)
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.GroupIDParameter): Promise<BaseResponse<defs.ResultBean<Array<defs.SysUserEntityObject>>>> {
  return fetch({
    url: config.API_HOST + '/auth/org/selectOrgUserByOrgId',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
