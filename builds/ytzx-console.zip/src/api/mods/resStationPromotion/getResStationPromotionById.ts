/**
 * @desc 进入加油站优惠信息编辑页面
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 优惠信息id */
  id?: number
}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean<defs.ResStationPromotion>>> {
  return fetch({
    url: config.API_HOST + '/base/resStationPromotion/getResStationPromotionById',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
