/**
 * @description 商城商品
 */
import * as delGoods from './delGoods'
import * as getMallGoodsById from './getMallGoodsById'
import * as goodsPageList from './goodsPageList'
import * as saveGoods from './saveGoods'

export { delGoods, getMallGoodsById, goodsPageList, saveGoods }
