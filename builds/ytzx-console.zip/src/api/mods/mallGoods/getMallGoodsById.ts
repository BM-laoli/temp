/**
 * @desc 获取商品Details
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 商品id */
  goodsId?: number
}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean<defs.MallGoodsWithImg>>> {
  return fetch({
    url: config.API_HOST + '/mall/goods/getDetail',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
