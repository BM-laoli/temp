/**
 * @desc 导出列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 加油站id */
  stationId?: number
}

export function request(data: QueryParams): Promise<BaseResponse<any>> {
  return fetch({
    url: config.API_HOST + '/stationCommission/export',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
