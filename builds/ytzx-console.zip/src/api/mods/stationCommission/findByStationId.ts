/**
 * @desc 根据加油站查询加油站ACommissionSetUp
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.GasStationIDParameter): Promise<BaseResponse<defs.ResultBean<defs.CommissionSetUpDetails>>> {
  return fetch({
    url: config.API_HOST + '/stationCommission/findByStationId',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
