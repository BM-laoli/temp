/**
 * @description Star Controller
 */
import * as fetchStarOilSiteInfo from './fetchStarOilSiteInfo'
import * as syncPetrolStations from './syncPetrolStations'

export { fetchStarOilSiteInfo, syncPetrolStations }
