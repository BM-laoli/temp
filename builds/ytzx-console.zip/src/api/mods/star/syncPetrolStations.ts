/**
 * @desc syncPetrolStations
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.StarSyncCommonParams): Promise<BaseResponse<defs.StarRestResult>> {
  return fetch({
    url: config.API_HOST + '/star/syncPetrolStations',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
