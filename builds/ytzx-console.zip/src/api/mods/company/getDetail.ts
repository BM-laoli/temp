/**
     * @desc 获取公司Details
companyId
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 唯一id */
  companyId: number
}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean<defs.TheNewCooperationCompanyParameters>>> {
  return fetch({
    url: config.API_HOST + '/base/company/getDetail',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
