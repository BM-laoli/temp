/**
     * @desc 公司分页列表
where查询条件
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.CompanyPagingQueryParameters>): Promise<BaseResponse<defs.PageBean<Array<defs.ReturnsTheEntityManagementList>>>> {
  return fetch({
    url: config.API_HOST + '/base/company/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
