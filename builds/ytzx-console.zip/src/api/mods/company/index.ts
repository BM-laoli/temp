/**
 * @description 合作公司管理
 */
import * as add from './add'
import * as del from './del'
import * as disabledCompanyCard from './disabledCompanyCard'
import * as exporting from './exporting'
import * as getDetail from './getDetail'
import * as pageList from './pageList'
import * as update from './update'

export { add, del, disabledCompanyCard, exporting, getDetail, pageList, update }
