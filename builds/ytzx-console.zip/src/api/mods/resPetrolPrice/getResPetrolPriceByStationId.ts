/**
 * @desc 进入加油站油价信息编辑页面
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 油站id */
  stationId?: number
}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean<defs.ResPetrolPriceDto>>> {
  return fetch({
    url: config.API_HOST + '/base/resPetrolPrice/getDetailByStationId',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
