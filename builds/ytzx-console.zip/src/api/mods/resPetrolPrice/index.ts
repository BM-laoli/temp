/**
 * @description 加油站油价信息管理
 */
import * as getResPetrolPriceById from './getResPetrolPriceById'
import * as getResPetrolPriceByStationId from './getResPetrolPriceByStationId'
import * as resPetrolStationPricePage from './resPetrolStationPricePage'
import * as resPetrolPriceSave from './resPetrolPriceSave'

export { getResPetrolPriceById, getResPetrolPriceByStationId, resPetrolStationPricePage, resPetrolPriceSave }
