/**
 * @description 文件上传
 */
import * as uploadImg from './uploadImg'

export { uploadImg }
