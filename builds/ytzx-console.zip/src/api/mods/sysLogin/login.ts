/**
 * @desc 登录接口
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.LoginParameters): Promise<BaseResponse<defs.ResultBean<defs.TheLoginInformation>>> {
  return fetch({
    url: config.API_HOST + '/auth/login',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
