/**
 * @desc 选择车辆
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.AccordingToTheOrganizationOrDepartment): Promise<BaseResponse<defs.ResultBean<Array<defs.CompanyVehicleInformation>>>> {
  return fetch({
    url: config.API_HOST + '/shitiCard/yuTu/getVehicleListByDeptId',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
