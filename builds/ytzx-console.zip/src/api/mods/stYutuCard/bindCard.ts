/**
 * @desc 油卡分配
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PhysicalOilBindingLogCardVehicles): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/shitiCard/yuTu/bindCard',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
