/**
 * @desc 确认开票
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.ToMakeOutAnInvoice): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/invoice/agreeInvoice',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
