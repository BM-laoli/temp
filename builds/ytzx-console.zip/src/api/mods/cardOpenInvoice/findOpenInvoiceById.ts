/**
 * @desc 查询Details
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.IdParamsObject): Promise<BaseResponse<defs.ResultBean<defs.TheInformationOfMakeOutInvoice>>> {
  return fetch({
    url: config.API_HOST + '/invoice/findOpenInvoiceById',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
