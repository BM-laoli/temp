/**
 * @desc 用户信息
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.UserIDParameter): Promise<BaseResponse<defs.ResultBean<defs.SysUserEntityObject>>> {
  return fetch({
    url: config.API_HOST + '/auth/user/info/',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
