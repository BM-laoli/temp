/**
 * @desc 分页用户列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.UserPagingQueryParameters>): Promise<BaseResponse<defs.PageBean<Array<defs.SysUserEntityObject>>>> {
  return fetch({
    url: config.API_HOST + '/auth/user/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
