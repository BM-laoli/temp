/**
 * @description 系统设置-优惠信息管理
 */
import * as delById from './delById'
import * as findById from './findById'
import * as pageList from './pageList'
import * as save from './save'
import * as updateById from './updateById'

export { delById, findById, pageList, save, updateById }
