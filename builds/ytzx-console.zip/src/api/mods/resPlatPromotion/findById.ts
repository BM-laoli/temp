/**
 * @desc 根据ID查询优惠信息
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.IdParameter): Promise<BaseResponse<defs.ResultBean<defs.PreferentialInformationPlatform>>> {
  return fetch({
    url: config.API_HOST + '/base/platPromotion/findById',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
