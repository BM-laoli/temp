/**
 * @desc 查询地区列表根据城市编码
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.RegionEncodingParameters): Promise<BaseResponse<defs.ResultBean<Array<defs.Area>>>> {
  return fetch({
    url: config.API_HOST + '/dict/findRegionListByCity',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
