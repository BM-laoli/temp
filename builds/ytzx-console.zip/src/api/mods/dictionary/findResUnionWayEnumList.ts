/**
 * @desc 加盟方式枚举
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(): Promise<BaseResponse<defs.ResultBean<Array<defs.EnumVo>>>> {
  return fetch({
    url: config.API_HOST + '/dict/findResUnionWayEnumList',
    data: undefined,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
