/**
 * @desc 查询系统配置信息
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.SystemConfigurationQueryParameters): Promise<BaseResponse<defs.ResultBean<defs.SysConfigEntity>>> {
  return fetch({
    url: config.API_HOST + '/dict/findBySysConfigType',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
