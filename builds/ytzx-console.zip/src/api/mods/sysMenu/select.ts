/**
 * @desc 选择菜单(添加、修改菜单)
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(): Promise<BaseResponse<defs.ResultBean<Array<defs.SysMenuEntityObject>>>> {
  return fetch({
    url: config.API_HOST + '/auth/menu/select',
    data: undefined,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
