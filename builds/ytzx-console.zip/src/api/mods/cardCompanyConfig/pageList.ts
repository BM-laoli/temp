/**
     * @desc 分页授信校验列表
where查询条件
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.CreditTransactionsQueryConditions>): Promise<BaseResponse<defs.PageBean<Array<defs.CreditTransactionDetails>>>> {
  return fetch({
    url: config.API_HOST + '/base/credit/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
