/**
 * @desc 导出交易列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.CreditTransactionsQueryConditions): Promise<BaseResponse<any>> {
  return fetch({
    url: config.API_HOST + '/base/credit/export',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
