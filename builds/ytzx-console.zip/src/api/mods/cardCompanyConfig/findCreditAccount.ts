/**
     * @desc 查询额度Details以及账户统计
companyId
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 唯一id */
  companyId: number
}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean<defs.CreditAccount>>> {
  return fetch({
    url: config.API_HOST + '/base/credit/findCreditAccount',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
