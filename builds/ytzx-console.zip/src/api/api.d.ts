type ObjectMap<Key extends string | number | symbol = any, Value = any> = {
  [key in Key]: Value
}

declare namespace defs {
  export class ACommissionSetUp {
    /** id */
    id: number

    /** 是否启用 0-否 1-是 */
    isEnabled?: number
  }

  export class AccordingToTheOrganizationOrDepartment {
    /** 公司id */
    companyId?: number

    /** 部门id */
    deptId?: number

    /** 车辆ID */
    vehicleId?: number

    /** 车辆ID集合 */
    vehicleIds?: Array<number>
  }

  export class AllAccountInformation {
    /** 新增时间 */
    addTime?: string

    /** id */
    id?: number

    /** 操作人账号 */
    loginName?: string

    /** 操作时间 */
    opTime?: string

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** 剩余金额(分) */
    remainingSum?: number

    /** 总消费金额(分) */
    totalConsumeMoney?: number

    /** 总充值金额(分) */
    totalDepositMoney?: number
  }

  export class AllAccountTransactionHistory {
    /** 账户ID */
    accountId?: number

    /** 账户名称 1-万金油 2-G7 3-星油 */
    accountName?: string

    /** 新增时间 */
    addTime?: string

    /** 变化后剩余金额(分) */
    afterRemainingSum?: number

    /** 变化总金额(分) */
    afterTotalDeposit?: number

    /** 变化前剩余金额(分) */
    beforeRemainingSum?: number

    /** 变化前总金额(分) */
    beforeTotalDeposit?: number

    /** 变化类型 0-充值 1-消费 */
    changeType?: number

    /** 变化金额(分) */
    depositMoney?: number

    /** id */
    id?: number

    /** 操作人账号 */
    loginName?: string

    /** 操作时间 */
    opTime?: string

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** 订单流水号 */
    orderSerialNo?: string

    /** 备注 */
    remark?: string

    /** 第三方流水号 */
    thirdSerialNo?: string
  }

  export class Area {
    /** 下级 */
    children?: Array<defs.Area>

    /** Area编码 */
    regionCode?: string

    /** Area名称 */
    regionName?: string
  }

  export class AuthServiceIDParameter {
    /** id */
    id: number
  }

  export class BatchCommissionSet {
    /** 消费成功佣金千分比(‰) */
    consumeCommissionMoney: number

    /** 安装并注册成功佣金(分) */
    installCommissionMoney: number
  }

  export class BindingLog {
    /** 账号id */
    accountId?: number

    /** 新增时间 */
    addTime?: string

    /** 绑定设备 */
    bindingDevice?: string

    /** id */
    id?: number

    /** 登录名 */
    loginName?: string

    /** 操作类型 0-绑定 1-解绑 */
    opType?: number

    /** 操作时间 */
    operateTime?: string

    /** 操作人id */
    operatorId?: number

    /** 操作人 */
    operatorName?: string

    /** 用户id */
    userId?: number

    /** 用户类型 0-加油员 1-驾驶员 2-公司人员 */
    userType?: number
  }

  export class BookedParameters {
    /** 入账公司ID */
    companyId: number

    /** 入账金额 分 */
    money: number

    /** 备注 */
    remark: string
  }

  export class CardInfoExtObject {
    /** 新增时间 */
    addTime?: string

    /** 油卡平台 0-云途 1-G7 */
    cardPlatform?: number

    /** 卡是否存在密码 1-存在，0-不存在,如果不存在则需要先进行设置密码 */
    cardPsw?: number

    /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
    cardStatus?: number

    /** 油卡状态描述 */
    cardStatusDesc?: string

    /** 公司id */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 部门id */
    deptId?: number

    /** 部门名称 */
    deptName?: string

    /** 油卡Detailsid */
    detailId?: number

    /** 驾驶员id */
    driverId?: number

    /** 驾驶员姓名 */
    driverName?: string

    /** 即将过期的剩余油量2(ml) */
    expireRemainConsume2PetrolWarn?: number

    /** 即将过期的剩余油量(ml) */
    expireRemainConsumePetrolWarn?: number

    /** 半年累计消费2油量(ml) */
    halfYearConsume2Petrol?: number

    /** 累计消费金额(分) */
    halfYearConsumeMoney?: number

    /** 半年内消费油量(ml) */
    halfYearConsumePetrol?: number

    /** 卡ID */
    id?: number

    /** 是否主卡 0-否 1-是 */
    isPri?: number

    /** 是否主卡描述 */
    isPriDesc?: string

    /** 锁定2油量(ml) */
    lockRemaining2Petrol?: number

    /** 锁定油量(ml) */
    lockRemainingPetrol?: number

    /** 锁定金额(分) */
    lockRemainingSum?: number

    /** 登录名 */
    loginName?: string

    /** 开卡时间 */
    openTime?: string

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** 父id */
    parentId?: number

    /** Oil2id */
    petrol2Id?: number

    /** Oil2名称 */
    petrol2Name?: string

    /** 卡号 */
    petrolCardNum?: string

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardType?: number

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardTypeDesc?: string

    /** Oilid */
    petrolId?: number

    /** Oil名称 */
    petrolName?: string

    /** 剩余2油量(ml) */
    remaining2PetrolSum?: number

    /** 剩余油量(ml) */
    remainingPetrolSum?: number

    /** 余额(分) */
    remainingSum?: number

    /** 半年内消费2油量(ml) */
    totalConsume2Petrol?: number

    /** 累计消费金额(分) */
    totalConsumeMoney?: number

    /** 累计消费油量(ml) */
    totalConsumePetrol?: number

    /** 累计抵扣运费(分) */
    totalDeductionCost?: number

    /** 累计充值2油量(ml) */
    totalDeposit2Petrol?: number

    /** 累计充值金额(分) */
    totalDepositMoney?: number

    /** 累计充值油量(ml) */
    totalDepositPetrol?: number

    /** 车辆id */
    vehicleId?: number

    /** 车牌号 */
    vehicleNum?: string

    /** 车辆来源 0-后台添加 1-加盟 */
    vehicleSource?: number

    /** 车辆来源描述 */
    vehicleSourceDesc?: string

    /** 车辆类型 0-自有车辆 1-外协车辆 */
    vehicleType?: number

    /** 车辆类型描述 */
    vehicleTypeDesc?: string

    /** Modelsid */
    vehicleTypeId?: number

    /** Models名称 */
    vehicleTypeName?: string

    /** 云途油卡类型 0-个人云途油卡 1-公司云途油卡 2-非云途油卡 */
    ytCardType?: number

    /** 云途油卡类型描述 */
    ytCardTypeDesc?: string
  }

  export class CardPetrolDepositObject {
    /** 新增时间 */
    addTime?: string

    /** 订单号(业务交易流水号) */
    busiTradeNo?: string

    /** -35#柴油充值油量(ml) */
    change2Petrol?: number

    /** 0#柴油充值油量(ml) */
    changePetrol?: number

    /** 抵扣运费(分) */
    deductionCost?: number

    /** id */
    id?: number

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** -35#柴油Oilid */
    petrol2Id?: number

    /** -35#柴油Oil名称 */
    petrol2Name?: string

    /** 油卡id */
    petrolCardId?: number

    /** 卡号 */
    petrolCardNum?: string

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardType?: number

    /** petrolCardTypeDesc */
    petrolCardTypeDesc?: string

    /** 0#柴油Oilid */
    petrolId?: number

    /** 0#柴油Oil名称 */
    petrolName?: string

    /** 备注 */
    remark?: string

    /** 第三方交易流水号 */
    thirdTradeNo?: string

    /** 车辆id */
    vehicleId?: number
  }

  export class CardTransferLogObject {
    /** 转账金额(分) */
    changeMoney?: number

    /** id */
    id?: number

    /** 转账时间 */
    operateTime?: string

    /** 转出卡id */
    zcCardId?: number

    /** 转出卡号 */
    zcCardNum?: string

    /** 公司id */
    zcCompanyId?: number

    /** 公司名称 */
    zcCompanyName?: string

    /** 转出驾驶员id */
    zcDriverId?: number

    /** 转出驾驶员姓名 */
    zcDriverName?: string

    /** 转入卡id */
    zrCardId?: number

    /** 转入卡号 */
    zrCardNum?: string

    /** 公司id */
    zrCompanyId?: number

    /** 公司名称 */
    zrCompanyName?: string

    /** 转入驾驶员id */
    zrDriverId?: number

    /** 转入驾驶员姓名 */
    zrDriverName?: string
  }

  export class CloudElectronicOilClipCardObjects {
    /** 新增时间 */
    addTime?: string

    /** 油卡平台 0-云途 1-G7 */
    cardPlatform?: number

    /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
    cardStatus?: number

    /** 油卡状态描述 */
    cardStatusDesc?: string

    /** 公司id */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 部门id */
    deptId?: number

    /** 部门名称 */
    deptName?: string

    /** 驾驶员id */
    driverId?: number

    /** 驾驶员姓名 */
    driverName?: string

    /** 即将过期的剩余油量2(ml) */
    expireRemainConsume2PetrolWarn?: number

    /** 即将过期的剩余油量(ml) */
    expireRemainConsumePetrolWarn?: number

    /** 冻结余额(分) */
    freezeRemainingSum?: number

    /** 历史累计充值金额(分) */
    hisDepositMoney?: number

    /** id */
    id?: number

    /** 是否主卡 0-否 1-是 */
    isPri?: number

    /** 是否主卡描述 */
    isPriDesc?: string

    /** 登录名 */
    loginName?: string

    /** 开卡时间 */
    openTime?: string

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** 父id */
    parentId?: number

    /** 卡号 */
    petrolCardNum?: string

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardType?: number

    /** 油卡类型描述 */
    petrolCardTypeDesc?: string

    /** 退款金额(分) */
    refundMoney?: number

    /** （车队油卡）剩余2油量(ml) */
    remaining2PetrolSum?: number

    /** （车队油卡）剩余油量(ml) */
    remainingPetrolSum?: number

    /** 余额(分) */
    remainingSum?: number

    /** 回退金额(分) */
    returnMoney?: number

    /** 累计消费金额(分) */
    totalConsumeMoney?: number

    /** 累计充值金额(分) */
    totalDepositMoney?: number

    /** 车辆id */
    vehicleId?: number

    /** 车牌号 */
    vehicleNum?: string

    /** 车辆来源 0-后台添加 1-加盟 */
    vehicleSource?: number

    /** 车辆来源描述 */
    vehicleSourceDesc?: string

    /** 车辆类型 0-自有车辆 1-外协车辆 */
    vehicleType?: number

    /** 车辆类型描述 */
    vehicleTypeDesc?: string

    /** Modelsid */
    vehicleTypeId?: number

    /** Models名称 */
    vehicleTypeName?: string

    /** 云途油卡类型 0-个人云途油卡 1-公司云途油卡 2-非云途油卡 */
    ytCardType?: number

    /** 云途油卡类型描述 */
    ytCardTypeDesc?: string
  }

  export class CloudOilCardChangeDetailParameters {
    /** 变更类型 0-充值 1-消费 2-划拨 */
    changeType?: number

    /** 公司id */
    companyId?: number

    /** 部门id */
    deptId?: number

    /** 结束日期 yyyy-MM-dd */
    endDate?: string

    /** 结束日期 yyyy-MM-dd HH:mm:ss */
    endTime?: string

    /** 结束日期 yyyy-MM-dd HH:mm:ss */
    endTimeStr?: string

    /** 卡id */
    petrolCardId?: number

    /** 开始日期 yyyy-MM-dd */
    startDate?: string

    /** 开始时间 yyyy-MM-dd HH:mm:ss */
    startTime?: string

    /** 开始时间 yyyy-MM-dd HH:mm:ss */
    startTimeStr?: string

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
    stationSource?: number

    /** 车牌号 */
    vehicleNum?: string
  }

  export class CloudOilCardChangeObjects {
    /** 新增时间 */
    addTime?: string

    /** 变更后金额(分) */
    afterMoney?: number

    /** 变更前金额(分) */
    beforeMoney?: number

    /** 业务交易流水号 */
    busiTradeNo?: string

    /** 变更金额(分) */
    changeMoney?: number

    /** 变更油量(ml) */
    changePetrol?: number

    /** 变更类型 0-充值 1-消费 2-划出 3-划入 4-转出 5-转入 */
    changeType?: number

    /** 变更类型 0-充值 1-消费 2-划出 3-划入 4-转出 5-转入 */
    changeTypeDesc?: string

    /** 公司id */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 充值方式 0-后台充值 1-支付宝 2-微信 */
    depositWay?: number

    /** 充值方式 0-后台充值 1-支付宝 2-微信 */
    depositWayDesc?: string

    /** 部门ID */
    deptId?: number

    /** 部门名称 */
    deptName?: string

    /** 驾驶员名称 */
    driverName?: string

    /** id */
    id?: number

    /** 操作时间 */
    operateTime?: string

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** 油卡id */
    petrolCardId?: number

    /** 油卡卡号 */
    petrolCardNum?: string

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardType?: number

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardTypeDesc?: string

    /** Oilid */
    petrolId?: number

    /** Oil名称 */
    petrolName?: string

    /** 主卡id */
    priCardId?: number

    /** 主卡卡号 */
    priCardNum?: string

    /** 备注 */
    remark?: string

    /** 加油站id */
    stationId?: number

    /** 加油站名称 */
    stationName?: string

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
    stationSource?: number

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
    stationSourceDesc?: string

    /** 第三方交易流水号 */
    thirdTradeNo?: string

    /** 交易卡ID */
    transCardId?: number

    /** 交易卡号 */
    transCardNum?: string

    /** 车牌号 */
    vehicleNum?: string
  }

  export class CloudOilCardMasterCardParameters {
    /** 卡Id */
    cardId: number

    /** 充值金额(分) */
    depositMoney: number
  }

  export class CloudOilClipCardTopParameters {
    /** 卡Id */
    cardId: number

    /** 充值金额(分) */
    depositMoney: number
  }

  export class ComeOnDetail {
    /** 新增时间 */
    addTime?: string

    /** 业务交易流水号 */
    busiTradeNo?: string

    /** 变更金额(分) */
    changeMoney?: number

    /** 变更油量(ml) */
    changePetrol?: number

    /** 变更类型 0-充值 1-消费 2-划出 3-划入 4-转出 5-转入 */
    changeType?: number

    /** 变更类型 0-充值 1-消费 2-划出 3-划入 4-转出 5-转入 */
    changeTypeDesc?: string

    /** 公司id */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 充值方式 0-后台充值 1-支付宝 2-微信 */
    depositWay?: number

    /** 充值方式 0-后台充值 1-支付宝 2-微信 */
    depositWayDesc?: string

    /** 加油撬编号 */
    deviceCode?: string

    /** 加油撬id */
    deviceId?: number

    /** id */
    id?: number

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** 油卡id */
    petrolCardId?: number

    /** 油卡卡号 */
    petrolCardNum?: string

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardType?: number

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardTypeDesc?: string

    /** Oilid */
    petrolId?: number

    /** Oil名称 */
    petrolName?: string

    /** 主卡id */
    priCardId?: number

    /** 主卡卡号 */
    priCardNum?: string

    /** 备注 */
    remark?: string

    /** 加油站id */
    stationId?: number

    /** 加油站名称 */
    stationName?: string

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
    stationSource?: number

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
    stationSourceDesc?: string

    /** 第三方交易流水号 */
    thirdTradeNo?: string
  }

  export class ComeOnMemberID {
    /** ComeOnMemberID */
    referee?: number
  }

  export class ComeOnReconciliationPageListsCompany {
    /** 加油金额/抵扣运费（元） */
    actTotalPrice?: string

    /** 适用油卡 */
    cardTypeName?: string

    /** 公司id */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 对账月份 */
    dateTime?: string

    /** 加油橇编号 */
    deviceCode?: string

    /** 加油橇id */
    deviceId?: number

    /** 油卡类型 */
    petrolCardType?: number

    /** 加油型号 */
    petrolNames?: string

    /** 油站id */
    stationId?: number

    /** 油站名称 */
    stationName?: string

    /** 加油站来源 */
    stationSource?: number

    /** 加油站来源 中文 */
    stationSourceDesc?: string
  }

  export class ComeOnReconciliationQueryParameters {
    /** 卡号 */
    cardNum?: string

    /** 油卡类型 */
    cardType?: number

    /** 地市编码 */
    cityCode?: string

    /** 公司id，公司对账不能为空 */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 对账月份  yyyy-MM */
    dateTime?: string

    /** 部门ID */
    deptId?: number

    /** 部门名称 */
    deptName?: string

    /** 加油橇编号 */
    deviceCode?: string

    /** 加油橇id，加油橇对账Details不能为空 */
    deviceId?: number

    /** 结束日期 */
    endDate?: string

    /** 月份 */
    month?: number

    /** 操作类型 0-充值 1-消费 2-退款 */
    opType?: number

    /** 订单号 */
    orderSerialNo?: string

    /** Oil型号id */
    petrolId?: number

    /** 加油型号 */
    petrolName?: number

    /** 省份编码 */
    provinceCode?: number

    /** 区县编码 */
    regionCode?: string

    /** 开始日期 */
    startDate?: string

    /** 加油站id，加油站对账不能为空 */
    stationId?: number

    /** 油站名称 */
    stationName?: string

    /** 加油站来源 */
    stationSource: number

    /** 车牌号 */
    vehicleNum?: string

    /** 年份 */
    year?: number
  }

  export class ComeOnStatistical {
    /** 加油量  ml */
    data?: number

    /** 加油时间 */
    date?: string
  }

  export class ComeOnStatisticalQueryParameters {
    /** 卡号 */
    cardNum?: string

    /** 油卡类型 0-车队油卡 1-云图油卡 2-实体油卡 */
    cardType?: number

    /** 是否核销 0-否 1-是 2无需核销 */
    checkStatus?: number

    /** 地市编码 */
    cityCode?: string

    /** 公司名称 */
    companyName?: string

    /** 订单结束日期 */
    endDate?: string

    /** 支付完成结束日期 */
    endPayFinishedDate?: string

    /** 退款完成结束日期 */
    endRefundFinishedDate?: string

    /** 是否时万金油对账界面 */
    isWJY: number

    /** 订单号 */
    orderSerialNo?: string

    /** 订单状态 0-待支付 1-已完成 3-已退款 */
    orderStatus?: number

    /** 支付状态 支付状态 0-待支付 1-支付中 2-已支付 3-支付失败 4-退款中 5-已退款 6-待发送确认 */
    payStatus?: number

    /** Oil类型ID 字典数据 */
    petrolId?: number

    /** 省份编码 */
    provinceCode?: number

    /** 区县编码 */
    regionCode?: string

    /** 订单开始日期 */
    startDate?: string

    /** 支付完成开始日期 */
    startPayFinishedDate?: string

    /** 退款完成开始日期 */
    startRefundFinishedDate?: string

    /** 加油站名称 */
    stationName?: string

    /** 油站所属 0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
    stationSource?: number

    /** 第三方订单号 */
    thirdSerialNo?: string

    /** 交易方式 0-司机出示二维码(加油员扫码) 1-司机主动支付  3 补单 */
    tradeType?: number

    /** 车牌号 */
    vehicleNum?: string
  }

  export class ComeOnStatisticsPagingInformationCompany {
    /** 实付消费总价(分) */
    actTotalPrice?: number

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    cardType?: number

    /** 卡类型 */
    cardTypeDesc?: string

    /** 公司id */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 日期 */
    dateStr?: string

    /** 结束时间 */
    endTime?: string

    /** 实际油量(ml) */
    petrolCount?: number

    /** OilID */
    petrolId?: number

    /** Oil名称 */
    petrolName?: string

    /** 开始时间 */
    startTime?: string

    /** 加油站id */
    stationId?: number

    /** 加油站名称 */
    stationName?: string

    /** 加油站来源 */
    stationSource?: number

    /** 加油站来源 */
    stationSourceDesc?: string
  }

  export class ComeOnTheOverviewScreenObjects {
    /** 加油总量排名前10的加油站 */
    chartBarDto?: defs.HistogramDataReturnObjects

    /** 加油总量排名前10的公司 */
    chartLineDto?: defs.TheLineChartDataReturnObjects

    /** 加油总量排名前10的加油站 */
    chartLineSingleDto?: defs.TheLineChartDataReturnObjects

    /** 合作公司数 */
    companyHeadVo?: defs.RefuelingOverviewHeadFuelStatistics

    /** 累计加油量 */
    fuelChargeHeadVo?: defs.RefuelingOverviewHeadFuelStatistics

    /** 合作加油站数 */
    stationHeadVo?: defs.RefuelingOverviewHeadFuelStatistics
  }

  export class CommissionChangeParameters {
    /** 佣金金额 单位:分 */
    commissionMoney: number

    /** ComeOnMemberID PC需要端传入ID， APP需要后端获取ID */
    referee?: number
  }

  export class CommissionManagement {
    /** 推荐人数 */
    refereeNum?: number

    /** 剩余金额(分) */
    remainingCommision?: number

    /** 所属加油站 */
    stationName?: string

    /** 提现金额(分) */
    totalCashOut?: number

    /** 累计佣金总额(分) */
    totalCommissionMoney?: number

    /** 累计加油金额(分) */
    totalOilMoney?: number

    /** ComeOnMemberID */
    userId?: number

    /** 加油员名称 */
    userName?: string
  }

  export class CommissionManagementPagingQueryParameters {
    /** 加油站名称 */
    stationName?: string

    /** 加油员名称 */
    userName?: string
  }

  export class CommissionSetList {
    /** 新增时间 */
    addTime?: string

    /** 消费成功佣金千分比(‰) */
    consumeCommissionMoney?: number

    /** 安装并注册成功佣金(分) */
    installCommissionMoney?: number

    /** 是否启用 0-否 1-是 */
    isEnabled?: number

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** 加油站id */
    stationId?: number

    /** 加油站名称 */
    stationName?: string
  }

  export class CommissionSetThePagingQueryParameters {
    /** 加油站id */
    stationId?: number
  }

  export class CommissionSetUpDetails {
    /** 消费成功佣金千分比(‰) */
    consumeCommissionMoney: number

    /** 安装并注册成功佣金(分) */
    installCommissionMoney: number

    /** 加油站id */
    stationId: number

    /** 加油站名称 */
    stationName: string
  }

  export class CommissionSetUpToModifyParameters {
    /** 消费成功佣金千分比(‰) */
    consumeCommissionMoney: number

    /** 安装并注册成功佣金(分) */
    installCommissionMoney: number

    /** 加油站id */
    stationId: number
  }

  export class CompanyComeOnStatisticalPagingConditions {
    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    cardType?: number

    /** 城市编码 */
    cityCode?: string

    /** 公司id */
    companyId?: number

    /** 结束日期 格式:yyyy-MM-dd 23:59:59 */
    endTime?: string

    /** Oil类型ID 字典数据 */
    petrolId?: number

    /** Oil名称 */
    petrolName?: string

    /** 省份编码 */
    provinceCode?: string

    /** 地区编码 */
    regionCode?: string

    /** 开始日期 格式:yyyy-MM-dd 00:00:00 */
    startTime?: string

    /** 油站来源 */
    stationSource?: number
  }

  export class CompanyComeOnStatisticalSubsidiaryConditions {
    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    cardType: number

    /** 公司ID */
    companyId: number

    /** 结束日期 格式:yyyy-MM-dd 23:59:59 */
    endTime: string

    /** OilID */
    petrolId?: number

    /** Oil名称 */
    petrolName?: string

    /** 开始日期 格式:yyyy-MM-dd 00:00:00 */
    startTime: string

    /** 加油站ID */
    stationId?: number

    /** 加油站名称 */
    stationName?: string
  }

  export class CompanyPagingQueryParameters {
    /** 地市编码 */
    cityCode?: string

    /** 公司ID */
    orgId?: number

    /** 公司名称 */
    orgName?: string

    /** 组织类型 0公司 1部门 */
    orgType?: number

    /** 省份编码 */
    provinceCode?: string

    /** 区县编码 */
    regionCode?: string
  }

  export class CompanyUsersToModifyParameters {
    /** 状态  0：禁用   1：正常 */
    accountStatus: number

    /** 所属公司id */
    companyId: number

    /** 所属公司名称 */
    companyName: string

    /** 手机号 */
    contactPhone: string

    /** 所属部门id */
    deptId: number

    /** 所属部门名称 */
    deptName: string

    /** 图片地址 */
    headImgAddr: string

    /** 图片ID */
    headImgId: string

    /** 用户帐号 */
    loginName: string

    /** 角色ID列表 */
    roleIdList: Array<number>

    /** 用户ID */
    userId: number

    /** 用户姓名 */
    userName: string
  }

  export class CompanyVehicleInformation {
    /** 新增时间 */
    addTime?: string

    /** 公司id */
    companyId: number

    /** 公司名称 */
    companyName: string

    /** 部门id */
    deptId: number

    /** 部门名称 */
    deptName: string

    /** 驾驶员ID */
    driverId?: number

    /** 驾驶员名称 */
    driverName?: string

    /** id,修改时必填 */
    id: number

    /** 是否默认车辆 0-否 1-是 */
    isDefault?: number

    /** 是否删除  0-否 1-是 */
    isDeleted?: number

    /** 驾驶员登录名 */
    loginName?: string

    /** 油卡类型 多个用英文逗号隔开 */
    petrolCardTypes: string

    /** OilID集合 */
    petrolIds: string

    /** Oil名称集合 */
    petrolNames: string

    /** Oil类型 0-柴油 1-汽油 2-天然气 */
    petrolTypeName?: string

    /** 车辆Oil集合 */
    resVehiclePetrols?: Array<defs.VehicleProductInformation>

    /** 车牌号 */
    vehicleNum: string

    /** 车辆来源 0-后台添加 1-加盟 */
    vehicleSource: number

    /** 车辆来源 0-后台添加 1-加盟 */
    vehicleSourceName?: string

    /** 车辆类型 0-自有车辆 1-外协车辆 */
    vehicleType: number

    /** 车辆类型 */
    vehicleTypeDesc?: string

    /** Modelsid */
    vehicleTypeId: number

    /** Models名称 */
    vehicleTypeName: string
  }

  export class CorporateUsersOfNewParameters {
    /** 状态  0：禁用   1：正常 */
    accountStatus: number

    /** 所属公司id */
    companyId: number

    /** 所属公司名称 */
    companyName: string

    /** 手机号 */
    contactPhone: string

    /** 所属部门id */
    deptId: number

    /** 所属部门名称 */
    deptName: string

    /** 图片地址 */
    headImgAddr: string

    /** 图片ID */
    headImgId: string

    /** 用户帐号 */
    loginName: string

    /** 角色ID列表 */
    roleIdList: Array<number>

    /** 用户姓名 */
    userName: string
  }

  export class CreditAccount {
    /** 授信额度 分 */
    creditLine?: number

    /** 授信余额 分 */
    creditRemainingLine?: number

    /** 入账金额 分 */
    inMoney?: number

    /** 消费金额 分 */
    totalConsumeMoney?: number
  }

  export class CreditTransactionDetails {
    /** 交易时间 */
    addTime?: string

    /** 交易金额 分 */
    changeMoney?: number

    /** 交易类型 1消费 12入账 */
    changeType?: number

    /** 交易类型描述 1消费 12入账 */
    changeTypeDesc?: string

    /** id */
    id?: number

    /** 操作人名称 */
    operatorName?: string

    /** 交易卡号 */
    petrolCardNum?: string

    /** 备注 */
    remark?: string
  }

  export class CreditTransactionsQueryConditions {
    /** 交易类型 1消费 12入账 */
    changeType?: number

    /** 公司ID */
    companyId: number

    /** 结束日期 yyyy-MM-dd */
    endDate?: string

    /** 结束日期 yyyy-MM-dd HH:mm:ss */
    endTime?: string

    /** 结束日期 yyyy-MM-dd HH:mm:ss */
    endTimeStr?: string

    /** 操作人 */
    operatorName?: string

    /** 交易卡号 */
    petrolCardNum?: string

    /** 开始日期 yyyy-MM-dd */
    startDate?: string

    /** 开始时间 yyyy-MM-dd HH:mm:ss */
    startTime?: string

    /** 开始时间 yyyy-MM-dd HH:mm:ss */
    startTimeStr?: string
  }

  export class DeleteTheParameterInARelease {
    /** id */
    id: number

    /** 是否管理员 0-否 1-是 */
    isAdmin?: number
  }

  export class DepartmentOfNewParameters {
    /** 联系人姓名 */
    contactName: string

    /** 联系人电话 */
    contactPhone: string

    /** 名称 */
    orgName: string

    /** 父级ID */
    parentOrgId: number
  }

  export class DepartmentToModifyParameters {
    /** 联系人姓名 */
    contactName: string

    /** 联系人电话 */
    contactPhone: string

    /** 组织ID */
    orgId: number

    /** 名称 */
    orgName: string

    /** 父级ID */
    parentOrgId: number
  }

  export class DetailedListOfMakeOutInvoice {
    /** 实付消费总价(分) */
    actTotalPrice?: number

    /** 申请人姓名 */
    applicantName?: string

    /** 申请时间 */
    applyTime?: string

    /** id */
    id?: number

    /** 开票id */
    openInvoiceId?: number

    /** 订单ID */
    orderId?: number

    /** 订单流水号 */
    orderSerialNo?: string

    /** 订单时间 */
    orderTime?: string

    /** Oil名称 */
    petrolName?: string

    /** 加油站名称 */
    stationName?: string

    /** 车牌号 */
    vehicleNum?: string

    /** Models名称 */
    vehicleTypeName?: string
  }

  export class Details {
    /** 新增时间 */
    addTime?: string

    /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
    checkStatus?: number

    /** 审核时间 */
    checkTime?: string

    /** 审核人id */
    checkUserId?: number

    /** 审核人姓名 */
    checkUserName?: string

    /** 审核人手机号 */
    checkUserPhone?: string

    /** 发布内容 */
    content?: string

    /** id */
    id?: number

    /** 是否自己发布的数据 0否 1是 */
    isSelfPublish?: number

    /** 发布时间 */
    publishTime?: string

    /** 附件列表 */
    resPublishAppendixList?: Array<defs.ReleaseInformationAttachment>

    /** 发布人id */
    userId?: number

    /** 发布人姓名 */
    userName?: string

    /** 发布人手机 */
    userPhone?: string
  }

  export class ElectronicOilCardQueryObject {
    /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
    cardStatus?: number

    /** 公司Id */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 部门id */
    deptId?: number

    /** 部门名称 */
    deptName?: string

    /** 登录名 */
    loginName?: string

    /** 卡号 */
    petrolCardNum?: string

    /** 油卡类型 */
    petrolCardType?: number

    /** 车牌号 */
    vehicleNum?: string

    /** 车辆类型 0-自有车辆 1-外协车辆 */
    vehicleType?: number
  }

  export class ElectronicOilCardStatistics {
    /** 实体油卡总数量 张 */
    entityCardTotalNum?: number

    /** 实体油卡已使用 (分) */
    entityConsumeTotalMoney?: number

    /** 实体油卡加盟公司 (个) */
    entityJoinCompanyNum?: number

    /** 实体油卡已充值(分) */
    entityTotalRechargeMoney?: number

    /** 本月加盟车辆同比上月 (%) */
    monthJoinVehicleRate?: number

    /** 本月加盟车辆  辆 */
    monthJoinVehicleTotal?: number

    /** 本月加油总量同比上月 (%) */
    monthReFuelRate?: number

    /** 本月加油总量  ml */
    monthRefuelTotal?: number

    /** 车队油卡总数量 张 */
    vehicleCardTotalNum?: number

    /** 车队油卡已加油 ml */
    vehicleConsumePetrolTotal?: number

    /** 车队油卡订单数 单 */
    vehicleOrderTotal?: number

    /** 车队油卡累计抵扣运费(分) */
    vehicleTotalDeductionCost?: number

    /** 车队油卡未使用 张 */
    vehicleUnusedTotalNum?: number

    /** 车队油卡已使用 张 */
    vehicleUsedTotalNum?: number

    /** 本周加盟车辆同比上月 (%) */
    weekJoinVehicleRate?: number

    /** 本周加盟车辆  辆 */
    weekJoinVehicleTotal?: number

    /** 本周加油总量同比上月 (%) */
    weekReFuelRate?: number

    /** 本周加油总量  ml */
    weekRefuelTotal?: number

    /** 云途油卡已使用 (分) */
    yuntuConsumeTotalMoney?: number

    /** 云途油卡加盟公司  (个) */
    yuntuJoinCompanyNum?: number

    /** 云途油卡总数量 张 */
    yutuCardTotalNum?: number
  }

  export class EnumVo {
    /** 编码 */
    code?: object

    /** 描述 */
    desc?: string

    /** 名称 */
    name?: string
  }

  export class ExtractTheCommissionRecord {
    /** 新增时间 */
    addTime?: string

    /** 提现后剩余佣金(分) */
    afterRemainingCommision?: number

    /** 总提现佣金(分) */
    applyTime?: string

    /** 提现前剩余佣金(分) */
    beforeRemainingCommision?: number

    /** 提现佣金(分) */
    cashOutCommision?: number

    /** id */
    id?: number

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** 推荐人id */
    referee?: number

    /** 推荐人加油站id */
    refereeStationId?: number

    /** 加油站名称 */
    stationName?: string

    /** 总提现佣金(分) */
    totalCashOut?: number

    /** 用户姓名 */
    userName?: string
  }

  export class FileUploadResponse {
    /** 文件ID */
    fileId?: string

    /** 文件名 */
    fileName?: string

    /** 文件路径 */
    filePath?: string

    /** 文件类型 */
    fileType?: string

    /** 文件http请求地址 */
    httpUrl?: string

    /** 访问文件的时效性 */
    token?: string
  }

  export class FillOneParameter {
    /** 油卡id */
    cardId: number

    /** 加油撬设备ID */
    deviceId?: number

    /** 加油枪ID */
    gunId?: number

    /** 油量(ml) */
    petrolCount?: number

    /** Oilid */
    petrolId: number

    /** Oil名称 */
    petrolName: string

    /** 价格（分） */
    price?: number

    /** 加油站id */
    stationId: number
  }

  export class G7RestResult {
    /** code */
    code?: number

    /** data */
    data?: object

    /** msg */
    msg?: string
  }

  export class GasOil {
    /** 加油枪信息 */
    resStation2GunList?: Array<defs.ResStation2GunObject>

    /** GasOil信息 */
    station2PetrolList?: Array<defs.ResStation2PetrolObject>

    /** 加油站加油撬信息 */
    stationDeviceList?: Array<defs.ResStationDeviceObject>

    /** 0 GasOil 1加油撬 2加油枪 */
    type?: number
  }

  export class GasStationAccountParameters {
    /** 返点(分)比例 */
    rebateRate?: number

    /** 账户充值(分) */
    rechargeMoney?: number

    /** 加油站id */
    stationId?: number
  }

  export class GasStationCollation {
    /** 新增时间 */
    addTime?: string

    /** 规则id */
    id?: number

    /** 启用  0-停用 1-启用 */
    isEnabled?: number

    /** 规则名称 */
    ruleName?: string
  }

  export class GasStationIDParameter {
    /** 加油站ID */
    stationId: number
  }

  export class GroupIDParameter {
    /** id */
    orgId: number
  }

  export class HistogramDataReturnObjects {
    /** xline */
    xline?: Array<string>

    /** yline */
    yline?: Array<number>
  }

  export class IdParameter {
    /** id */
    id: number
  }

  export class IdParamsObject {
    /** 查询对应的Id */
    id: number
  }

  export class JoinThePagingParametersList {
    /** 申请结束时间 yyyy-MM-dd HH:mm:ss */
    applyEndTime?: string

    /** 申请开始时间 yyyy-MM-dd HH:mm:ss */
    applyStartTime?: string

    /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
    auditStatus?: number

    /** 电话号码 */
    contactPhone?: string

    /** 驾驶员 */
    userName?: string

    /** 车牌号 */
    vehicleNum?: string
  }

  export class LoginParameters {
    /** 终端系统类型 1-ios 2-android 3-winphone  4-其他 */
    appOs?: number

    /** app系统类型 */
    appVersion?: string

    /** 绑定设备 */
    bindingDevice?: string

    /** 登录账号 */
    loginName: string

    /** 终端品牌 */
    osBrand?: string

    /** 终端型号 */
    osModel?: string

    /** 终端系统版本 */
    osVersion?: string

    /** 登录密码 */
    password: string

    /** 终端推送token */
    pushToken?: string

    /** 用户类型 0-加油员 1-驾驶员 2-公司人员 */
    userType?: number
  }

  export class MallGoods {
    /** 新增时间 */
    addTime?: string

    /** 商品简介 */
    goodsDesc?: string

    /** 商品名称 */
    goodsName?: string

    /** 商品积分 */
    goodsPoints?: number

    /** id */
    id?: number

    /** 是否删除  0-否 1-是 */
    isDeleted?: number

    /** 是否上架 0-否 1-是 */
    isOnline?: number
  }

  export class MallGoodsImg {
    /** 新增时间 */
    addTime?: string

    /** 大图地址 */
    bigImgAddr?: string

    /** 大图id */
    bigImgId?: string

    /** 商品id */
    goodsId?: number

    /** id */
    id?: number

    /** 小图地址 */
    smallImgAddr?: string

    /** 小图id */
    smallImgId?: string
  }

  export class MallGoodsPageQueryParams {
    /** 结束积分 */
    endPoints?: number

    /** 商品名称 */
    goodsName?: string

    /** 商品积分 */
    goodsPoints?: number

    /** 是否上架 0-否 1-是 */
    isOnline?: number

    /** 开始积分 */
    startPoints?: number
  }

  export class MallGoodsWithImg {
    /** 新增时间 */
    addTime?: string

    /** 商品简介 */
    goodsDesc?: string

    /** 商品图片列表 */
    goodsImgs?: Array<defs.MallGoodsImg>

    /** 商品名称 */
    goodsName?: string

    /** 商品积分 */
    goodsPoints?: number

    /** id */
    id?: number

    /** 是否删除  0-否 1-是 */
    isDeleted?: number

    /** 是否上架 0-否 1-是 */
    isOnline?: number
  }

  export class MallOrder {
    /** 新增时间 */
    addTime?: string

    /** 新增时间 */
    addTimeStr?: string

    /** 地址id */
    addrId?: number

    /** 申请退款时间 */
    applyRefundTime?: string

    /** 申请退款时间 */
    applyRefundTimeStr?: string

    /** 地市编码 */
    cityCode?: string

    /** 地市名称 */
    cityName?: string

    /** 联系电话 */
    contactPhone?: string

    /** 处理时间 */
    dealTime?: string

    /** 处理时间 */
    dealTimeStr?: string

    /** 详细地址 */
    detailAddr?: string

    /** id */
    id?: number

    /** 是否已处理 0-否 1-是 */
    isDeal?: number

    /** isDealStr */
    isDealStr?: string

    /** 订单商品列表 */
    orderList?: Array<defs.MallOrderGoods>

    /** 订单流水号 */
    orderSerialNo?: string

    /** 订单状态 0-正常 1-已完成 2-已取消 */
    orderStatus?: number

    /** orderStatusStr */
    orderStatusStr?: string

    /** 订单时间 */
    orderTime?: string

    /** 订单时间 */
    orderTimeStr?: string

    /** 支付状态 0-待支付 1-已支付 2-退款中 3-已退款 */
    payStatus?: number

    /** payStatusStr */
    payStatusStr?: string

    /** 支付时间 */
    payTime?: string

    /** 支付时间 */
    payTimeStr?: string

    /** 支付方式 0-积分 1-微信 2-支付宝 */
    payWay?: number

    /** payWayStr */
    payWayStr?: string

    /** 省份编码 */
    provinceCode?: string

    /** 省份名称 */
    provinceName?: string

    /** 退款时间 */
    refundTime?: string

    /** 退款时间 */
    refundTimeStr?: string

    /** 区县编码 */
    regionCode?: string

    /** 区县名称 */
    regionName?: string

    /** 总积分 */
    totalPoints?: number

    /** 总金额(分) */
    totalPrice?: number

    /** 用户id */
    userId?: number

    /** 用户姓名 */
    userName?: string
  }

  export class MallOrderApplyParams {
    /** 地址id */
    addrId?: number

    /** 订单商品列表 */
    orderApplyList?: Array<defs.MallOrderGoodsParams>
  }

  export class MallOrderDealParams {
    /** 订单id */
    orderId?: number
  }

  export class MallOrderGoods {
    /** 新增时间 */
    addTime?: string

    /** 新增时间 */
    addTimeStr?: string

    /** 商品数量 */
    goodsCnt?: number

    /** 商品id */
    goodsId?: number

    /** 商品名称 */
    goodsName?: string

    /** 商品积分 */
    goodsPoints?: number

    /** 商品单价(分) */
    goodsPrice?: number

    /** id */
    id?: number

    /** 订单id */
    orderId?: number

    /** 订单商品图片列表 */
    orderImgList?: Array<defs.MallOrderImg>
  }

  export class MallOrderGoodsParams {
    /** 商品数量 */
    goodsCnt?: number

    /** 商品id */
    goodsId?: number
  }

  export class MallOrderImg {
    /** 新增时间 */
    addTime?: string

    /** 新增时间 */
    addTimeStr?: string

    /** 大图地址 */
    bigImgAddr?: string

    /** 大图id */
    bigImgId?: string

    /** id */
    id?: number

    /** 订单商品id */
    orderGoodsId?: number

    /** 小图地址 */
    smallImgAddr?: string

    /** 小图id */
    smallImgId?: string
  }

  export class MallOrderPageQueryParams {
    /** 新增时间 */
    addTime?: string

    /** 申请退款时间 */
    applyRefundTime?: string

    /** 地市编码 */
    cityCode?: string

    /** 地市名称 */
    cityName?: string

    /** 联系电话 */
    contactPhone?: string

    /** 处理时间 */
    dealTime?: string

    /** 详细地址 */
    detailAddr?: string

    /** 结束积分 */
    endPoints?: number

    /** 商品名称 */
    goodsName?: string

    /** 是否已处理 0-否 1-是 */
    isDeal?: number

    /** isDealStr */
    isDealStr?: string

    /** 订单流水号 */
    orderSerialNo?: string

    /** 订单状态 0-正常 1-已完成 2-已取消 */
    orderStatus?: number

    /** orderStatusStr */
    orderStatusStr?: string

    /** 订单时间 */
    orderTime?: string

    /** 支付状态 0-待支付 1-已支付 2-退款中 3-已退款 */
    payStatus?: number

    /** payStatusStr */
    payStatusStr?: string

    /** 支付时间 */
    payTime?: string

    /** 支付方式 0-积分 1-微信 2-支付宝 */
    payWay?: number

    /** payWayStr */
    payWayStr?: string

    /** 省份编码 */
    provinceCode?: string

    /** 省份名称 */
    provinceName?: string

    /** 退款时间 */
    refundTime?: string

    /** 区县编码 */
    regionCode?: string

    /** 区县名称 */
    regionName?: string

    /** 开始积分 */
    startPoints?: number

    /** 总积分 */
    totalPoints?: number

    /** 总金额(分) */
    totalPrice?: number

    /** 用户id */
    userId?: number

    /** 用户姓名 */
    userName?: string
  }

  export class MenuIDParameter {
    /** 菜单ID */
    menuId: number
  }

  export class MenuToModifyParameters {
    /** 菜单图标 */
    icon?: string

    /** 菜单ID */
    menuId: number

    /** 菜单类型 0-司机端APP 1-运营平台 2-加油员端APP */
    menuType?: number

    /** 名称 */
    name: string

    /** 排序 */
    orderNum?: number

    /** 父级ID */
    parentMenuId?: number

    /** 类型   0：目录   1：菜单   2：按钮 */
    type: number

    /** 菜单URL */
    url?: string
  }

  export class Models {
    /** 新增时间 */
    addTime?: string

    /** id */
    id?: number

    /** Models名称 */
    vehicleTypeName?: string
  }

  export class ModifyTheParameterInARelease {
    /** 附件 */
    appendixList?: Array<defs.ReleaseInformationAttachmentParameters>

    /** 发布内容 */
    content: string

    /** id */
    id: number
  }

  export class NewParametersInANewsRelease {
    /** 附件 */
    appendixList?: Array<defs.ReleaseInformationAttachmentParameters>

    /** 发布内容 */
    content: string
  }

  export class NewVersionControlParameters {
    /** 版本下载地址 */
    appDownUrl: string

    /** app类型 0-油卡app 1加油员app */
    appType: number

    /** 版本号，如1.0.1 */
    appVersion: string

    /** 版本序号，如101 */
    appVersionNum: number

    /** 是否强制升级：0-不是 ，1-是 */
    isEnforceUpgrade: number

    /** 终端系统类型：操作系统 0-ios 1-android 2-harmony */
    opSystem: number
  }

  export class NotifyEntity {
    /** companyCode */
    companyCode?: string

    /** data */
    data?: string

    /** timestamp */
    timestamp?: number
  }

  export class Oil {
    /** id */
    id?: number

    /** 排序 */
    orderby?: number

    /** Oil名称 */
    petrolName?: string

    /** Oil类型 0-柴油 1-汽油 2-天然气 */
    petrolType?: number

    /** Oil类型 0-柴油 1-汽油 2-天然气 */
    petrolTypeDesc?: string

    /** 单位 */
    units?: string
  }

  export class OilCardDetailedQuery {
    /** 业务交易流水号(运输订单号) */
    busiTradeNo?: string

    /** 变更类型 0-充值 1-消费 2-划出 3-划入 4-转出 5-转入 */
    changeType?: number

    /** 结束日期 yyyy-MM-dd */
    endDate?: string

    /** 结束日期 yyyy-MM-dd HH:mm:ss */
    endTime?: string

    /** 结束日期 yyyy-MM-dd HH:mm:ss */
    endTimeStr?: string

    /** 卡id */
    petrolCardId?: number

    /** 开始日期 yyyy-MM-dd */
    startDate?: string

    /** 开始时间 yyyy-MM-dd HH:mm:ss */
    startTime?: string

    /** 开始时间 yyyy-MM-dd HH:mm:ss */
    startTimeStr?: string
  }

  export class OilCardDisabledStateIsEnabled {
    /** 油卡状态 0-禁用 1-正常 */
    cardStatus?: number

    /** 卡ID */
    id?: number
  }

  export class OilCardOperationParameters {
    /** 油卡ID */
    cardId: number

    /** 金额 单位：分 */
    money: number

    /** 操作类型 1 余额退回 2余额冻结 3取消冻结 */
    opType: number

    /** 备注 */
    remark: string
  }

  export class OilCardStatisticalQueryParameters {
    /** 结束日期 yyyy-MM-dd */
    endDate?: string

    /** 油卡类型 0-车队油卡 1-云图油卡 2-实体油卡 */
    petrolCardType?: number

    /** 查询类型 今日-1 本周-2 本月3 */
    queryType?: number

    /** 开始日期 yyyy-MM-dd */
    startDate?: string
  }

  export class OilCardTopUpParameters {
    /** 订单号(业务交易流水号) */
    busiTradeNo?: string

    /** 卡id */
    cardId?: number

    /** -35#柴油充值油量(ml) */
    change2Petrol?: number

    /** 0#柴油充值油量(ml) */
    changePetrol?: number

    /** 抵扣运费(分) */
    deductionCost?: number

    /** 车辆id */
    vehicleId?: number
  }

  export class OilCardTransferDetailedQuery {
    /** 结束日期 yyyy-MM-dd */
    endDate?: string

    /** 结束日期 yyyy-MM-dd HH:mm:ss */
    endTime?: string

    /** 结束日期 yyyy-MM-dd HH:mm:ss */
    endTimeStr?: string

    /** 开始日期 yyyy-MM-dd */
    startDate?: string

    /** 开始时间 yyyy-MM-dd HH:mm:ss */
    startTime?: string

    /** 开始时间 yyyy-MM-dd HH:mm:ss */
    startTimeStr?: string

    /** 公司id */
    zcCompanyId?: number

    /** 公司id */
    zrCompanyId?: number
  }

  export class OilCardUnlockParameters {
    /** 卡ID */
    cardId: number

    /** 订单ID */
    orderId: number
  }

  export class OilCompanyCardInformation {
    /** 新增时间 */
    addTime?: string

    /** 新增时间 */
    addTimeStr?: string

    /** 地市编码 */
    cityCode?: string

    /** 地市名称 */
    cityName?: string

    /** 公司id */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 授信余额 分 */
    creditLine?: number

    /** id */
    id?: number

    /** 限额提醒金额 */
    limitRemindMoney?: number

    /** 油卡id */
    petrolCardId?: number

    /** 卡号 */
    petrolCardNum?: string

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardType?: number

    /** 油卡类型中文名称 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardTypeName?: string

    /** 省份编码 */
    provinceCode?: string

    /** 省份名称 */
    provinceName?: string

    /** 区县编码 */
    regionCode?: string

    /** 区县名称 */
    regionName?: string
  }

  export class OilCompanyCardQueryParameters {
    /** 油卡状态 */
    cardStatus?: number

    /** 使用卡种 */
    cardType?: number

    /** 地市编码 */
    cityCode?: string

    /** 合作公司id */
    orgId?: number

    /** 省份编码 */
    provinceCode?: string

    /** 区县编码 */
    regionCode?: string
  }

  export class OilCompanyCardTopUpEntities {
    /** 充值时间 */
    addTime?: string

    /** 充值后金额 */
    afterMoney?: number

    /** 充值前金额 */
    beforeMoney?: number

    /** 变更金额 */
    changeMoney?: number

    /** 变更类型（交易类型） 0-充值 1-消费 2-划出 3-划入 */
    changeType?: number

    /** 变更类型 （交易类型） 0-充值 1-消费 2-划出 3-划入 */
    changeTypeName?: string

    /** 交易部门 */
    deptName?: string

    /** 搜索结束时间 */
    endTime?: string

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** 油卡id */
    petrolCardId?: number

    /** 备注 */
    remark?: string

    /** 搜索开始时间 */
    startTime?: string

    /** 转出卡 */
    transCardNum?: string
  }

  export class OilCompanyStatisticalInterfaceCardObjects {
    /** 油卡数量 */
    cardNum?: number

    /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
    cardStatus?: number

    /** 公司id */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 主卡卡号 */
    mainCardNo?: string

    /** 主卡剩余金额 分 */
    mainRemainingSum?: number

    /** 主卡充值金额 分 */
    mainTotalDepositMoney?: number

    /** 主卡id */
    petrolCardId?: number

    /** 卡种 */
    petrolCardType?: string

    /** 副卡总充值金额 分 */
    sonDepositMoney?: number

    /** 副卡总剩余金额 分 */
    sonRemainingSum?: number

    /** 副卡退回金额 分 */
    sonReturnMoney?: number

    /** 副卡总消费金额 分 */
    sonTotalConsumeMoney?: number

    /** 车辆数量 */
    vehicleNum?: number
  }

  export class OilTeamElectronicCard {
    /** 新增时间 */
    addTime?: string

    /** 油卡平台 0-云途 1-G7 */
    cardPlatform?: number

    /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
    cardStatus?: number

    /** 油卡状态描述 */
    cardStatusDesc?: string

    /** 公司id */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 部门id */
    deptId?: number

    /** 部门名称 */
    deptName?: string

    /** 驾驶员id */
    driverId?: number

    /** 驾驶员姓名 */
    driverName?: string

    /** 即将过期的剩余油量2(ml) */
    expireRemainConsume2PetrolWarn?: number

    /** 即将过期的剩余油量(ml) */
    expireRemainConsumePetrolWarn?: number

    /** id */
    id?: number

    /** 是否主卡 0-否 1-是 */
    isPri?: number

    /** 是否主卡描述 */
    isPriDesc?: string

    /** 登录名 */
    loginName?: string

    /** 开卡时间 */
    openTime?: string

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** 父id */
    parentId?: number

    /** Oil2id */
    petrol2Id?: number

    /** Oil2名称 */
    petrol2Name?: string

    /** 卡号 */
    petrolCardNum?: string

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardType?: number

    /** 油卡类型描述 */
    petrolCardTypeDesc?: string

    /** Oilid */
    petrolId?: number

    /** Oil名称 */
    petrolName?: string

    /** 剩余2油量(ml) */
    remaining2PetrolSum?: number

    /** 剩余油量(ml) */
    remainingPetrolSum?: number

    /** 累计消费2油量(ml) */
    totalConsume2Petrol?: number

    /** 累计消费油量(ml) */
    totalConsumePetrol?: number

    /** 累计抵扣运费(分) */
    totalDeductionCost?: number

    /** 累计充值2油量(ml) */
    totalDeposit2Petrol?: number

    /** 累计充值油量(ml) */
    totalDepositPetrol?: number

    /** 车辆id */
    vehicleId?: number

    /** 车牌号 */
    vehicleNum?: string

    /** 车辆来源 0-后台添加 1-加盟 */
    vehicleSource?: number

    /** 车辆来源描述 */
    vehicleSourceDesc?: string

    /** 车辆类型 0-自有车辆 1-外协车辆 */
    vehicleType?: number

    /** 车辆类型描述 */
    vehicleTypeDesc?: string

    /** Modelsid */
    vehicleTypeId?: number

    /** Models名称 */
    vehicleTypeName?: string

    /** 云途油卡类型 0-个人云途油卡 1-公司云途油卡 2-非云途油卡 */
    ytCardType?: number

    /** 云途油卡类型描述 */
    ytCardTypeDesc?: string
  }

  export class OperationLogsPagingQueryParameters {
    /** 操作结束时间 格式:yyyy-MM-dd HH:mm:ss */
    endTime?: string

    /** 用户帐号 */
    loginName?: string

    /** 操作模块 */
    opModule?: string

    /** 用户姓名 */
    operatorName?: string

    /** 操作开始时间 格式:yyyy-MM-dd HH:mm:ss */
    startTime?: string
  }

  export class PageBean<T0 = any> {
    /** 总数 */
    count: number

    /** 当前页 */
    curPage: number

    /** 业务数据 */
    data?: Array<defs.CardPetrolDepositObject>

    /** 请求结果(http请求是否成功) */
    httpStatus?: number

    /** 业务信息描述 */
    msg?: string

    /** 数据量/页 */
    pageSize: number

    /** 处理结果(业务处理是否成功) */
    resultStatus?: number

    /** success */
    success?: boolean
  }

  export class PageRequest<T0 = any> {
    /** 当前页 */
    curPage: number

    /** 数据量/页 */
    pageSize: number

    /** startIndex */
    startIndex?: number

    /** 查询条件 */
    where?: T0
  }

  export class PetrolStationNameEntity {
    /** 详细地址 */
    detailAddr?: string

    /** id */
    id?: number

    /** OilID列表 */
    petrolIdList?: Array<number>

    /** 加油站编码 */
    stationCode?: string

    /** 加油站纬度 */
    stationLat?: number

    /** 加油站经度 */
    stationLng?: number

    /** 加油站名称 */
    stationName?: string

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 5-G7 6-星油 7-团油 */
    stationSource?: number

    /** 油站来源 */
    stationSourceDesc?: string
  }

  export class PhysicalOilBindingLogCardVehicles {
    /** 部门id */
    deptId?: number

    /** 公司id */
    orgId: number

    /** 油卡ID */
    petrolCardId: number

    /** 车辆id */
    vehicleId: number
  }

  export class PhysicalOilCardBindingQueryParameters {
    /** 油卡id */
    cardId?: number
  }

  export class PlatformOffersInformationToModifyParameters {
    /** 大图地址 */
    bigImgAddr: string

    /** 大图id */
    bigImgId?: string

    /** id */
    id: number

    /** 优惠Details */
    proDetail: string

    /** 优惠结束时间 格式:yyyy-MM-dd HH:mm:ss */
    proEndTime: string

    /** 优惠开始时间 格式:yyyy-MM-dd HH:mm:ss */
    proStartTime: string

    /** 优惠标题 */
    proTitle: string

    /** 小图地址 */
    smallImgAddr?: string

    /** 小图id */
    smallImgId?: string

    /** 加油站ID */
    stationIds: Array<number>
  }

  export class PreferentialInformationPlatform {
    /** 新增时间 */
    addTime?: string

    /** 新增时间 */
    addTimeStr?: string

    /** 大图地址 */
    bigImgAddr?: string

    /** 大图id */
    bigImgId?: string

    /** id */
    id?: number

    /** 优惠Details */
    proDetail?: string

    /** 优惠结束时间 */
    proEndTime?: string

    /** 优惠结束时间 */
    proEndTimeStr?: string

    /** 优惠开始时间 */
    proStartTime?: string

    /** 优惠开始时间 */
    proStartTimeStr?: string

    /** 优惠标题 */
    proTitle?: string

    /** 小图地址 */
    smallImgAddr?: string

    /** 小图id */
    smallImgId?: string

    /** 加油站ID */
    stationIds?: Array<number>

    /** 加油站名称 多个逗号分隔 */
    stationNames?: string
  }

  export class PreferentialInformationPlatformPagingQueryParameters {
    /** 结束时间 格式:yyyy-MM-dd HH:mm:ss */
    endTime?: string

    /** 开始时间 格式:yyyy-MM-dd HH:mm:ss */
    startTime?: string

    /** 加油站Id */
    stationIds?: Array<number>

    /** 加油站名称 */
    stationName?: string
  }

  export class PrincipalCardTopUpParameterClass {
    /** 卡种 */
    cardType: number

    /** 公司id */
    orgId: number

    /** 卡号 */
    petrolCardNum?: string

    /** 充值金额 */
    rechargeAmount?: number

    /** 剩余金额 */
    remainAmount?: number
  }

  export class ProductModificationParameters {
    /** Oilid */
    id: number

    /** Oil名称 */
    petrolName: string

    /** Oil类型 0-柴油 1-汽油 2-天然气 */
    petrolType: number

    /** 单位 */
    units?: string
  }

  export class ProductOfNewParameters {
    /** Oil名称 */
    petrolName: string

    /** Oil类型 0-柴油 1-汽油 2-天然气 */
    petrolType: number

    /** 单位 */
    units?: string
  }

  export class Provinces {
    /** 城市编码 */
    cityCode?: string

    /** 城市名称 */
    cityName?: string

    /** 省份编码 */
    provinceCode?: string

    /** 省份名称 */
    provinceName?: string

    /** 地区编码 */
    regionCode?: string

    /** 地区名称 */
    regionName?: string
  }

  export class QueryConditionsAppVersion {
    /** app类型 0-油卡app 1加油员app */
    appType?: number

    /** 操作系统 0-ios 1-android 2-harmony */
    opSystem?: number
  }

  export class QueryConditionsOfMakeOutInvoice {
    /** 申请结束时间 yyyy-MM-dd HH:mm:ss */
    applyEndTime?: string

    /** 申请开始时间 yyyy-MM-dd HH:mm:ss */
    applyStartTime?: string

    /** 开票结束时间 yyyy-MM-dd HH:mm:ss */
    dealEndTime?: string

    /** 开票开始时间 yyyy-MM-dd HH:mm:ss */
    dealStartTime?: string

    /** 是否已处理 0-否 1-是 */
    isDeal?: number

    /** 发票抬头 */
    title?: string
  }

  export class QueryParameterClassPrincipalCardAccount {
    /** 卡种 */
    cardType: number

    /** 公司id */
    companyId: number
  }

  export class RefuelingOverviewHeadFuelStatistics {
    /** 统计数 */
    countNum?: number

    /** 比率 */
    rate?: number

    /** 标题 */
    title?: string
  }

  export class RegionEncodingParameters {
    /** 编码 */
    regionCode: string
  }

  export class ReleaseInformationAttachment {
    /** 文件id */
    fileId?: string

    /** 文件名称 */
    fileName?: string

    /** 文件地址 */
    fileUrl?: string

    /** 附件id */
    id?: number

    /** 发布消息id */
    publishId?: number
  }

  export class ReleaseInformationAttachmentParameters {
    /** 文件id */
    fileId?: string

    /** 文件名称 */
    fileName?: string

    /** 文件地址 */
    fileUrl?: string
  }

  export class ReleaseInformationQueryConditions {
    /** 审核状态 */
    checkStatus?: number

    /** 结束日期 yyyy-MM-dd */
    endDate?: string

    /** 结束日期 yyyy-MM-dd HH:mm:ss */
    endTime?: string

    /** 开始日期 yyyy-MM-dd */
    startDate?: string

    /** 开始时间 yyyy-MM-dd HH:mm:ss */
    startTime?: string

    /** 用户姓名 */
    userName?: string

    /** 用户手机号 */
    userPhone?: string
  }

  export class ResPetrolPrice {
    /** id */
    id?: number

    /** 挂牌价(分) */
    listingPrice?: number

    /** Oilid */
    petrolId?: number

    /** Oil名称 */
    petrolName?: string

    /** Oil价格(分) */
    petrolPrice?: number

    /** Oil类型 0-柴油 1-汽油 2-天然气 */
    petrolType?: number

    /** Oil单位 */
    petrolUnit?: string

    /** 优惠价(分) */
    preferentialPrice?: number

    /** 加油站id */
    stationId?: number

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
    stationSource?: number

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
    stationSourceStr?: string

    /** 发改委价格(分) */
    suggestPrice?: number
  }

  export class ResPetrolPriceDto {
    /** //是否调价 0 否  1 是 */
    isAdjust?: number

    /** //油价列表 */
    priceList?: Array<defs.ResPetrolPrice>

    /** //加油站编码 */
    stationCode?: string

    /** 油站id */
    stationId?: number

    /** //加油站名称 */
    stationName?: string

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 5-G7 6-星油 */
    stationSource?: number

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 5-G7 6-星油 */
    stationSourceDesc?: string
  }

  export class ResPetrolStation {
    /** 新增时间 */
    addTime?: string

    /** 银行账号 */
    bankAccount?: string

    /** 计费方式 0-金额 1-升 */
    calWay?: number

    /** 审核人id */
    checkId?: number

    /** 审核人姓名 */
    checkName?: string

    /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
    checkStatus?: number

    /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
    checkStatusStr?: string

    /** 审核时间 */
    checkTime?: string

    /** 地市编码 */
    cityCode?: string

    /** 地市名称 */
    cityName?: string

    /** 联系人姓名 */
    contactName?: string

    /** 联系人电话 */
    contactPhone?: string

    /** 详细地址 */
    detailAddr?: string

    /** 加油撬编号集合  多个用英文逗号隔开 */
    deviceCodes?: string

    /** 加油站距离 km */
    distance?: number

    /** 油枪数量 */
    gunNum?: number

    /** id */
    id?: number

    /** 图片 */
    imgUrl?: string

    /** 是否删除  0-否 1-是 */
    isDeleted?: number

    /** 是否已启用  0-停用 1-启用 */
    isEnabled?: number

    /** isEnabledStr */
    isEnabledStr?: string

    /** 油站是否在高速上 0-否  1-是 */
    isHighSpeed?: number

    /** 是否锁卡 0-否 1-是 */
    isLockCard?: number

    /** 是否显示 0-否 1-是 */
    isShow?: number

    /** 加入时间 */
    joinTime?: string

    /** 组合名称 */
    merName?: string

    /** 开户地址 */
    openAddr?: string

    /** 开户银行 */
    openBank?: string

    /** 订单是否需要加油枪 0-否 1-是 */
    orderNeedGun?: number

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardType?: number

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardTypeStr?: string

    /** Oilid集合 */
    petrolIds?: string

    /** Oil名称集合 */
    petrolNames?: string

    /** 省份编码 */
    provinceCode?: string

    /** 省份名称 */
    provinceName?: string

    /** 返点(分)比例 */
    rebateRate?: number

    /** 区县编码 */
    regionCode?: string

    /** 区县名称 */
    regionName?: string

    /** 加油站编码 */
    stationCode?: string

    /** 加油站纬度 */
    stationLat?: number

    /** 加油站经度 */
    stationLng?: number

    /** 加油站名称 */
    stationName?: string

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 5-G7 */
    stationSource?: number

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 5-G7 */
    stationSourceStr?: string

    /** 第三方id */
    thirdId?: string

    /** 交易方式 0-司机出示二维码(加油员扫码) 1-司机主动支付 */
    tradeType?: number

    /** 加盟方式  0-主动申请 1-后台添加 */
    unionWay?: number

    /** 加盟方式  0-主动申请 1-后台添加 */
    unionWayStr?: string

    /** 更新时间 */
    updateTime?: string
  }

  export class ResPetrolStationAuditParams {
    /** //审核人id */
    checkId?: number

    /** //审核人姓名 */
    checkName?: string

    /** //审核状态 0-待审核 1-审核通过 2-审核不通过 */
    checkStatus?: number

    /** //id */
    id?: number
  }

  export class ResPetrolStationEnableParams {
    /** //id */
    id?: number

    /** 是否已启用  0-停用 1-启用 */
    isEnabled?: number
  }

  export class ResPetrolStationLockCardParams {
    /** //id */
    id?: number

    /** 是否显示  0-否 1-是 */
    isLockCard?: number
  }

  export class ResPetrolStationOrderbyEnableParams {
    /** //id */
    id?: number

    /** 是否已启用  0-停用 1-启用 */
    isEnabled?: number
  }

  export class ResPetrolStationPageParams {
    /** 计费方式 0-金额 1-升 2-金额+升 */
    calWay?: number

    /** //审核状态 0-待审核 1-审核通过 2-审核不通过 */
    checkStatus?: number

    /** //地市编码 */
    cityCode?: string

    /** 联系人电话 */
    contactPhone?: string

    /** 申请结束时间  yyyy-MM-dd HH:mm:ss  2021-06-02 23:59:59 */
    endTimeStr?: string

    /** 是否已启用  0-停用 1-启用 */
    isEnabled?: number

    /** 油站是否在高速上 0-否  1-是 */
    isHighSpeed?: number

    /** 是否锁卡  0-否 1-1是 */
    isLockCard?: number

    /** //油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardType?: number

    /** //省份编码 */
    provinceCode?: string

    /** //区县编码 */
    regionCode?: string

    /** 申请开始时间  yyyy-MM-dd HH:mm:ss  2021-06-01 00:00:00 */
    startTimeStr?: string

    /** //加油站名称 */
    stationName?: string

    /** 油站来源 */
    stationSource?: number

    /** 交易方式 0-司机出示二维码(加油员扫码) 1-司机主动支付 */
    tradeType?: number
  }

  export class ResPetrolStationSaveParams {
    /** 银行账号 */
    bankAccount?: string

    /** 计费方式 0-金额 1-升 */
    calWay?: number

    /** 审核人id */
    checkId?: number

    /** 审核人姓名 */
    checkName?: string

    /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
    checkStatus?: number

    /** 地市编码 */
    cityCode?: string

    /** 地市名称 */
    cityName?: string

    /** 联系人姓名 */
    contactName?: string

    /** 联系人电话 */
    contactPhone?: string

    /** 详细地址 */
    detailAddr?: string

    /** 加油撬编号集合  多个用英文逗号隔开 */
    deviceCodes?: string

    /** id */
    id?: number

    /** 是否已启用  0-停用 1-启用 */
    isEnabled?: number

    /** 油站是否在高速上 0-否  1-是 */
    isHighSpeed?: number

    /** 是否锁卡 0-否 1-是 */
    isLockCard?: number

    /** 是否显示 0-否 1-是 */
    isShow?: number

    /** 组合名称 */
    merName?: string

    /** 开户地址 */
    openAddr?: string

    /** 开户银行 */
    openBank?: string

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardType?: number

    /** Oilid集合 */
    petrolIds?: string

    /** Oil名称集合 */
    petrolNames?: string

    /** 省份编码 */
    provinceCode?: string

    /** 省份名称 */
    provinceName?: string

    /** 返点(分)比例 */
    rebateRate?: number

    /** 区县编码 */
    regionCode?: string

    /** 区县名称 */
    regionName?: string

    /** 加油枪信息 */
    resStation2GunList?: Array<defs.ResStation2GunObject>

    /** GasOil信息 */
    station2PetrolList?: Array<defs.ResStation2PetrolObject>

    /** 加油站编码 */
    stationCode?: string

    /** 加油站加油撬信息 */
    stationDeviceList?: Array<defs.ResStationDeviceObject>

    /** 加油站图片 */
    stationImgList?: Array<defs.ResStationImgObject>

    /** 加油站纬度 */
    stationLat?: number

    /** 加油站经度 */
    stationLng?: number

    /** 加油站名称 */
    stationName?: string

    /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
    stationSource?: number

    /** 第三方加油站ID */
    thirdId?: string

    /** 交易方式 0-司机出示二维码(加油员扫码) 1-司机主动支付 */
    tradeType?: number
  }

  export class ResPetrolStationShowParams {
    /** //id */
    id?: number

    /** 是否显示  0-隐藏 1-显示 */
    isShow?: number
  }

  export class ResPhysicalBindingLog {
    /** 新增时间 */
    addTime?: string

    /** 部门id */
    deptId?: number

    /** 部门名称 */
    deptName?: string

    /** 驾驶员id */
    driverId?: number

    /** 驾驶员名称 */
    driverName?: string

    /** id */
    id?: number

    /** 设置操作时间 */
    opTime?: string

    /** 操作类型 0-绑定 1-解绑 */
    opType?: number

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** 公司id */
    orgId?: number

    /** 公司名称 */
    orgName?: string

    /** 油卡ID */
    petrolCardId?: number

    /** 卡编号 */
    petrolCardNum?: string

    /** 油卡类型 */
    petrolCardType?: number

    /** TheThirdPartyInstitution编码 */
    thirdOrgCode?: string

    /** TheThirdPartyInstitutionid */
    thirdOrgId?: number

    /** TheThirdPartyInstitution平台 0-G7 */
    thirdOrgPlatform?: number

    /** 车辆id */
    vehicleId?: number

    /** 车牌号 */
    vehicleNum?: string

    /** 车辆来源 0-后台添加 1-加盟 */
    vehicleSource?: number

    /** 车辆类型 0-自有车辆 1-外协车辆 */
    vehicleType?: number
  }

  export class ResStation2GunObject {
    /** 新增时间 */
    addTime?: string

    /** 加油枪编号 */
    gunCode?: string

    /** id */
    id?: number

    /** 是否删除  0-否 1-是 */
    isDeleted?: number

    /** 挂牌价(分) */
    listingPrice?: number

    /** Oilid */
    petrolId?: number

    /** Oil名称 */
    petrolName?: string

    /** Oil类型 0-柴油 1-汽油 2-天然气 */
    petrolType?: number

    /** 加油站id */
    stationId?: number

    /** 三方Oil编码 */
    thirdPetrolCode?: string
  }

  export class ResStation2PetrolObject {
    /** 新增时间 */
    addTime?: string

    /** id */
    id?: number

    /** 是否删除  0-否 1-是 */
    isDeleted?: number

    /** Oil级别 例：国 V、国 IV  G7专用 */
    oilLevel?: string

    /** Oil类型 例：柴油、汽油  G7专用 */
    oilName?: string

    /** Oil标号 例：0#、97#  G7专用 */
    oilType?: string

    /** Oilid */
    petrolId?: number

    /** Oil名称 */
    petrolName?: string

    /** Oil类型 0-柴油 1-汽油 2-天然气 */
    petrolType?: number

    /** 加油站id */
    stationId?: number

    /** 三方Oil编码 */
    thirdPetrolCode?: string
  }

  export class ResStationDeviceObject {
    /** 新增时间 */
    addTime?: string

    /** 加油撬编号 */
    deviceCode?: string

    /** id */
    id?: number

    /** 是否删除  0-否 1-是 */
    isDeleted?: number

    /** 是否自有 0-否 1-是 */
    isSelfDevice?: number

    /** Oilid */
    petrolId?: number

    /** Oil名称 */
    petrolName?: string

    /** Oil类型 0-柴油 1-汽油 2-天然气 */
    petrolType?: number

    /** 加油站id */
    stationId?: number
  }

  export class ResStationImgObject {
    /** 新增时间 */
    addTime?: string

    /** 大图地址 */
    bigImgAddr?: string

    /** 大图id */
    bigImgId?: string

    /** id */
    id?: number

    /** 是否封面 0-否 1-是 */
    isFace?: number

    /** 小图地址 */
    smallImgAddr?: string

    /** 小图id */
    smallImgId?: string

    /** 加油站id */
    stationId?: number
  }

  export class ResStationPromotion {
    /** 优惠结束时间 */
    activityEndTime?: string

    /** 优惠开始时间 */
    activityStartTime?: string

    /** 新增时间 */
    addTime?: string

    /** 优惠信息 */
    content?: string

    /** 优惠信息id */
    id?: number

    /** 是否删除  0-否 1-是 */
    isDeleted?: number

    /** 加油站id */
    stationId?: number

    /** 修改时间 */
    updateTime?: string
  }

  export class ResStationPromotionDto {
    /** 优惠结束时间 */
    activityEndTime?: string

    /** 优惠开始时间 */
    activityStartTime?: string

    /** 新增时间 */
    addTime?: string

    /** 优惠信息 */
    content?: string

    /** 优惠信息id */
    id?: number

    /** 优惠信息列表 */
    promotionList?: Array<defs.ResStationPromotion>

    /** 加油站id */
    stationId?: number

    /** 加油站名称 */
    stationName?: string

    /** 修改时间 */
    updateTime?: string
  }

  export class RestResult {
    /** code */
    code?: number

    /** message */
    message?: string

    /** result */
    result?: object
  }

  export class ResultBean<T0 = any> {
    /** 业务数据 */
    data?: T0

    /** 请求结果(http请求是否成功) */
    httpStatus?: number

    /** 业务信息描述 */
    msg?: string

    /** 处理结果(业务处理是否成功) */
    resultStatus?: number

    /** success */
    success?: boolean
  }

  export class ReturnsTheEntityManagementList {
    /** 新增时间 */
    addTime?: string

    /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
    cardStatus?: number

    /** 油卡类型 */
    cardTypeName?: string

    /** 地市名称 */
    cityName?: string

    /** 联系人姓名 */
    contactName?: string

    /** 联系人电话 */
    contactPhone?: string

    /** 授信余额(分) */
    creditRemainingLine?: number

    /** 详细地址 */
    detailAddr?: string

    /** id */
    orgId?: number

    /** 名称 */
    orgName?: string

    /** 省份名称 */
    provinceName?: string

    /** 区县名称 */
    regionName?: string
  }

  export class ReviewTheParametersInARelease {
    /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
    checkStatus: number

    /** id */
    id: number
  }

  export class RoleChangeParameters {
    /** 菜单ID */
    menuIdList: Array<number>

    /** 机构ID */
    orgId: number

    /** 备注 */
    remark?: string

    /** 角色ID */
    roleId: number

    /** 角色名称 */
    roleName: string
  }

  export class RoleIDParameter {
    /** 角色ID */
    roleId: number
  }

  export class RoleOfPagingQueryConditions {
    /** 公司ID */
    companyId?: number
  }

  export class StarRestResult {
    /** code */
    code?: number

    /** data */
    data?: object

    /** msg */
    msg?: string
  }

  export class StarSyncCommonParams {
    /** params */
    params?: string
  }

  export class StateOilCompanyCardIsDisabled {
    /** 油卡状态 0-禁用 1-正常 */
    cardStatus?: number

    /** 公司ID */
    companyId?: number
  }

  export class SysAccountPwdEditParams {
    /** 新密码 */
    newPassword: string

    /** 旧密码 */
    password: string
  }

  export class SysConfigEntity {
    /** addTime */
    addTime?: string

    /** addTimeStr */
    addTimeStr?: string

    /** configType */
    configType?: number

    /** id */
    id?: number

    /** textArea */
    textArea?: string

    /** textChar */
    textChar?: string

    /** updateTime */
    updateTime?: string

    /** updateTimeStr */
    updateTimeStr?: string
  }

  export class SysDeptEntityObject {
    /** 新增时间 */
    addTime?: string

    /** 银行账号 */
    bankAccount?: string

    /** 地市编码 */
    cityCode?: string

    /** 地市名称 */
    cityName?: string

    /** 联系人姓名 */
    contactName?: string

    /** 联系人电话 */
    contactPhone?: string

    /** 详细地址 */
    detailAddr?: string

    /** 是否默认  0-否 1-是 */
    isDefault?: number

    /** 是否删除  0-否 1-是 */
    isDeleted?: number

    /** 开户地址 */
    openAddr?: string

    /** 开户银行 */
    openBank?: string

    /** id */
    orgId?: number

    /** 组织纬度 */
    orgLat?: number

    /** 组织经度 */
    orgLng?: number

    /** 名称 */
    orgName?: string

    /** 组织类型 0公司 1部门 */
    orgType?: number

    /** 父级ID */
    parentOrgId?: number

    /** 父级名称 */
    parentOrgName?: string

    /** 省份编码 */
    provinceCode?: string

    /** 省份名称 */
    provinceName?: string

    /** 区县编码 */
    regionCode?: string

    /** 区县名称 */
    regionName?: string

    /** 顶级机构ID */
    topOrgId?: number
  }

  export class SysMenuEntityObject {
    /** 新增时间 */
    addTime?: string

    /** 菜单图标 */
    icon?: string

    /** 菜单ID */
    menuId?: number

    /** 菜单类型 0-司机端APP 1-运营平台 2-加油员端APP */
    menuType?: number

    /** 密码 */
    name?: string

    /** 排序 */
    orderNum?: number

    /** 父级ID */
    parentMenuId?: number

    /** 类型   0：目录   1：菜单   2：按钮 */
    type?: number

    /** 菜单URL */
    url?: string
  }

  export class SysMsgEntityObject {
    /** 新增时间 */
    addTime?: string

    /** id */
    id?: number

    /** 消息内容 */
    msgContent?: string

    /** 消息所属系统 0-APP 1-PC */
    msgFrom?: number

    /** 消息标签 订单标签格式:{orderId:123456} */
    msgTag?: string

    /** 消息时间 */
    msgTime?: string

    /** 消息类型 1：订单消息 */
    msgType?: number

    /** 消息类型说明 */
    msgTypeDesc?: string
  }

  export class SysRoleEntityObject {
    /** 创建时间 */
    addTime?: string

    /** 菜单ID */
    menuIdList?: Array<number>

    /** 机构ID */
    orgId?: number

    /** 公司名称 */
    orgName?: string

    /** 备注 */
    remark?: string

    /** 角色ID */
    roleId?: number

    /** 角色名称 */
    roleName?: string

    /** 用户人数 */
    userNum?: number
  }

  export class SysUserEntityObject {
    /** 状态  0：禁用   1：正常 */
    accountStatus?: number

    /** 新增时间 */
    addTime?: string

    /** 绑定设备 */
    bindingDevice?: string

    /** 公司id */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 联系电话 */
    contactPhone?: string

    /** 部门id */
    deptId?: number

    /** 部门名称 */
    deptName?: string

    /** 头像图片地址 */
    headImgAddr?: string

    /** 头像图片id */
    headImgId?: string

    /** 用户ID */
    id?: number

    /** 身份证号码 */
    idCard?: string

    /** 是否管理员 0-否 1-是 */
    isAdmin?: number

    /** 是否删除  0-否 1-是 */
    isDeleted?: number

    /** 是否启用绑定设备 0-否 1-是 */
    isEnableBinding?: number

    /** 登录账号 */
    loginName?: string

    /** 角色ID列表 */
    roleIdList?: Array<number>

    /** 角色名称 */
    roleName?: string

    /** 加油站编码 */
    stationCode?: string

    /** 加油站id */
    stationId?: number

    /** 加油站名称 */
    stationName?: string

    /** 用户姓名 */
    userName?: string

    /** 用户类型 0-加油员 1-驾驶员 2-公司人员 */
    userType?: number
  }

  export class SystemConfigurationModificationParameters {
    /** id */
    id: number

    /** 富文本内容 */
    textArea: string

    /** 字符串内容 */
    textChar?: string
  }

  export class SystemConfigurationQueryParameters {
    /** 配置类型 0-云途油卡用户章程 1-云途加油用户章程 2-云途油卡隐私条款 3-云途加油隐私条款 4-云途油卡帮助中心 5-云途加油帮助中心 6-管理员手机号码 */
    sysConfigType: number
  }

  export class SystemMessagePagingQueryConditions {}

  export class TheAppVersionNumberQuery {
    /** app类型 0-油卡app 1加油员app */
    appType: number

    /** 终端系统类型：操作系统 0-ios 1-android 2-harmony */
    opSystem?: number
  }

  export class TheCompanyComeOnDetailedInformation {
    /** 实付消费总价(分) */
    actTotalPrice?: number

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    cardType?: number

    /** 卡类型 */
    cardTypeDesc?: string

    /** 日期 */
    dateStr?: string

    /** 驾驶员 */
    driverName?: string

    /** 实际油量(ml) */
    petrolCount?: number

    /** Oil名称 */
    petrolName?: string

    /** 加油员 */
    stationEmpName?: string

    /** 油站名称 */
    stationName?: string

    /** 车牌号 */
    vehicleNum?: string
  }

  export class TheDriverManagementQueryParameters {
    /** 油卡类型 */
    cardType?: number

    /** 公司id */
    companyId?: number

    /** 驾驶员姓名 */
    driverName?: string

    /** 手机号 */
    loginName?: string

    /** 车牌号 */
    vehicleNum?: string
  }

  export class TheDriverToAuditStatusParameters {
    /** 审核意见 */
    auditOpinion?: string

    /** 审核状态中文 0-待审核 1-审核通过 2-审核不通过 */
    auditStatus?: number

    /** id */
    id?: number
  }

  export class TheDriverToJoinAudit {
    /** 新增时间 */
    addTime?: string

    /** 申请时间 */
    applyTime?: string

    /** 审核意见 */
    auditOpinion?: string

    /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
    auditStatus?: number

    /** 审核状态中文 0-待审核 1-审核通过 2-审核不通过 */
    auditStatusStr?: string

    /** 审核时间 */
    auditTime?: string

    /** 联系电话 */
    contactPhone?: string

    /** id */
    id?: number

    /** 身份证 */
    idCard?: string

    /** Oil类型中文  */
    petrolTypeStr?: string

    /** 用户id */
    userId?: number

    /** 用户姓名 */
    userName?: string

    /** 车辆ID */
    vehicleId?: number

    /** 车牌号 */
    vehicleNum?: string

    /** ModelsID */
    vehicleTypeId?: number

    /** Models名称 */
    vehicleTypeName?: string
  }

  export class TheInformationOfMakeOutInvoice {
    /** 新增时间 */
    addTime?: string

    /** 申请人id */
    applicantId?: number

    /** 申请人姓名 */
    applicantName?: string

    /** 申请时间 */
    applyTime?: string

    /** 地市编码 */
    cityCode?: string

    /** 地市名称 */
    cityName?: string

    /** 企业名称 */
    companyName?: string

    /** 企业税号 */
    companyTaxNum?: string

    /** 联系电话 */
    contactPhone?: string

    /** 处理时间 */
    dealTime?: string

    /** 详细地址 */
    detailAddr?: string

    /** id */
    id?: number

    /** 是否已处理 0-否 1-是 */
    isDeal?: number

    /** 是否已处理 */
    isDealDesc?: string

    /** 操作人id */
    operatorId?: number

    /** 操作人姓名 */
    operatorName?: string

    /** 省份编码 */
    provinceCode?: string

    /** 省份名称 */
    provinceName?: string

    /** 区县编码 */
    regionCode?: string

    /** 区县名称 */
    regionName?: string

    /** 发票抬头 */
    title?: string

    /** 抬头类型 0-个人 1-企业 */
    titleType?: number

    /** 抬头类型 */
    titleTypeDesc?: string

    /** 总金额(分) */
    totalMoney?: number

    /** 用户姓名 */
    userName?: string
  }

  export class TheLineChartDataReturnObjects {
    /** xline */
    xline?: Array<string>

    /** yline */
    yline?: Array<number>
  }

  export class TheLoginInformation {
    /** 登陆过期时间 */
    loginExpiredTime?: string

    /** 登陆token */
    loginToken?: string

    /** 刷新过期时间 */
    refreshExpiredTime?: string

    /** TheRefreshToken */
    refreshToken?: string
  }

  export class TheNewCooperationCompanyParameters {
    /** 银行账号 */
    bankAccount?: string

    /** 油卡类型集合 */
    cardTypes?: Array<number>

    /** 地市编码 */
    cityCode: string

    /** 地市名称 */
    cityName: string

    /** 油卡信息集合 */
    companyPetrolCards?: Array<defs.OilCompanyCardInformation>

    /** 联系人姓名 */
    contactName: string

    /** 联系人电话 */
    contactPhone: string

    /** 详细地址 */
    detailAddr: string

    /** 开户地址 */
    openAddr?: string

    /** 开户银行 */
    openBank?: string

    /** orgId */
    orgId?: number

    /** 名称 */
    orgName: string

    /** 省份编码 */
    provinceCode: string

    /** 省份名称 */
    provinceName: string

    /** 区县编码 */
    regionCode: string

    /** 区县名称 */
    regionName: string
  }

  export class TheNewMenuParameters {
    /** 菜单图标 */
    icon?: string

    /** 菜单类型 0-司机端APP 1-运营平台 2-加油员端APP */
    menuType?: number

    /** 名称 */
    name: string

    /** 排序 */
    orderNum?: number

    /** 父级ID */
    parentMenuId?: number

    /** 类型   0：目录   1：菜单   2：按钮 */
    type: number

    /** 菜单URL */
    url?: string
  }

  export class TheOilCardSubsidiaryQueryParameters {
    /** 使用卡种 */
    cardType?: number

    /** 部门id */
    deptId?: number

    /** 驾驶员id */
    driverId?: number

    /** 驾驶员名称 */
    driverName?: string

    /** 合作公司id */
    orgId: number

    /** 油卡类型  */
    petrolCardType?: number

    /** 车辆id */
    vehicleId?: number

    /** 车牌号 */
    vehicleNum?: string
  }

  export class TheOilCardSubsidiaryReturnDetails {
    /** 卡状态  油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
    cardStatus?: number

    /** 卡状态描述 */
    cardStatusDesc?: string

    /** 部门id */
    deptId?: number

    /** 部门名称 */
    deptName?: string

    /** 驾驶员id */
    driverId?: number

    /** 驾驶员姓名 */
    driverName?: string

    /** 冻结金额（元） */
    freezeRemainingSum?: number

    /** 卡号 */
    petrolCardNum?: string

    /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
    petrolCardType?: number

    /** 剩余金额（元） */
    remainingSum?: number

    /** 退回金额（元） */
    returnMoney?: number

    /** 加油总额（元） */
    totalConsumeMoney?: number

    /** 充值总额（元） */
    totalDepositMoney?: number

    /** 车辆id */
    vehicleId?: number

    /** 车牌号 */
    vehicleNum?: string
  }

  export class TheOperationLog {
    /** 描述 */
    description?: string

    /** 登录名 */
    loginName?: string

    /** 操作模块 */
    opModule?: string

    /** 操作时间 */
    operateTime?: string

    /** 操作人姓名 */
    operatorName?: string
  }

  export class TheOperatorsOfNewParameters {
    /** 状态  0：禁用   1：正常 */
    accountStatus?: number

    /** 手机号 */
    contactPhone: string

    /** 是否管理员 0否 1是 */
    isAdmin?: number

    /** 加油站编号 WEB端传入,APP后端获取 */
    stationCode?: string

    /** 加油站ID WEB端传入,APP后端获取 */
    stationId?: number

    /** 加油站名称 WEB端传入,APP后端获取 */
    stationName?: string

    /** 用户姓名 */
    userName: string
  }

  export class TheOperatorsToModifyParameters {
    /** 状态  0：禁用   1：正常 */
    accountStatus?: number

    /** 手机号 */
    contactPhone: string

    /** 是否管理员 0否 1是 */
    isAdmin?: number

    /** 加油站编号 WEB端传入,APP后端获取 */
    stationCode?: string

    /** 加油站ID WEB端传入,APP后端获取 */
    stationId?: number

    /** 加油站名称 WEB端传入,APP后端获取 */
    stationName?: string

    /** 用户ID */
    userId: number

    /** 用户姓名 */
    userName: string
  }

  export class ThePilotListManagementReturnObjects {
    /** 绑定设备 */
    bindingDevice?: string

    /** 公司id */
    companyId?: number

    /** 公司名称 */
    companyName?: string

    /** 部门id */
    deptId?: number

    /** 部门名称 */
    deptName?: string

    /** 驾驶员ID */
    driverId?: number

    /** 驾驶员名称 */
    driverName?: string

    /** 车辆驾驶员关联id */
    id?: number

    /** 是否启用绑定设备 0-否 1-是 */
    isEnableBinding?: number

    /** 联系电话 */
    loginName?: string

    /** 油卡类型 多个用英文逗号隔开 */
    petrolCardTypes?: string

    /** 车牌号 */
    vehicleNum?: string

    /** Models名称 */
    vehicleTypeName?: string
  }

  export class ThePilotOfNewParameterObject {
    /** 公司id */
    companyId: number

    /** 公司名称 */
    companyName: string

    /** 驾驶员电话 */
    contactPhone: string

    /** 部门id */
    deptId: number

    /** 部门名称 */
    deptName: string

    /** 驾驶员姓名 */
    driverName: string

    /** 驾驶员ID */
    id: number

    /** 身份证号 */
    idCard: string

    /** 登录名 */
    loginName: string

    /** 使用卡种类型 */
    petrolCardTypes?: string

    /** 车辆ids */
    vehicleIds?: Array<number>

    /** 车牌号 */
    vehicleNum?: string
  }

  export class ThePlatformOffersNewParameters {
    /** 大图地址 */
    bigImgAddr: string

    /** 大图id */
    bigImgId?: string

    /** 优惠Details */
    proDetail: string

    /** 优惠结束时间 格式:yyyy-MM-dd HH:mm:ss */
    proEndTime: string

    /** 优惠开始时间 格式:yyyy-MM-dd HH:mm:ss */
    proStartTime: string

    /** 优惠标题 */
    proTitle: string

    /** 小图地址 */
    smallImgAddr?: string

    /** 小图id */
    smallImgId?: string

    /** 加油站ID */
    stationIds: Array<number>
  }

  export class TheReconciliationSubsidiaryEntities {
    /** 返点金额(分) */
    actRebate?: number

    /** 加油金额/抵扣运费（分） */
    actTotalPrice?: number

    /** 油卡类型 */
    cardTypeName?: string

    /** 所属公司名称 */
    companyName?: string

    /** 加油日期 */
    dateTime?: string

    /** 所属部门名称 */
    deptName?: string

    /** 获取方式 */
    detailSource?: string

    /** 加油撬编号 */
    deviceCode?: string

    /** 驾驶员名称 */
    driverName?: string

    /** 油枪编号 */
    gunCode?: string

    /** Details大图图片,多张图片','分隔 */
    imgBigPaths?: string

    /** Details小图图片,多张图片','分隔 */
    imgSmallPaths?: string

    /** 是否确认 */
    isConfirm?: string

    /** 是否允许核销 0-否 1-是 */
    isNeedVerification?: number

    /** 是否核销 0-否 1-是 */
    isVerification?: number

    /** 是否核销 0-否 1-是 */
    isVerificationDesc?: string

    /** 操作类型 0-充值 1-消费 2-退款 */
    opType?: number

    /** 操作类型 */
    opTypeDesc?: string

    /** 操作姓名 */
    operatorName?: string

    /** 加油订单号 */
    orderSerialNo?: string

    /** 油卡订单状态 */
    orderStatus?: string

    /** 油卡状态中文名称 */
    orderStatusName?: string

    /** 支付完成时间 */
    payFinishedTime?: string

    /** 油卡支付状态 */
    payStatus?: string

    /** 卡号 */
    petrolCardNum?: string

    /** 加油量（毫升） */
    petrolCount?: number

    /** 加油型号 */
    petrolNames?: string

    /** 退款完成时间 */
    refundFinishedTime?: string

    /** 结算金额(分) */
    settleMoney?: number

    /** 加油员 */
    stationEmpName?: string

    /** 加油站id */
    stationId?: number

    /** 加油站名称 */
    stationName?: string

    /** 油站所属 */
    stationSource?: number

    /** stationSourceDesc */
    stationSourceDesc?: string

    /** 操作人 （补单人） */
    supOpName?: string

    /** 万金油流水号 */
    thirdSerialNo?: string

    /** 交易方式 0-司机出示二维码(加油员扫码) 1-司机主动支付 2-实体卡 3-补单 */
    tradeType?: number

    /** 支付方式  */
    tradeTypeDesc?: string

    /** 车牌号名称 */
    vehicleNum?: string

    /** 核销时间 */
    verificationTime?: string
  }

  export class TheRefreshToken {
    /** refreshToken */
    refreshToken: string
  }

  export class TheRoleOfNewParameters {
    /** 菜单ID */
    menuIdList: Array<number>

    /** 机构ID */
    orgId: number

    /** 备注 */
    remark?: string

    /** 角色名称 */
    roleName: string
  }

  export class TheTeamOpenedByParameters {
    /** 部门id */
    deptId?: number

    /** 车辆id */
    vehicleId?: number
  }

  export class TheThirdPartyInstitution {
    /** 新增时间 */
    addTime?: string

    /** 联系人姓名 */
    contactName?: string

    /** 联系人电话 */
    contactPhone?: string

    /** id */
    id?: number

    /** 是否删除 1是 0否 */
    isDeleted?: number

    /** 最后同步时间 */
    lastSyncTime?: string

    /** 机构地址 */
    orgAddr?: string

    /** 机构编码 */
    orgCode?: string

    /** 机构名称 */
    orgName?: string

    /** 机构平台 0-G7 */
    orgPlatform?: number

    /** 机构类型 组织类型 0公司 1部门 */
    orgType?: number

    /** 云图机构id */
    ytOrgId?: number

    /** 云图机构名称 */
    ytOrgName?: string
  }

  export class TheUnlockCardDetails {
    /** 卡ID */
    cardId?: number

    /** 加油撬 */
    deviceCode?: string

    /** 驾驶员 */
    driverName?: string

    /** 锁定原因 0 驾驶员未确认 1油量为手工输入 */
    lockType?: number

    /** 锁定原因 */
    lockTypeDesc?: string

    /** 锁定时间 */
    opTime?: string

    /** 订单ID */
    orderId?: number

    /** 实际油量(ml) */
    petrolCount?: number

    /** 图片列表 */
    picList?: Array<string>

    /** 车牌号 */
    vehicleNum?: string
  }

  export class ThirdPartyParametersBound {
    /** TheThirdPartyInstitutionid */
    id: number

    /** 云图机构id */
    ytOrgId?: number
  }

  export class TigerBalmTopUpParameters {
    /** 充值金额(分) */
    depositMoney: number

    /** 账户id 1-万金油 2-G7 3-星油 4-团油 */
    id?: number

    /** 备注 */
    remark?: string
  }

  export class TigerBalmTopUpQueryConditions {
    /** 变化类型 0-充值 1-消费 */
    changeType?: number

    /** 结束日期 yyyy-MM-dd */
    endDate?: string

    /** 结束日期 yyyy-MM-dd HH:mm:ss */
    endTime?: string

    /** 结束日期 yyyy-MM-dd HH:mm:ss */
    endTimeStr?: string

    /** 类型 1-万金油 2-G7 3-星油 4-团油 */
    id?: number

    /** 开始日期 yyyy-MM-dd */
    startDate?: string

    /** 开始时间 yyyy-MM-dd HH:mm:ss */
    startTime?: string

    /** 开始时间 yyyy-MM-dd HH:mm:ss */
    startTimeStr?: string
  }

  export class ToMakeOutAnInvoice {
    /** 开票id */
    id: number
  }

  export class UserIDParameter {
    /** 用户ID */
    userId: number
  }

  export class UserPagingQueryParameters {
    /** 所属公司id */
    companyId?: number

    /** 用户帐号 */
    loginName?: string

    /** 推荐人id */
    referee?: number

    /** 角色名称 */
    roleName?: string

    /** 加油站id */
    stationId?: number

    /** 加油站名称 */
    stationName?: string

    /** 角色名称 */
    userName?: string

    /** 用户类型 0-加油员 1-驾驶员 2-公司人员 */
    userType?: number
  }

  export class UsersDisableEnableParameters {
    /** 状态  0：禁用   1：正常 */
    accountStatus: number

    /** 用户ID不能为空 */
    userId: number
  }

  export class VehicleInformationModifyParameters {
    /** 部门id */
    deptId: number

    /** 部门名称 */
    deptName: string

    /** 车辆id */
    id: number

    /** 车辆Oilid集合 */
    petrolIds: Array<number>

    /** 车牌号 只有自有车辆可以修改车牌 */
    vehicleNum?: string

    /** Modelsid */
    vehicleTypeId: number

    /** Models名称 */
    vehicleTypeName: string
  }

  export class VehicleInformationNewParameters {
    /** 公司id */
    companyId: number

    /** 公司名称 */
    companyName: string

    /** 部门id */
    deptId: number

    /** 部门名称 */
    deptName: string

    /** 车辆Oilid集合 */
    petrolIds?: Array<number>

    /** 车牌号 */
    vehicleNum: string

    /** 车辆类型 0-自有车辆 1-外协车辆 */
    vehicleType: number

    /** Modelsid */
    vehicleTypeId: number

    /** Models名称 */
    vehicleTypeName: string
  }

  export class VehicleProductInformation {
    /** 新增时间 */
    addTime?: string

    /** id */
    id?: number

    /** Oilid */
    petrolId?: number

    /** Oil名称 */
    petrolName?: string

    /** Oil类型 0-柴油 1-汽油 2-天然气 */
    petrolType?: number

    /** 车辆id */
    vehicleId?: number
  }

  export class VersionControl {
    /** 新增时间 */
    addTime?: string

    /** 版本下载地址 */
    appDownUrl?: string

    /** app类型 0-油卡app 1加油员app */
    appType?: number

    /** app类型 */
    appTypeDesc?: string

    /** 版本号，如1.0.1 */
    appVersion?: string

    /** 版本序号，如101 */
    appVersionNum?: number

    /** ID */
    id?: number

    /** 是否强制升级：0-不是 ，1-是 */
    isEnforceUpgrade?: number

    /** 是否强制升级 */
    isEnforceUpgradeDesc?: string

    /** 终端系统类型：操作系统 0-ios 1-android 2-harmony */
    opSystem?: number

    /** 终端系统类型 */
    opSystemDesc?: string
  }

  export class VersionControlToModifyParameters {
    /** 版本下载地址 */
    appDownUrl: string

    /** app类型 0-油卡app 1加油员app */
    appType: number

    /** 版本号，如1.0.1 */
    appVersion: string

    /** 版本序号，如101 */
    appVersionNum: number

    /** id */
    id?: number

    /** 是否强制升级：0-不是 ，1-是 */
    isEnforceUpgrade: number

    /** 终端系统类型：操作系统 0-ios 1-android 2-harmony */
    opSystem: number
  }

  export class WJYFuel {
    /** fuel_name */
    fuel_name?: string

    /** fuel_no */
    fuel_no?: string

    /** guide_price */
    guide_price?: string

    /** is_discount */
    is_discount?: number

    /** original_price */
    original_price?: string

    /** price */
    price?: string

    /** sf_id */
    sf_id?: string

    /** status */
    status?: string
  }

  export class WJYStation {
    /** address */
    address?: string

    /** areaCode */
    areaCode?: string

    /** brand_name */
    brand_name?: string

    /** channel */
    channel?: string

    /** cityCode */
    cityCode?: string

    /** fuels */
    fuels?: Array<defs.WJYFuel>

    /** h_ids */
    h_ids?: Array<string>

    /** isHighspeed */
    isHighspeed?: number

    /** isStop */
    isStop?: number

    /** is_input_money */
    is_input_money?: string

    /** lat */
    lat?: string

    /** lng */
    lng?: string

    /** logo */
    logo?: string

    /** open_time */
    open_time?: string

    /** provinceCode */
    provinceCode?: string

    /** sa_id */
    sa_id?: string

    /** stationId */
    stationId?: string

    /** stationName */
    stationName?: string

    /** status */
    status?: number
  }

  export class WhetherToEnableBindingEquipmentParameters {
    /** 状态  0：否   1：是 */
    status: number

    /** 用户ID不能为空 */
    userId: number
  }
}

declare namespace API {
  /**
   * 授信额度管理
   */
  export namespace cardCompanyConfig {
    /**
     * 入账
     * /base/credit/addCredit
     */
    export namespace addCredit {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.BookedParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 导出交易列表
     * /base/credit/export
     */
    export namespace exporting {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.CreditTransactionsQueryConditions): Promise<BaseResponse<Response>>
    }

    /**
        * 查询额度Details以及账户统计
companyId
        * /base/credit/findCreditAccount
        */
    export namespace findCreditAccount {
      export class QueryParams {
        /** 唯一id */
        companyId: number
      }

      export type Response = defs.ResultBean<defs.CreditAccount>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
        * 分页授信校验列表
where查询条件
        * /base/credit/pageList
        */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.CreditTransactionDetails>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.CreditTransactionsQueryConditions>): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 油费管理-发票管理
   */
  export namespace cardOpenInvoice {
    /**
     * 确认开票
     * /invoice/agreeInvoice
     */
    export namespace agreeInvoice {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ToMakeOutAnInvoice): Promise<BaseResponse<Response>>
    }

    /**
     * 导出明细列表
     * /invoice/exportDetailList
     */
    export namespace exportDetailList {
      export class QueryParams {
        /** 查询对应的Id */
        id: number
      }

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 导出管理列表
     * /invoice/exportOpenInvoiceList
     */
    export namespace exportOpenInvoiceList {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.QueryConditionsOfMakeOutInvoice): Promise<BaseResponse<Response>>
    }

    /**
     * 查询明细列表
     * /invoice/findOpenDetailListById
     */
    export namespace findOpenDetailListById {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.DetailedListOfMakeOutInvoice>>

      export const init: Response

      export function request(data: defs.IdParamsObject): Promise<BaseResponse<Response>>
    }

    /**
     * 查询Details
     * /invoice/findOpenInvoiceById
     */
    export namespace findOpenInvoiceById {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.TheInformationOfMakeOutInvoice>

      export const init: Response

      export function request(data: defs.IdParamsObject): Promise<BaseResponse<Response>>
    }

    /**
     * 分页查询管理列表
     * /invoice/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.TheInformationOfMakeOutInvoice>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.QueryConditionsOfMakeOutInvoice>): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 油卡充值导入
   */
  export namespace cardRechargeXls {
    /**
     * 公司油卡充值导入
     * /card/recharge/import/company
     */
    export namespace importCompanyFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 车队油卡充值导入
     * /card/recharge/import/vehicle
     */
    export namespace importVehicleFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 加油站-CommissionManagement
   */
  export namespace commissionManage {
    /**
     * 分页查询提现记录
     * /commissionManage/findCashOutPageList
     */
    export namespace findCashOutPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ExtractTheCommissionRecord>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ComeOnMemberID>): Promise<BaseResponse<Response>>
    }

    /**
     * 分页查询CommissionManagement列表
     * /commissionManage/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.CommissionManagement>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.CommissionManagementPagingQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     *  提现
     * /commissionManage/withDrawCommission
     */
    export namespace withDrawCommission {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.CommissionChangeParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 统计查询-佣金统计
   */
  export namespace commissionStat {
    /**
     * 导出佣金统计列表
     * /stat/export
     */
    export namespace exporting {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.CommissionManagementPagingQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 分页查询佣金统计列表
     * /stat/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.CommissionManagement>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.CommissionManagementPagingQueryParameters>): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 合作公司管理
   */
  export namespace company {
    /**
     * 新增合作公司
     * /base/company/add
     */
    export namespace add {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.TheNewCooperationCompanyParameters): Promise<BaseResponse<Response>>
    }

    /**
        * 删除合作公司
companyId
        * /base/company/del
        */
    export namespace del {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.TheNewCooperationCompanyParameters>

      export const init: Response

      export function request(data: defs.GroupIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 公司油卡状态修改
     * /base/company/disabledCompanyCard
     */
    export namespace disabledCompanyCard {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.StateOilCompanyCardIsDisabled): Promise<BaseResponse<Response>>
    }

    /**
     * 导出合作公司列表
     * /base/company/export
     */
    export namespace exporting {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.CompanyPagingQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
        * 获取公司Details
companyId
        * /base/company/getDetail
        */
    export namespace getDetail {
      export class QueryParams {
        /** 唯一id */
        companyId: number
      }

      export type Response = defs.ResultBean<defs.TheNewCooperationCompanyParameters>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
        * 公司分页列表
where查询条件
        * /base/company/pageList
        */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ReturnsTheEntityManagementList>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.CompanyPagingQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 修改
     * /base/company/update
     */
    export namespace update {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.TheNewCooperationCompanyParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 公司油卡
   */
  export namespace companyCard {
    /**
     * 导出公司油卡列表
     * /base/company/card/export
     */
    export namespace exporting {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.OilCompanyCardQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 导出交易明细列表
     * /base/company/card/exportCardDetails
     */
    export namespace exportCardDetails {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.OilCompanyCardTopUpEntities): Promise<BaseResponse<Response>>
    }

    /**
        * 查询油卡明细分页列表
where查询条件
        * /base/company/card/getCardDetailInfos
        */
    export namespace getCardDetailInfos {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.TheOilCardSubsidiaryReturnDetails>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.TheOilCardSubsidiaryQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
        * 查询公司余额信息
查询公司余额信息
        * /base/company/card/getMainCardAccountInfo
        */
    export namespace getCardAccountInfosByCompanyId {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.CardInfoExtObject>

      export const init: Response

      export function request(data: defs.QueryParameterClassPrincipalCardAccount): Promise<BaseResponse<Response>>
    }

    /**
        * 查询公司主卡余额信息
切换主卡类型时调用
        * /base/company/card/getMainCardBalanceInfo
        */
    export namespace getMainCardBalanceInfo {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.PrincipalCardTopUpParameterClass>

      export const init: Response

      export function request(data: defs.PrincipalCardTopUpParameterClass): Promise<BaseResponse<Response>>
    }

    /**
     * 查询公司油卡充值明细
     * /base/company/card/getRechargeInfoByCardId
     */
    export namespace getRechargeInfoByCardId {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.OilCompanyCardTopUpEntities>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.OilCompanyCardTopUpEntities>): Promise<BaseResponse<Response>>
    }

    /**
        * 公司分页列表
where查询条件
        * /base/company/card/pageList
        */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.OilCompanyStatisticalInterfaceCardObjects>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.OilCompanyCardQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 主卡充值
     * /base/company/card/rechargeMainCard
     */
    export namespace rechargeMainCard {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.CloudOilCardMasterCardParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 主卡禁用启用
     * /base/company/card/updateCardStatus
     */
    export namespace updateCardStatus {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.OilCardDisabledStateIsEnabled): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 字典数据
   */
  export namespace dictionary {
    /**
     * 查询系统配置信息
     * /dict/findBySysConfigType
     */
    export namespace findBySysConfigType {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.SysConfigEntity>

      export const init: Response

      export function request(data: defs.SystemConfigurationQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 查询城市列表根据省份编码
     * /dict/findCityListByProvince
     */
    export namespace findCityListByProvince {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.Area>>

      export const init: Response

      export function request(data: defs.RegionEncodingParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 查询Oil列表 加油撬的
     * /dict/findDevicePetrolList
     */
    export namespace findDevicePetrolList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.Oil>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 查询Oil列表
     * /dict/findPetrolList
     */
    export namespace findPetrolList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.Oil>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 根据Area编码查询Provinces信息
     * /dict/findProCityRegionByRegion
     */
    export namespace findProCityRegionByRegion {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.Provinces>

      export const init: Response

      export function request(data: defs.RegionEncodingParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 查询省份列表
     * /dict/findProvinceList
     */
    export namespace findProvinceList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.Area>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 查询充值账户类型
     * /dict/findRechargeAccountTypeList
     */
    export namespace findRechargeAccountTypeList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.EnumVo>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 查询地区列表根据城市编码
     * /dict/findRegionListByCity
     */
    export namespace findRegionListByCity {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.Area>>

      export const init: Response

      export function request(data: defs.RegionEncodingParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 油站加盟审核状态枚举
     * /dict/findResCheckStatusEnumList
     */
    export namespace findResCheckStatusEnumList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.EnumVo>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 适用油卡枚举
     * /dict/findResPetrolCardTypeEnumList
     */
    export namespace findResPetrolCardTypeEnumList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.EnumVo>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 加油站来源枚举
     * /dict/findResStationSourceEnumList
     */
    export namespace findResStationSourceEnumList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.EnumVo>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 加盟方式枚举
     * /dict/findResUnionWayEnumList
     */
    export namespace findResUnionWayEnumList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.EnumVo>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 查询车辆类型列表
     * /dict/findVehicleTypeList
     */
    export namespace findVehicleTypeList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.Models>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 电子油卡-油卡总览
   */
  export namespace elecCard {
    /**
     * 油卡总览-ComeOnStatisticalchart
     * /card/overview/refuelTotal
     */
    export namespace refuelTotal {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.ComeOnStatistical>>

      export const init: Response

      export function request(data: defs.OilCardStatisticalQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 油卡总览-数值统计
     * /card/overview/total
     */
    export namespace cardTotal {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.ElectronicOilCardStatistics>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 油卡总览-车队油卡统计chart
     * /card/overview/vehicleCardTotal
     */
    export namespace vehicleCardTotal {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.ComeOnStatistical>>

      export const init: Response

      export function request(data: defs.OilCardStatisticalQueryParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 车队电子油卡
   */
  export namespace elecVehicleCard {
    /**
     * ComeOnDetail列表分页
     * /elecCard/vehicle/CardRefuelListPage
     */
    export namespace cardRefuelListPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ComeOnDetail>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.OilCardDetailedQuery>): Promise<BaseResponse<Response>>
    }

    /**
     * 油卡明细列表分页
     * /elecCard/vehicle/cardDepositListPage
     */
    export namespace cardDepositListPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.CardPetrolDepositObject>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.OilCardDetailedQuery>): Promise<BaseResponse<Response>>
    }

    /**
     * 油卡列表
     * /elecCard/vehicle/cardInfoListPage
     */
    export namespace cardInfoListPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.OilTeamElectronicCard>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ElectronicOilCardQueryObject>): Promise<BaseResponse<Response>>
    }

    /**
     * 车队油卡管理导出
     * /elecCard/vehicle/exportFile
     */
    export namespace exportFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ElectronicOilCardQueryObject): Promise<BaseResponse<Response>>
    }

    /**
     * 车队油卡充值模版下载
     * /elecCard/vehicle/exportTemplateFile
     */
    export namespace exportTemplateFile {
      export class QueryParams {
        /** 公司Id */
        companyId?: number
        /** 公司名称 */
        companyName?: string
        /** 部门id */
        deptId?: number
        /** 部门名称 */
        deptName?: string
        /** 卡号 */
        petrolCardNum?: string
        /** 车牌号 */
        vehicleNum?: string
        /** 车辆类型 0-自有车辆 1-外协车辆 */
        vehicleType?: number
        /** 登录名 */
        loginName?: string
        /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
        cardStatus?: number
        /** 油卡类型 */
        petrolCardType?: number
      }

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 查询油卡解锁Details
     * /elecCard/vehicle/findUnLockCardDetail
     */
    export namespace findUnLockCardDetail {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.TheUnlockCardDetails>

      export const init: Response

      export function request(data: defs.IdParamsObject): Promise<BaseResponse<Response>>
    }

    /**
     * 开卡
     * /elecCard/vehicle/openCard
     */
    export namespace openCard {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.TheTeamOpenedByParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 充卡
     * /elecCard/vehicle/recharge
     */
    export namespace recharge {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.OilCardTopUpParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 油卡解锁
     * /elecCard/vehicle/unlockCard
     */
    export namespace unlockCard {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.TheUnlockCardDetails>

      export const init: Response

      export function request(data: defs.OilCardUnlockParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 充值万金油（三方平台）管理
   */
  export namespace elecWjyCard {
    /**
     * 充值列表导出
     * /elecCard/wjy/exportFile
     */
    export namespace exportFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.TigerBalmTopUpQueryConditions): Promise<BaseResponse<Response>>
    }

    /**
     * 充值
     * /elecCard/wjy/recharge
     */
    export namespace recharge {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.TigerBalmTopUpParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 充值列表
     * /elecCard/wjy/rechargeList
     */
    export namespace rechargeListPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.AllAccountTransactionHistory>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.TigerBalmTopUpQueryConditions>): Promise<BaseResponse<Response>>
    }

    /**
     * 充值统计
     * /elecCard/wjy/rechargeTotal
     */
    export namespace rechargeTotal {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.AllAccountInformation>

      export const init: Response

      export function request(data: defs.TigerBalmTopUpQueryConditions): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 云途电子油卡
   */
  export namespace elecYutuCard {
    /**
     * 云途油卡管理列表
     * /elecCard/yuTu/cardInfoListPage
     */
    export namespace cardInfoListByPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.CloudElectronicOilClipCardObjects>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ElectronicOilCardQueryObject>): Promise<BaseResponse<Response>>
    }

    /**
     * 云途油卡账户操作
     * /elecCard/yuTu/cardOperate
     */
    export namespace cardOperate {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.OilCardOperationParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 云途油卡转账列表
     * /elecCard/yuTu/cardTransferByPage
     */
    export namespace getCardTransferLogByPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.CardTransferLogObject>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.OilCardTransferDetailedQuery>): Promise<BaseResponse<Response>>
    }

    /**
     * 云途油卡明细列表
     * /elecCard/yuTu/changeLogListByPage
     */
    export namespace changeLogListByPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.CloudOilCardChangeObjects>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.CloudOilCardChangeDetailParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 云途油卡管理导出
     * /elecCard/yuTu/exportFile
     */
    export namespace exportFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ElectronicOilCardQueryObject): Promise<BaseResponse<Response>>
    }

    /**
     * 云途油卡管理导出所有充值记录
     * /elecCard/yuTu/exportFileAll
     */
    export namespace exportFileAll {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ElectronicOilCardQueryObject): Promise<BaseResponse<Response>>
    }

    /**
     * 云途油卡充值模版下载
     * /elecCard/yuTu/exportTemplateFile
     */
    export namespace exportTemplateFile {
      export class QueryParams {
        /** 公司Id */
        companyId?: number
        /** 公司名称 */
        companyName?: string
        /** 部门id */
        deptId?: number
        /** 部门名称 */
        deptName?: string
        /** 卡号 */
        petrolCardNum?: string
        /** 车牌号 */
        vehicleNum?: string
        /** 车辆类型 0-自有车辆 1-外协车辆 */
        vehicleType?: number
        /** 登录名 */
        loginName?: string
        /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
        cardStatus?: number
        /** 油卡类型 */
        petrolCardType?: number
      }

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 云途油卡转账列表导出
     * /elecCard/yuTu/exportTransferFile
     */
    export namespace exportTransferFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.OilCardTransferDetailedQuery): Promise<BaseResponse<Response>>
    }

    /**
     * 云途油卡子卡充值（主卡划拨给子卡）
     * /elecCard/yuTu/rechargeSubCard
     */
    export namespace yutuCardTransfer {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.CloudOilClipCardTopParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 云途油卡启用禁用
     * /elecCard/yuTu/updateCardStatus
     */
    export namespace updateCardStatus {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.OilCardDisabledStateIsEnabled): Promise<BaseResponse<Response>>
    }
  }

  /**
   * excel导入导出
   */
  export namespace excel {
    /**
     * 商品列表导出
     * /excel/goodsExportFile
     */
    export namespace goodsExportFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.MallGoodsPageQueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 订单列表导出
     * /excel/orderExportFile
     */
    export namespace orderExportFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.MallOrderPageQueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 油价列表导出
     * /excel/priceExportFile
     */
    export namespace priceExportFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ResPetrolStationPageParams): Promise<BaseResponse<Response>>
    }

    /**
     * 加油站列表导出
     * /excel/stationExportFile
     */
    export namespace stationExportFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ResPetrolStationPageParams): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 文件上传
   */
  export namespace fileUpload {
    /**
     * 文件上传
     * /upload/uploadFile
     */
    export namespace uploadImg {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.FileUploadResponse>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 油费管理
   */
  export namespace fuelFee {
    /**
     * 公司对账明细
     * /fuel/fee/companyReconciliationDetail
     */
    export namespace companyReconciliationDetail {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.TheReconciliationSubsidiaryEntities>>

      export const init: Response

      export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 公司对账明细分页
     * /fuel/fee/companyReconciliationDetailPageList
     */
    export namespace companyReconciliationDetailPageList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.TheReconciliationSubsidiaryEntities>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ComeOnReconciliationQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 公司对账分页列表
     * /fuel/fee/companyReconciliationPageList
     */
    export namespace companyReconciliationPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ComeOnReconciliationPageListsCompany>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ComeOnReconciliationQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 公司对账导出
     * /fuel/fee/exportCompanyReconciliation
     */
    export namespace exportCompanyReconciliation {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 公司对账Details导出
     * /fuel/fee/exportCompanyReconciliationDetail
     */
    export namespace exportCompanyReconciliationDetail {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 加油橇对账导出
     * /fuel/fee/exportRefuelingSkidReconciliation
     */
    export namespace exportRefuelingSkidReconciliation {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 加油橇Details对账导出
     * /fuel/fee/exportRefuelingSkidReconciliationDetail
     */
    export namespace exportRefuelingSkidReconciliationDetail {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 加油站对账导出
     * /fuel/fee/exportStationReconciliation
     */
    export namespace exportStationReconciliation {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 加油站Details对账导出
     * /fuel/fee/exportStationReconciliationDetail
     */
    export namespace exportStationReconciliationDetail {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 查看预充值
     * /fuel/fee/findStationAccount
     */
    export namespace findStationAccount {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.IdParamsObject): Promise<BaseResponse<Response>>
    }

    /**
     * 查看预充值统计
     * /fuel/fee/findStationAccountStat
     */
    export namespace findStationAccountStat {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 加油总览列表数据
     * /fuel/fee/getChartData
     */
    export namespace getChartData {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.ComeOnTheOverviewScreenObjects>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 预充值
     * /fuel/fee/rechargeStationAccount
     */
    export namespace rechargeStationAccount {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.GasStationAccountParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 加油橇对账Details接口
     * /fuel/fee/refuelingSkidReconciliationDetail
     */
    export namespace refuelingSkidReconciliationDetail {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.TheReconciliationSubsidiaryEntities>>

      export const init: Response

      export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 加油橇对账Details分页接口
     * /fuel/fee/refuelingSkidReconciliationDetailPageList
     */
    export namespace refuelingSkidReconciliationDetailPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.TheReconciliationSubsidiaryEntities>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ComeOnReconciliationQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 加油橇对账分页接口
     * /fuel/fee/refuelingSkidReconciliationPageList
     */
    export namespace refuelingSkidReconciliationPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ComeOnReconciliationPageListsCompany>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ComeOnReconciliationQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 加油站对账明细
     * /fuel/fee/stationReconciliationDetail
     */
    export namespace stationReconciliationDetail {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.TheReconciliationSubsidiaryEntities>>

      export const init: Response

      export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 加油站对账明细分页
     * /fuel/fee/stationReconciliationDetailPageList
     */
    export namespace stationReconciliationDetailPageList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.TheReconciliationSubsidiaryEntities>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ComeOnReconciliationQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 加油站对账
     * /fuel/fee/stationReconciliationPageList
     */
    export namespace stationReconciliationPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ComeOnReconciliationPageListsCompany>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ComeOnReconciliationQueryParameters>): Promise<BaseResponse<Response>>
    }
  }

  /**
   * G 7 Controller
   */
  export namespace g7 {
    /**
     * syncPetrolStations
     * /g7/syncPetrolStations
     */
    export namespace syncPetrolStations {
      export class QueryParams {}

      export type Response = defs.G7RestResult

      export const init: Response

      export function request(data: string): Promise<BaseResponse<Response>>
    }
  }

  /**
   * Group Oil Controller
   */
  export namespace groupOil {
    /**
     * manualNotify
     * /groupOil/manualNotify
     */
    export namespace manualNotify {
      export class QueryParams {
        /** gasId */
        gasId?: string
      }

      export type Response = string

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * notify
     * /groupOil/notify
     */
    export namespace notify {
      export class QueryParams {}

      export type Response = string

      export const init: Response

      export function request(data: defs.NotifyEntity): Promise<BaseResponse<Response>>
    }

    /**
     * syncPetrolStations
     * /groupOil/syncPetrolStations
     */
    export namespace syncPetrolStations {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 商城商品
   */
  export namespace mallGoods {
    /**
     * 删除商品
     * /mall/goods/del
     */
    export namespace delGoods {
      export class QueryParams {
        /** 商品id */
        goodsId?: number
      }

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 获取商品Details
     * /mall/goods/getDetail
     */
    export namespace getMallGoodsById {
      export class QueryParams {
        /** 商品id */
        goodsId?: number
      }

      export type Response = defs.ResultBean<defs.MallGoodsWithImg>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 获取商品列表数据
     * /mall/goods/pageList
     */
    export namespace goodsPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.MallGoods>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.MallGoodsPageQueryParams>): Promise<BaseResponse<Response>>
    }

    /**
     * 保存商品信息
     * /mall/goods/save
     */
    export namespace saveGoods {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.MallGoodsWithImg): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 商城订单
   */
  export namespace mallOrder {
    /**
     * 新增订单信息
     * /mall/order/applyOrder
     */
    export namespace applyOrder {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.MallOrderApplyParams): Promise<BaseResponse<Response>>
    }

    /**
     * 处理订单信息
     * /mall/order/deal
     */
    export namespace deal {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.MallOrderDealParams): Promise<BaseResponse<Response>>
    }

    /**
     * 进入订单信息编辑页面
     * /mall/order/getDetail
     */
    export namespace getMallOrderById {
      export class QueryParams {
        /** 订单id */
        orderId?: number
      }

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 获取订单信息列表数据
     * /mall/order/pageList
     */
    export namespace orderPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.MallOrder>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.MallOrderPageQueryParams>): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 加油站-加油员信息
   */
  export namespace oilUser {
    /**
     * 删除
     * /base/oilDriver/del
     */
    export namespace del {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.TheNewCooperationCompanyParameters>

      export const init: Response

      export function request(data: defs.UserIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 导出加油员列表
     * /base/oilDriver/export
     */
    export namespace exporting {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 分页查询加油员列表
     * /base/oilDriver/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.SysUserEntityObject>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.UserPagingQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 新增
     * /base/oilDriver/save
     */
    export namespace saveOilUser {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.TheOperatorsOfNewParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 修改
     * /base/oilDriver/update
     */
    export namespace update {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.TheOperatorsToModifyParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 车辆管理
   */
  export namespace resCompanyVehicle {
    /**
     * 新增公司车辆
     * /base/vehicle/add
     */
    export namespace add {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.VehicleInformationNewParameters): Promise<BaseResponse<Response>>
    }

    /**
        * 删除车辆信息
车辆id
        * /base/vehicle/del
        */
    export namespace del {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.CompanyVehicleInformation>

      export const init: Response

      export function request(data: defs.IdParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 导出车辆列表
     * /base/vehicle/export
     */
    export namespace exporting {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.CompanyVehicleInformation): Promise<BaseResponse<Response>>
    }

    /**
        * 获取车辆Details
id
        * /base/vehicle/getDetail
        */
    export namespace getDetail {
      export class QueryParams {
        /** 唯一id */
        id: number
      }

      export type Response = defs.ResultBean<defs.CompanyVehicleInformation>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
        * 根据部门id查询车辆信息集合
部门id
        * /base/vehicle/getListByCompanyIdOrDeptId
        */
    export namespace getListByCompanyIdOrDeptId {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.CompanyVehicleInformation>>

      export const init: Response

      export function request(data: defs.AccordingToTheOrganizationOrDepartment): Promise<BaseResponse<Response>>
    }

    /**
        * 根据部门id查询无油卡的有驾驶员的车辆信息
id 部门id
        * /base/vehicle/getVehicleListByDeptId
        */
    export namespace getVehicleListByDeptId {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.CompanyVehicleInformation>>

      export const init: Response

      export function request(data: defs.AccordingToTheOrganizationOrDepartment): Promise<BaseResponse<Response>>
    }

    /**
     * 导入车辆
     * /base/vehicle/import
     */
    export namespace importFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
        * 车辆分页列表
where查询条件
        * /base/vehicle/pageList
        */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.CompanyVehicleInformation>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.CompanyVehicleInformation>): Promise<BaseResponse<Response>>
    }

    /**
     * 修改
     * /base/vehicle/update
     */
    export namespace update {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.VehicleInformationModifyParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * Oil管理
   */
  export namespace resPetrol {
    /**
     * 获取Oil列表
     * /base/resPetrol/findPetrolList
     */
    export namespace findPetrolList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.Oil>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 新增Oil
     * /base/resPetrol/savePetrol
     */
    export namespace savePetrol {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ProductOfNewParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 修改Oil
     * /base/resPetrol/updatePetrol
     */
    export namespace updatePetrol {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ProductModificationParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 加油站油价信息管理
   */
  export namespace resPetrolPrice {
    /**
     * 根据id获取单个油价信息
     * /base/resPetrolPrice/getDetail
     */
    export namespace getResPetrolPriceById {
      export class QueryParams {
        /** 油价id */
        id?: number
      }

      export type Response = defs.ResultBean<defs.ResPetrolPrice>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 进入加油站油价信息编辑页面
     * /base/resPetrolPrice/getDetailByStationId
     */
    export namespace getResPetrolPriceByStationId {
      export class QueryParams {
        /** 油站id */
        stationId?: number
      }

      export type Response = defs.ResultBean<defs.ResPetrolPriceDto>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 获取加油站油价列表
     * /base/resPetrolPrice/pageList
     */
    export namespace resPetrolStationPricePage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ResPetrolPriceDto>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ResPetrolStationPageParams>): Promise<BaseResponse<Response>>
    }

    /**
     * 新增加油站油价信息
     * /base/resPetrolPrice/save
     */
    export namespace resPetrolPriceSave {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ResPetrolPriceDto): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 加油站信息管理
   */
  export namespace resPetrolStation {
    /**
     * 加油站审核
     * /base/resPetrolStation/audit
     */
    export namespace resPetrolStationAudit {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ResPetrolStationAuditParams): Promise<BaseResponse<Response>>
    }

    /**
        * 获取加油站加盟审核列表数据
where查询条件
        * /base/resPetrolStation/auditPageList
        */
    export namespace auditPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ResPetrolStation>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ResPetrolStationPageParams>): Promise<BaseResponse<Response>>
    }

    /**
     * 根据id删除加油站信息
     * /base/resPetrolStation/del
     */
    export namespace delResPetrolStationById {
      export class QueryParams {
        /** 油站id */
        id?: number
      }

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 根据名称获取加油站信息列表数据
     * /base/resPetrolStation/findPetrolIdsByFuzzyStationName
     */
    export namespace findPetrolIdsByFuzzyStationName {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<number>>

      export const init: Response

      export function request(data: string): Promise<BaseResponse<Response>>
    }

    /**
     * 根据加油站名称模糊查询  查询加油站列表
     * /base/resPetrolStation/findPetrolListByFuzzyStationName
     */
    export namespace findPetrolListByFuzzyStationName {
      export class QueryParams {
        /** 加油站名称 */
        stationName?: string
      }

      export type Response = defs.ResultBean<Array<defs.PetrolStationNameEntity>>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 加油站Details
     * /base/resPetrolStation/getDetail
     */
    export namespace getResPetrolStationById {
      export class QueryParams {
        /** 油站id */
        id?: number
      }

      export type Response = defs.ResultBean<defs.ResPetrolStationSaveParams>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
        * 获取加油站信息列表数据
where查询条件
        * /base/resPetrolStation/pageList
        */
    export namespace getResPetrolStationByPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ResPetrolStation>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ResPetrolStationPageParams>): Promise<BaseResponse<Response>>
    }

    /**
     * 加油站启用停用
     * /base/resPetrolStation/resPetrolStationEnable
     */
    export namespace resPetrolStationEnable {
      export class QueryParams {}

      export type Response = defs.ResultBean<number>

      export const init: Response

      export function request(data: defs.ResPetrolStationEnableParams): Promise<BaseResponse<Response>>
    }

    /**
     * 加油站锁卡状态修改
     * /base/resPetrolStation/resPetrolStationLockCard
     */
    export namespace resPetrolStationLockCard {
      export class QueryParams {}

      export type Response = defs.ResultBean<number>

      export const init: Response

      export function request(data: defs.ResPetrolStationLockCardParams): Promise<BaseResponse<Response>>
    }

    /**
     * 加油站隐藏显示
     * /base/resPetrolStation/resPetrolStationShow
     */
    export namespace resPetrolStationShow {
      export class QueryParams {}

      export type Response = defs.ResultBean<number>

      export const init: Response

      export function request(data: defs.ResPetrolStationShowParams): Promise<BaseResponse<Response>>
    }

    /**
     * 保存加油站信息
     * /base/resPetrolStation/save
     */
    export namespace save {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ResPetrolStationSaveParams): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 加GasStationCollation
   */
  export namespace resPetrolStationOrderby {
    /**
     * 启用禁用
     * /base/resPetrolStationOrderby/enabled
     */
    export namespace enabled {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ResPetrolStationOrderbyEnableParams): Promise<BaseResponse<Response>>
    }

    /**
     * 获取列表
     * /base/resPetrolStationOrderby/findList
     */
    export namespace findList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.GasStationCollation>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 系统设置-优惠信息管理
   */
  export namespace resPlatPromotion {
    /**
     * 删除优惠信息
     * /base/platPromotion/delById
     */
    export namespace delById {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.IdParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 根据ID查询优惠信息
     * /base/platPromotion/findById
     */
    export namespace findById {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.PreferentialInformationPlatform>

      export const init: Response

      export function request(data: defs.IdParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 分页查询优惠信息列表
     * /base/platPromotion/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.PreferentialInformationPlatform>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.PreferentialInformationPlatformPagingQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 新增优惠信息
     * /base/platPromotion/save
     */
    export namespace save {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ThePlatformOffersNewParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 修改优惠信息
     * /base/platPromotion/updateById
     */
    export namespace updateById {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.PlatformOffersInformationToModifyParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 系统设置-内容审核
   */
  export namespace resPublishInfo {
    /**
     * 审核
     * /base/resPublishInfo/audit
     */
    export namespace audit {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ReviewTheParametersInARelease): Promise<BaseResponse<Response>>
    }

    /**
     * 删除
     * /base/resPublishInfo/del
     */
    export namespace del {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.DeleteTheParameterInARelease): Promise<BaseResponse<Response>>
    }

    /**
     * 查询Details
     * /base/resPublishInfo/findById
     */
    export namespace findById {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.Details>

      export const init: Response

      export function request(data: defs.IdParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 查询列表
     * /base/resPublishInfo/pageList
     */
    export namespace appPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.Details>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ReleaseInformationQueryConditions>): Promise<BaseResponse<Response>>
    }

    /**
     * 新增
     * /base/resPublishInfo/save
     */
    export namespace add {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.NewParametersInANewsRelease): Promise<BaseResponse<Response>>
    }

    /**
     * 修改
     * /base/resPublishInfo/update
     */
    export namespace update {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ModifyTheParameterInARelease): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 司机加盟
   */
  export namespace resSelfDriverAudit {
    /**
     * 审核
     * /base/selfDriverAudit/audit
     */
    export namespace audit {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.TheDriverToAuditStatusParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 导出加盟审核列表
     * /base/selfDriverAudit/exportAuditList
     */
    export namespace exportAuditList {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.JoinThePagingParametersList): Promise<BaseResponse<Response>>
    }

    /**
     * 导出加盟信息列表
     * /base/selfDriverAudit/exportJointList
     */
    export namespace exportJointList {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.JoinThePagingParametersList): Promise<BaseResponse<Response>>
    }

    /**
     * 分页查询加盟审核列表
     * /base/selfDriverAudit/findAuditPageList
     */
    export namespace findAuditPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.TheDriverToJoinAudit>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.JoinThePagingParametersList>): Promise<BaseResponse<Response>>
    }

    /**
     * 查询Details
     * /base/selfDriverAudit/findById
     */
    export namespace findById {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.TheDriverToJoinAudit>

      export const init: Response

      export function request(data: defs.IdParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 分页查询加盟信息列表
     * /base/selfDriverAudit/findJointPageList
     */
    export namespace findJointPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.TheDriverToJoinAudit>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.JoinThePagingParametersList>): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 加油站优惠信息管理
   */
  export namespace resStationPromotion {
    /**
     * 根据id删除加油站优惠信息
     * /base/resStationPromotion/delResStationPromotionById
     */
    export namespace delResStationPromotionById {
      export class QueryParams {
        /** 优惠信息id */
        id?: number
      }

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 进入加油站优惠信息编辑页面
     * /base/resStationPromotion/getResStationPromotionById
     */
    export namespace getResStationPromotionById {
      export class QueryParams {
        /** 优惠信息id */
        id?: number
      }

      export type Response = defs.ResultBean<defs.ResStationPromotion>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 获取加油站优惠信息分页列表
     * /base/resStationPromotion/resStationPromotionPage
     */
    export namespace resStationPromotionPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ResStationPromotionDto>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ResPetrolStationPageParams>): Promise<BaseResponse<Response>>
    }

    /**
     * 保存加油站优惠信息
     * /base/resStationPromotion/resStationPromotionSave
     */
    export namespace resStationPromotionSave {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ResStationPromotion): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 驾驶员管理
   */
  export namespace resVehicleDriver {
    /**
     * 新增驾驶员
     * /base/driver/add
     */
    export namespace add {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ThePilotOfNewParameterObject): Promise<BaseResponse<Response>>
    }

    /**
     * 删除驾驶员信息
     * /base/driver/del
     */
    export namespace del {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.IdParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 设备绑定开关
     * /base/driver/deviceBindSwitch
     */
    export namespace deviceBindSwitch {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.WhetherToEnableBindingEquipmentParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 导出车辆列表
     * /base/driver/export
     */
    export namespace exporting {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.TheDriverManagementQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 查询BindingLog
     * /base/driver/findBindingLogList
     */
    export namespace findBindingLogList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.BindingLog>>

      export const init: Response

      export function request(data: defs.IdParameter): Promise<BaseResponse<Response>>
    }

    /**
        * 获取驾驶员Details
id
        * /base/driver/getDetail
        */
    export namespace getDetail {
      export class QueryParams {
        /** 唯一id */
        id: number
      }

      export type Response = defs.ResultBean<defs.ThePilotOfNewParameterObject>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 导入驾驶员
     * /base/driver/import
     */
    export namespace importFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
        * 驾驶员分页列表
where查询条件
        * /base/driver/pageList
        */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ThePilotListManagementReturnObjects>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.TheDriverManagementQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
        * 重置密码
重置驾驶员密码
        * /base/driver/passwordReset
        */
    export namespace passwordReset {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.UserIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 解绑设备
     * /base/driver/unbind
     */
    export namespace unbind {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.IdParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 修改驾驶员信息
     * /base/driver/update
     */
    export namespace update {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ThePilotOfNewParameterObject): Promise<BaseResponse<Response>>
    }
  }

  /**
   * Models信息管理
   */
  export namespace resVehicleType {
    /**
     * 根据id删除Models信息
     * /api/base/vehicleType/del
     */
    export namespace del {
      export class QueryParams {
        /** Modelsid */
        id?: number
      }

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 进入Models信息编辑页面
     * /api/base/vehicleType/getDetail
     */
    export namespace getDetail {
      export class QueryParams {
        /** Modelsid */
        id?: number
      }

      export type Response = defs.ResultBean<defs.Models>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 获取加油站加盟审核列表数据
     * /api/base/vehicleType/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.Models>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.Models>): Promise<BaseResponse<Response>>
    }

    /**
     * 新增Models信息
     * /api/base/vehicleType/save
     */
    export namespace save {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.Models): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 实体油卡
   */
  export namespace stYutuCard {
    /**
     * 油卡分配
     * /shitiCard/yuTu/bindCard
     */
    export namespace bindCard {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.PhysicalOilBindingLogCardVehicles): Promise<BaseResponse<Response>>
    }

    /**
     * 查询BindingLog分页列表
     * /shitiCard/yuTu/bindLogPageList
     */
    export namespace bindLogPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ResPhysicalBindingLog>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.PhysicalOilCardBindingQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 实体油卡管理列表
     * /shitiCard/yuTu/cardInfoListPage
     */
    export namespace cardInfoListByPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.CloudElectronicOilClipCardObjects>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ElectronicOilCardQueryObject>): Promise<BaseResponse<Response>>
    }

    /**
     * 实体油卡明细列表
     * /shitiCard/yuTu/changeLogListByPage
     */
    export namespace changeLogListByPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.CloudOilCardChangeObjects>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.CloudOilCardChangeDetailParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 实体油卡管理导出
     * /shitiCard/yuTu/exportFile
     */
    export namespace exportFile {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ElectronicOilCardQueryObject): Promise<BaseResponse<Response>>
    }

    /**
     * 实体油卡管理导出所有充值记录
     * /shitiCard/yuTu/exportFileAll
     */
    export namespace exportFileAll {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ElectronicOilCardQueryObject): Promise<BaseResponse<Response>>
    }

    /**
     * 选择车辆
     * /shitiCard/yuTu/getVehicleListByDeptId
     */
    export namespace getVehicleListByDeptId {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.CompanyVehicleInformation>>

      export const init: Response

      export function request(data: defs.AccordingToTheOrganizationOrDepartment): Promise<BaseResponse<Response>>
    }

    /**
     * 选择部门(添加、修改菜单)
     * /shitiCard/yuTu/selectByOrgId
     */
    export namespace selectByOrgId {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.SysDeptEntityObject>>

      export const init: Response

      export function request(data: defs.GroupIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 选择公司(添加、修改菜单)
     * /shitiCard/yuTu/selectOrgList
     */
    export namespace selectOrgList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.SysDeptEntityObject>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }
  }

  /**
   * Star Controller
   */
  export namespace star {
    /**
     * 主动拉取全量星油油站
     * /star/fetchStarOilSiteInfo
     */
    export namespace fetchStarOilSiteInfo {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * syncPetrolStations
     * /star/syncPetrolStations
     */
    export namespace syncPetrolStations {
      export class QueryParams {}

      export type Response = defs.StarRestResult

      export const init: Response

      export function request(data: defs.StarSyncCommonParams): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 系统设置-ACommissionSetUp
   */
  export namespace stationCommission {
    /**
     * 启用/禁用加油站ACommissionSetUp
     * /stationCommission/enabled
     */
    export namespace enabled {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ACommissionSetUp): Promise<BaseResponse<Response>>
    }

    /**
     * 导出列表
     * /stationCommission/export
     */
    export namespace exporting {
      export class QueryParams {
        /** 加油站id */
        stationId?: number
      }

      export type Response = any

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 根据加油站查询加油站ACommissionSetUp
     * /stationCommission/findByStationId
     */
    export namespace findByStationId {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.CommissionSetUpDetails>

      export const init: Response

      export function request(data: defs.GasStationIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 分页查询CommissionSetList
     * /stationCommission/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.CommissionSetList>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.CommissionSetThePagingQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 批量编辑加油站ACommissionSetUp
     * /stationCommission/updateBatch
     */
    export namespace updateBatch {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.BatchCommissionSet): Promise<BaseResponse<Response>>
    }

    /**
     * 编辑加油站ACommissionSetUp
     * /stationCommission/updateByStationId
     */
    export namespace updateByStationId {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.CommissionSetUpToModifyParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 统计查询
   */
  export namespace statistics {
    /**
        * 根据车辆id查询油卡集合
车辆id
        * /statistics/cardInfoListByVehicleId
        */
    export namespace cardInfoListByVehicleId {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.CloudElectronicOilClipCardObjects>>

      export const init: Response

      export function request(data: defs.IdParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 导出公司ComeOnStatistical列表
     * /statistics/exportCompany
     */
    export namespace exportCompany {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.CompanyComeOnStatisticalPagingConditions): Promise<BaseResponse<Response>>
    }

    /**
     * 导出公司ComeOnDetail统计列表
     * /statistics/exportCompanyDetail
     */
    export namespace exportCompanyDetail {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.CompanyComeOnStatisticalSubsidiaryConditions): Promise<BaseResponse<Response>>
    }

    /**
     * 导出订单列表
     * /statistics/exportWJY
     */
    export namespace exportWJY {
      export class QueryParams {}

      export type Response = any

      export const init: Response

      export function request(data: defs.ComeOnStatisticalQueryParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 根据加油站名称模糊查询   查询加油站列表
     * /statistics/findPetrolListByFuzzyStationName
     */
    export namespace findPetrolListByFuzzyStationName {
      export class QueryParams {
        /** 加油站名称 */
        stationName?: string
      }

      export type Response = defs.ResultBean<Array<defs.PetrolStationNameEntity>>

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 公司ComeOnDetail统计接口
     * /statistics/getCompanyPetrolDetailStatPage
     */
    export namespace getCompanyPetrolDetailStatPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.TheCompanyComeOnDetailedInformation>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.CompanyComeOnStatisticalSubsidiaryConditions>): Promise<BaseResponse<Response>>
    }

    /**
     * 公司ComeOnStatistical接口
     * /statistics/getCompanyPetrolStatPage
     */
    export namespace getCompanyPetrolStatPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.ComeOnStatisticsPagingInformationCompany>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.CompanyComeOnStatisticalPagingConditions>): Promise<BaseResponse<Response>>
    }

    /**
        * 根据加油站id查询Oil集合
加油站id
        * /statistics/getResPetrolListById
        */
    export namespace getResPetrolListById {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.GasOil>

      export const init: Response

      export function request(data: defs.IdParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 订单分页接口
     * /statistics/getStationStatisticsPage
     */
    export namespace getStationStatisticsPage {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.TheReconciliationSubsidiaryEntities>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.ComeOnStatisticalQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
        * 根据公司id查询车辆信息集合
公司id
        * /statistics/getVehicleListByCompanyId
        */
    export namespace getVehicleListByCompanyId {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.CompanyVehicleInformation>>

      export const init: Response

      export function request(data: defs.AccordingToTheOrganizationOrDepartment): Promise<BaseResponse<Response>>
    }

    /**
     * 选择公司(添加、修改菜单)
     * /statistics/selectOrgList
     */
    export namespace selectOrgList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.SysDeptEntityObject>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 补单
     * /statistics/supplementOrder
     */
    export namespace supplementOrder {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.FillOneParameter): Promise<BaseResponse<Response>>
    }
  }

  /**
   * app版本管理
   */
  export namespace sysAppVersion {
    /**
     * 新增
     * /sys/appVersion/add
     */
    export namespace addVersion {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.NewVersionControlParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 删除
     * /sys/appVersion/deleteVersion
     */
    export namespace deleteVersion {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.AuthServiceIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 查询Details
     * /sys/appVersion/findVersionById
     */
    export namespace findVersionById {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.VersionControl>

      export const init: Response

      export function request(data: defs.AuthServiceIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 分页列表
     * /sys/appVersion/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.VersionControl>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.QueryConditionsAppVersion>): Promise<BaseResponse<Response>>
    }

    /**
     * 修改
     * /sys/appVersion/update
     */
    export namespace updateVersion {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.VersionControlToModifyParameters): Promise<BaseResponse<Response>>
    }

    /**
        * app最新版本信息接口
app最新版本信息接口
        * /sys/appVersion/version
        */
    export namespace findAppVersion {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.VersionControl>>

      export const init: Response

      export function request(data: defs.TheAppVersionNumberQuery): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 系统设置-字典管理
   */
  export namespace sysConfig {
    /**
     * 根据id查询Details
     * /sys/sysConfig/findById
     */
    export namespace findById {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.SysConfigEntity>

      export const init: Response

      export function request(data: defs.AuthServiceIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 分页查询列表
     * /sys/sysConfig/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.SysConfigEntity>>

      export const init: Response

      export function request(data: defs.PageRequest): Promise<BaseResponse<Response>>
    }

    /**
     * 修改Details
     * /sys/sysConfig/updateById
     */
    export namespace updateById {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.SystemConfigurationModificationParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 登录授权
   */
  export namespace sysLogin {
    /**
     * 根据token获取用户信息
     * /auth/findUserByToken
     */
    export namespace findUserByToken {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.SysUserEntityObject>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 登录接口
     * /auth/login
     */
    export namespace login {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.TheLoginInformation>

      export const init: Response

      export function request(data: defs.LoginParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 退出接口
     * /auth/logout
     */
    export namespace logout {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
        * TheRefreshToken
token超时，调用接口TheRefreshToken
        * /auth/refreshToken
        */
    export namespace refreshToken {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.TheLoginInformation>

      export const init: Response

      export function request(data: defs.TheRefreshToken): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 系统设置-资源菜单管理
   */
  export namespace sysMenu {
    /**
     * 删除
     * /auth/menu/delete
     */
    export namespace remove {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.MenuIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 菜单信息
     * /auth/menu/getById
     */
    export namespace info {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.SysMenuEntityObject>

      export const init: Response

      export function request(data: defs.MenuIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 分页菜单列表
     * /auth/menu/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.SysMenuEntityObject>>

      export const init: Response

      export function request(data: defs.PageRequest): Promise<BaseResponse<Response>>
    }

    /**
     * 保存
     * /auth/menu/save
     */
    export namespace save {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.TheNewMenuParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 选择菜单(添加、修改菜单)
     * /auth/menu/select
     */
    export namespace select {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.SysMenuEntityObject>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 修改
     * /auth/menu/update
     */
    export namespace update {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.MenuToModifyParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 系统消息
   */
  export namespace sysMsg {
    /**
     * 分页消息列表
     * /msg/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.SysMsgEntityObject>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.SystemMessagePagingQueryConditions>): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 系统设置-TheOperationLog
   */
  export namespace sysOpLog {
    /**
     * 分页查询TheOperationLog
     * /sys/opLog/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.TheOperationLog>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.OperationLogsPagingQueryParameters>): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 系统设置-组织架构接口
   */
  export namespace sysOrg {
    /**
     * 删除
     * /auth/org/delete
     */
    export namespace remove {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.GroupIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 部门分页列表
     * /auth/org/deptPageList
     */
    export namespace deptPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.SysDeptEntityObject>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.CompanyPagingQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 获取Details
     * /auth/org/getById
     */
    export namespace getById {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.SysDeptEntityObject>

      export const init: Response

      export function request(data: defs.GroupIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 公司分页列表
     * /auth/org/orgPageList
     */
    export namespace orgPageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.SysDeptEntityObject>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.CompanyPagingQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 保存部门
     * /auth/org/saveDept
     */
    export namespace saveDept {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.DepartmentOfNewParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 选择部门(添加、修改菜单)
     * /auth/org/selectByOrgId
     */
    export namespace selectByOrgId {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.SysDeptEntityObject>>

      export const init: Response

      export function request(data: defs.GroupIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 选择公司(添加、修改菜单)
     * /auth/org/selectOrgList
     */
    export namespace selectOrgList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.SysDeptEntityObject>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 选择公司人员(添加、修改菜单)
     * /auth/org/selectOrgUserByOrgId
     */
    export namespace selectOrgUserByOrgId {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.SysUserEntityObject>>

      export const init: Response

      export function request(data: defs.GroupIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 修改部门
     * /auth/org/updateDeptById
     */
    export namespace updateDeptById {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.DepartmentToModifyParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 系统设置-角色管理
   */
  export namespace sysRole {
    /**
     * 删除角色
     * /auth/role/delete
     */
    export namespace remove {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.RoleIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 角色信息
     * /auth/role/info
     */
    export namespace info {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.SysRoleEntityObject>

      export const init: Response

      export function request(data: defs.RoleIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 分页角色列表
     * /auth/role/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.SysRoleEntityObject>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.RoleOfPagingQueryConditions>): Promise<BaseResponse<Response>>
    }

    /**
     * 保存角色
     * /auth/role/save
     */
    export namespace save {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.TheRoleOfNewParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 根据公司获取角色列表
     * /auth/role/select
     */
    export namespace select {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.SysRoleEntityObject>>

      export const init: Response

      export function request(data: defs.GroupIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 修改角色
     * /auth/role/update
     */
    export namespace update {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.RoleChangeParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 系统设置-系统用户
   */
  export namespace sysUser {
    /**
     * 按钮权限
     * /auth/user/buttons
     */
    export namespace buttons {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.SysMenuEntityObject>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 删除用户
     * /auth/user/delete
     */
    export namespace remove {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.UserIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 禁用启用
     * /auth/user/enableUser
     */
    export namespace enableUser {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.UsersDisableEnableParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 导出用户列表
     * /auth/user/export
     */
    export namespace exporting {
      export class QueryParams {
        /** 用户帐号 */
        loginName?: string
        /** 角色名称 */
        userName?: string
        /** 所属公司id */
        companyId?: number
        /** 角色名称 */
        roleName?: string
        /** 加油站名称 */
        stationName?: string
        /** 加油站id */
        stationId?: number
        /** 用户类型 0-加油员 1-驾驶员 2-公司人员 */
        userType?: number
        /** 推荐人id */
        referee?: number
      }

      export type Response = any

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 用户信息
     * /auth/user/info/
     */
    export namespace info {
      export class QueryParams {}

      export type Response = defs.ResultBean<defs.SysUserEntityObject>

      export const init: Response

      export function request(data: defs.UserIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 导航菜单权限
     * /auth/user/nav
     */
    export namespace nav {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.SysMenuEntityObject>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 分页用户列表
     * /auth/user/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.SysUserEntityObject>>

      export const init: Response

      export function request(data: defs.PageRequest<defs.UserPagingQueryParameters>): Promise<BaseResponse<Response>>
    }

    /**
     * 重置登录用户密码
     * /auth/user/passwordReset
     */
    export namespace passwordReset {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.UserIDParameter): Promise<BaseResponse<Response>>
    }

    /**
     * 修改登录用户密码
     * /auth/user/passwordUpd
     */
    export namespace passwordUpd {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.SysAccountPwdEditParams): Promise<BaseResponse<Response>>
    }

    /**
     * 保存公司用户
     * /auth/user/saveOrgUser
     */
    export namespace saveOrgUser {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.CorporateUsersOfNewParameters): Promise<BaseResponse<Response>>
    }

    /**
     * 修改公司用户
     * /auth/user/updateOrgUser
     */
    export namespace updateOrgUser {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.CompanyUsersToModifyParameters): Promise<BaseResponse<Response>>
    }
  }

  /**
   * Task Controller
   */
  export namespace task {
    /**
     * es创建加油站索引
     * /task/createPetrolIndex
     */
    export namespace createPetrolIndex {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * es删除所有加油站数据
     * /task/esDelAll
     */
    export namespace esDelAll {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * es同步所有加油站数据
     * /task/esSaveAll
     */
    export namespace esSaveAll {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }

    /**
     * 万金油油站变更 推送接口
     * /task/parsingWjyRestResult
     */
    export namespace parsingWjyRestResult {
      export class QueryParams {}

      export type Response = defs.RestResult

      export const init: Response

      export function request(data: defs.WJYStation): Promise<BaseResponse<Response>>
    }

    /**
     * 同步万金油  油站信息   全量
     * /task/syncWjyOilSiteInfo
     */
    export namespace syncWjyOilSiteInfo {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: QueryParams): Promise<BaseResponse<Response>>
    }
  }

  /**
   * 公司管理-关联设置
   */
  export namespace thirdOrgSet {
    /**
     * 绑定云图机构
     * /base/resThirdOrg/bandYtOrg
     */
    export namespace bindYtOrg {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.ThirdPartyParametersBound): Promise<BaseResponse<Response>>
    }

    /**
     * 查询未绑定的TheThirdPartyInstitution列表
     * /base/resThirdOrg/findEnabledBindList
     */
    export namespace findEnabledBindList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.TheThirdPartyInstitution>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 查询云图机构列表
     * /base/resThirdOrg/findYtOrgList
     */
    export namespace findYtOrgList {
      export class QueryParams {}

      export type Response = defs.ResultBean<Array<defs.SysDeptEntityObject>>

      export const init: Response

      export function request(): Promise<BaseResponse<Response>>
    }

    /**
     * 查询关联设置分页列表
     * /base/resThirdOrg/pageList
     */
    export namespace pageList {
      export class QueryParams {}

      export type Response = defs.PageBean<Array<defs.TheThirdPartyInstitution>>

      export const init: Response

      export function request(data: defs.PageRequest): Promise<BaseResponse<Response>>
    }

    /**
     * 解绑云图机构
     * /base/resThirdOrg/unbandYtOrg
     */
    export namespace unbandYtOrg {
      export class QueryParams {}

      export type Response = defs.ResultBean

      export const init: Response

      export function request(data: defs.IdParameter): Promise<BaseResponse<Response>>
    }
  }
}
