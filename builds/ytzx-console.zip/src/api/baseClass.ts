export class ACommissionSetUp {
  /** id */
  id = undefined

  /** 是否启用 0-否 1-是 */
  isEnabled = undefined
}

export class AccordingToTheOrganizationOrDepartment {
  /** 公司id */
  companyId = undefined

  /** 部门id */
  deptId = undefined

  /** 车辆ID */
  vehicleId = undefined

  /** 车辆ID集合 */
  vehicleIds = []
}

export class AllAccountInformation {
  /** 新增时间 */
  addTime = ''

  /** id */
  id = undefined

  /** 操作人账号 */
  loginName = ''

  /** 操作时间 */
  opTime = ''

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** 剩余金额(分) */
  remainingSum = undefined

  /** 总消费金额(分) */
  totalConsumeMoney = undefined

  /** 总充值金额(分) */
  totalDepositMoney = undefined
}

export class AllAccountTransactionHistory {
  /** 账户ID */
  accountId = undefined

  /** 账户名称 1-万金油 2-G7 3-星油 */
  accountName = ''

  /** 新增时间 */
  addTime = ''

  /** 变化后剩余金额(分) */
  afterRemainingSum = undefined

  /** 变化总金额(分) */
  afterTotalDeposit = undefined

  /** 变化前剩余金额(分) */
  beforeRemainingSum = undefined

  /** 变化前总金额(分) */
  beforeTotalDeposit = undefined

  /** 变化类型 0-充值 1-消费 */
  changeType = undefined

  /** 变化金额(分) */
  depositMoney = undefined

  /** id */
  id = undefined

  /** 操作人账号 */
  loginName = ''

  /** 操作时间 */
  opTime = ''

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** 订单流水号 */
  orderSerialNo = ''

  /** 备注 */
  remark = ''

  /** 第三方流水号 */
  thirdSerialNo = ''
}

export class Area {
  /** 下级 */
  children = []

  /** Area编码 */
  regionCode = ''

  /** Area名称 */
  regionName = ''
}

export class AuthServiceIDParameter {
  /** id */
  id = undefined
}

export class BatchCommissionSet {
  /** 消费成功佣金千分比(‰) */
  consumeCommissionMoney = undefined

  /** 安装并注册成功佣金(分) */
  installCommissionMoney = undefined
}

export class BindingLog {
  /** 账号id */
  accountId = undefined

  /** 新增时间 */
  addTime = ''

  /** 绑定设备 */
  bindingDevice = ''

  /** id */
  id = undefined

  /** 登录名 */
  loginName = ''

  /** 操作类型 0-绑定 1-解绑 */
  opType = undefined

  /** 操作时间 */
  operateTime = ''

  /** 操作人id */
  operatorId = undefined

  /** 操作人 */
  operatorName = ''

  /** 用户id */
  userId = undefined

  /** 用户类型 0-加油员 1-驾驶员 2-公司人员 */
  userType = undefined
}

export class BookedParameters {
  /** 入账公司ID */
  companyId = undefined

  /** 入账金额 分 */
  money = undefined

  /** 备注 */
  remark = ''
}

export class CardInfoExtObject {
  /** 新增时间 */
  addTime = ''

  /** 油卡平台 0-云途 1-G7 */
  cardPlatform = undefined

  /** 卡是否存在密码 1-存在，0-不存在,如果不存在则需要先进行设置密码 */
  cardPsw = undefined

  /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
  cardStatus = undefined

  /** 油卡状态描述 */
  cardStatusDesc = ''

  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 部门id */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 油卡Detailsid */
  detailId = undefined

  /** 驾驶员id */
  driverId = undefined

  /** 驾驶员姓名 */
  driverName = ''

  /** 即将过期的剩余油量2(ml) */
  expireRemainConsume2PetrolWarn = undefined

  /** 即将过期的剩余油量(ml) */
  expireRemainConsumePetrolWarn = undefined

  /** 半年累计消费2油量(ml) */
  halfYearConsume2Petrol = undefined

  /** 累计消费金额(分) */
  halfYearConsumeMoney = undefined

  /** 半年内消费油量(ml) */
  halfYearConsumePetrol = undefined

  /** 卡ID */
  id = undefined

  /** 是否主卡 0-否 1-是 */
  isPri = undefined

  /** 是否主卡描述 */
  isPriDesc = ''

  /** 锁定2油量(ml) */
  lockRemaining2Petrol = undefined

  /** 锁定油量(ml) */
  lockRemainingPetrol = undefined

  /** 锁定金额(分) */
  lockRemainingSum = undefined

  /** 登录名 */
  loginName = ''

  /** 开卡时间 */
  openTime = ''

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** 父id */
  parentId = undefined

  /** Oil2id */
  petrol2Id = undefined

  /** Oil2名称 */
  petrol2Name = ''

  /** 卡号 */
  petrolCardNum = ''

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardType = undefined

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardTypeDesc = ''

  /** Oilid */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** 剩余2油量(ml) */
  remaining2PetrolSum = undefined

  /** 剩余油量(ml) */
  remainingPetrolSum = undefined

  /** 余额(分) */
  remainingSum = undefined

  /** 半年内消费2油量(ml) */
  totalConsume2Petrol = undefined

  /** 累计消费金额(分) */
  totalConsumeMoney = undefined

  /** 累计消费油量(ml) */
  totalConsumePetrol = undefined

  /** 累计抵扣运费(分) */
  totalDeductionCost = undefined

  /** 累计充值2油量(ml) */
  totalDeposit2Petrol = undefined

  /** 累计充值金额(分) */
  totalDepositMoney = undefined

  /** 累计充值油量(ml) */
  totalDepositPetrol = undefined

  /** 车辆id */
  vehicleId = undefined

  /** 车牌号 */
  vehicleNum = ''

  /** 车辆来源 0-后台添加 1-加盟 */
  vehicleSource = undefined

  /** 车辆来源描述 */
  vehicleSourceDesc = ''

  /** 车辆类型 0-自有车辆 1-外协车辆 */
  vehicleType = undefined

  /** 车辆类型描述 */
  vehicleTypeDesc = ''

  /** Modelsid */
  vehicleTypeId = undefined

  /** Models名称 */
  vehicleTypeName = ''

  /** 云途油卡类型 0-个人云途油卡 1-公司云途油卡 2-非云途油卡 */
  ytCardType = undefined

  /** 云途油卡类型描述 */
  ytCardTypeDesc = ''
}

export class CardPetrolDepositObject {
  /** 新增时间 */
  addTime = ''

  /** 订单号(业务交易流水号) */
  busiTradeNo = ''

  /** -35#柴油充值油量(ml) */
  change2Petrol = undefined

  /** 0#柴油充值油量(ml) */
  changePetrol = undefined

  /** 抵扣运费(分) */
  deductionCost = undefined

  /** id */
  id = undefined

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** -35#柴油Oilid */
  petrol2Id = undefined

  /** -35#柴油Oil名称 */
  petrol2Name = ''

  /** 油卡id */
  petrolCardId = undefined

  /** 卡号 */
  petrolCardNum = ''

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardType = undefined

  /** petrolCardTypeDesc */
  petrolCardTypeDesc = ''

  /** 0#柴油Oilid */
  petrolId = undefined

  /** 0#柴油Oil名称 */
  petrolName = ''

  /** 备注 */
  remark = ''

  /** 第三方交易流水号 */
  thirdTradeNo = ''

  /** 车辆id */
  vehicleId = undefined
}

export class CardTransferLogObject {
  /** 转账金额(分) */
  changeMoney = undefined

  /** id */
  id = undefined

  /** 转账时间 */
  operateTime = ''

  /** 转出卡id */
  zcCardId = undefined

  /** 转出卡号 */
  zcCardNum = ''

  /** 公司id */
  zcCompanyId = undefined

  /** 公司名称 */
  zcCompanyName = ''

  /** 转出驾驶员id */
  zcDriverId = undefined

  /** 转出驾驶员姓名 */
  zcDriverName = ''

  /** 转入卡id */
  zrCardId = undefined

  /** 转入卡号 */
  zrCardNum = ''

  /** 公司id */
  zrCompanyId = undefined

  /** 公司名称 */
  zrCompanyName = ''

  /** 转入驾驶员id */
  zrDriverId = undefined

  /** 转入驾驶员姓名 */
  zrDriverName = ''
}

export class CloudElectronicOilClipCardObjects {
  /** 新增时间 */
  addTime = ''

  /** 油卡平台 0-云途 1-G7 */
  cardPlatform = undefined

  /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
  cardStatus = undefined

  /** 油卡状态描述 */
  cardStatusDesc = ''

  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 部门id */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 驾驶员id */
  driverId = undefined

  /** 驾驶员姓名 */
  driverName = ''

  /** 即将过期的剩余油量2(ml) */
  expireRemainConsume2PetrolWarn = undefined

  /** 即将过期的剩余油量(ml) */
  expireRemainConsumePetrolWarn = undefined

  /** 冻结余额(分) */
  freezeRemainingSum = undefined

  /** 历史累计充值金额(分) */
  hisDepositMoney = undefined

  /** id */
  id = undefined

  /** 是否主卡 0-否 1-是 */
  isPri = undefined

  /** 是否主卡描述 */
  isPriDesc = ''

  /** 登录名 */
  loginName = ''

  /** 开卡时间 */
  openTime = ''

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** 父id */
  parentId = undefined

  /** 卡号 */
  petrolCardNum = ''

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardType = undefined

  /** 油卡类型描述 */
  petrolCardTypeDesc = ''

  /** 退款金额(分) */
  refundMoney = undefined

  /** （车队油卡）剩余2油量(ml) */
  remaining2PetrolSum = undefined

  /** （车队油卡）剩余油量(ml) */
  remainingPetrolSum = undefined

  /** 余额(分) */
  remainingSum = undefined

  /** 回退金额(分) */
  returnMoney = undefined

  /** 累计消费金额(分) */
  totalConsumeMoney = undefined

  /** 累计充值金额(分) */
  totalDepositMoney = undefined

  /** 车辆id */
  vehicleId = undefined

  /** 车牌号 */
  vehicleNum = ''

  /** 车辆来源 0-后台添加 1-加盟 */
  vehicleSource = undefined

  /** 车辆来源描述 */
  vehicleSourceDesc = ''

  /** 车辆类型 0-自有车辆 1-外协车辆 */
  vehicleType = undefined

  /** 车辆类型描述 */
  vehicleTypeDesc = ''

  /** Modelsid */
  vehicleTypeId = undefined

  /** Models名称 */
  vehicleTypeName = ''

  /** 云途油卡类型 0-个人云途油卡 1-公司云途油卡 2-非云途油卡 */
  ytCardType = undefined

  /** 云途油卡类型描述 */
  ytCardTypeDesc = ''
}

export class CloudOilCardChangeDetailParameters {
  /** 变更类型 0-充值 1-消费 2-划拨 */
  changeType = undefined

  /** 公司id */
  companyId = undefined

  /** 部门id */
  deptId = undefined

  /** 结束日期 yyyy-MM-dd */
  endDate = ''

  /** 结束日期 yyyy-MM-dd HH:mm:ss */
  endTime = ''

  /** 结束日期 yyyy-MM-dd HH:mm:ss */
  endTimeStr = ''

  /** 卡id */
  petrolCardId = undefined

  /** 开始日期 yyyy-MM-dd */
  startDate = ''

  /** 开始时间 yyyy-MM-dd HH:mm:ss */
  startTime = ''

  /** 开始时间 yyyy-MM-dd HH:mm:ss */
  startTimeStr = ''

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
  stationSource = undefined

  /** 车牌号 */
  vehicleNum = ''
}

export class CloudOilCardChangeObjects {
  /** 新增时间 */
  addTime = ''

  /** 变更后金额(分) */
  afterMoney = undefined

  /** 变更前金额(分) */
  beforeMoney = undefined

  /** 业务交易流水号 */
  busiTradeNo = ''

  /** 变更金额(分) */
  changeMoney = undefined

  /** 变更油量(ml) */
  changePetrol = undefined

  /** 变更类型 0-充值 1-消费 2-划出 3-划入 4-转出 5-转入 */
  changeType = undefined

  /** 变更类型 0-充值 1-消费 2-划出 3-划入 4-转出 5-转入 */
  changeTypeDesc = ''

  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 充值方式 0-后台充值 1-支付宝 2-微信 */
  depositWay = undefined

  /** 充值方式 0-后台充值 1-支付宝 2-微信 */
  depositWayDesc = ''

  /** 部门ID */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 驾驶员名称 */
  driverName = ''

  /** id */
  id = undefined

  /** 操作时间 */
  operateTime = ''

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** 油卡id */
  petrolCardId = undefined

  /** 油卡卡号 */
  petrolCardNum = ''

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardType = undefined

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardTypeDesc = ''

  /** Oilid */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** 主卡id */
  priCardId = undefined

  /** 主卡卡号 */
  priCardNum = ''

  /** 备注 */
  remark = ''

  /** 加油站id */
  stationId = undefined

  /** 加油站名称 */
  stationName = ''

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
  stationSource = undefined

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
  stationSourceDesc = ''

  /** 第三方交易流水号 */
  thirdTradeNo = ''

  /** 交易卡ID */
  transCardId = undefined

  /** 交易卡号 */
  transCardNum = ''

  /** 车牌号 */
  vehicleNum = ''
}

export class CloudOilCardMasterCardParameters {
  /** 卡Id */
  cardId = undefined

  /** 充值金额(分) */
  depositMoney = undefined
}

export class CloudOilClipCardTopParameters {
  /** 卡Id */
  cardId = undefined

  /** 充值金额(分) */
  depositMoney = undefined
}

export class ComeOnDetail {
  /** 新增时间 */
  addTime = ''

  /** 业务交易流水号 */
  busiTradeNo = ''

  /** 变更金额(分) */
  changeMoney = undefined

  /** 变更油量(ml) */
  changePetrol = undefined

  /** 变更类型 0-充值 1-消费 2-划出 3-划入 4-转出 5-转入 */
  changeType = undefined

  /** 变更类型 0-充值 1-消费 2-划出 3-划入 4-转出 5-转入 */
  changeTypeDesc = ''

  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 充值方式 0-后台充值 1-支付宝 2-微信 */
  depositWay = undefined

  /** 充值方式 0-后台充值 1-支付宝 2-微信 */
  depositWayDesc = ''

  /** 加油撬编号 */
  deviceCode = ''

  /** 加油撬id */
  deviceId = undefined

  /** id */
  id = undefined

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** 油卡id */
  petrolCardId = undefined

  /** 油卡卡号 */
  petrolCardNum = ''

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardType = undefined

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardTypeDesc = ''

  /** Oilid */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** 主卡id */
  priCardId = undefined

  /** 主卡卡号 */
  priCardNum = ''

  /** 备注 */
  remark = ''

  /** 加油站id */
  stationId = undefined

  /** 加油站名称 */
  stationName = ''

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
  stationSource = undefined

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
  stationSourceDesc = ''

  /** 第三方交易流水号 */
  thirdTradeNo = ''
}

export class ComeOnMemberID {
  /** ComeOnMemberID */
  referee = undefined
}

export class ComeOnReconciliationPageListsCompany {
  /** 加油金额/抵扣运费（元） */
  actTotalPrice = ''

  /** 适用油卡 */
  cardTypeName = ''

  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 对账月份 */
  dateTime = ''

  /** 加油橇编号 */
  deviceCode = ''

  /** 加油橇id */
  deviceId = undefined

  /** 油卡类型 */
  petrolCardType = undefined

  /** 加油型号 */
  petrolNames = ''

  /** 油站id */
  stationId = undefined

  /** 油站名称 */
  stationName = ''

  /** 加油站来源 */
  stationSource = undefined

  /** 加油站来源 中文 */
  stationSourceDesc = ''
}

export class ComeOnReconciliationQueryParameters {
  /** 卡号 */
  cardNum = ''

  /** 油卡类型 */
  cardType = undefined

  /** 地市编码 */
  cityCode = ''

  /** 公司id，公司对账不能为空 */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 对账月份  yyyy-MM */
  dateTime = ''

  /** 部门ID */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 加油橇编号 */
  deviceCode = ''

  /** 加油橇id，加油橇对账Details不能为空 */
  deviceId = undefined

  /** 结束日期 */
  endDate = ''

  /** 月份 */
  month = undefined

  /** 操作类型 0-充值 1-消费 2-退款 */
  opType = undefined

  /** 订单号 */
  orderSerialNo = ''

  /** Oil型号id */
  petrolId = undefined

  /** 加油型号 */
  petrolName = undefined

  /** 省份编码 */
  provinceCode = undefined

  /** 区县编码 */
  regionCode = ''

  /** 开始日期 */
  startDate = ''

  /** 加油站id，加油站对账不能为空 */
  stationId = undefined

  /** 油站名称 */
  stationName = ''

  /** 加油站来源 */
  stationSource = undefined

  /** 车牌号 */
  vehicleNum = ''

  /** 年份 */
  year = undefined
}

export class ComeOnStatistical {
  /** 加油量  ml */
  data = undefined

  /** 加油时间 */
  date = ''
}

export class ComeOnStatisticalQueryParameters {
  /** 卡号 */
  cardNum = ''

  /** 油卡类型 0-车队油卡 1-云图油卡 2-实体油卡 */
  cardType = undefined

  /** 是否核销 0-否 1-是 2无需核销 */
  checkStatus = undefined

  /** 地市编码 */
  cityCode = ''

  /** 公司名称 */
  companyName = ''

  /** 订单结束日期 */
  endDate = ''

  /** 支付完成结束日期 */
  endPayFinishedDate = ''

  /** 退款完成结束日期 */
  endRefundFinishedDate = ''

  /** 是否时万金油对账界面 */
  isWJY = undefined

  /** 订单号 */
  orderSerialNo = ''

  /** 订单状态 0-待支付 1-已完成 3-已退款 */
  orderStatus = undefined

  /** 支付状态 支付状态 0-待支付 1-支付中 2-已支付 3-支付失败 4-退款中 5-已退款 6-待发送确认 */
  payStatus = undefined

  /** Oil类型ID 字典数据 */
  petrolId = undefined

  /** 省份编码 */
  provinceCode = undefined

  /** 区县编码 */
  regionCode = ''

  /** 订单开始日期 */
  startDate = ''

  /** 支付完成开始日期 */
  startPayFinishedDate = ''

  /** 退款完成开始日期 */
  startRefundFinishedDate = ''

  /** 加油站名称 */
  stationName = ''

  /** 油站所属 0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
  stationSource = undefined

  /** 第三方订单号 */
  thirdSerialNo = ''

  /** 交易方式 0-司机出示二维码(加油员扫码) 1-司机主动支付  3 补单 */
  tradeType = undefined

  /** 车牌号 */
  vehicleNum = ''
}

export class ComeOnStatisticsPagingInformationCompany {
  /** 实付消费总价(分) */
  actTotalPrice = undefined

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  cardType = undefined

  /** 卡类型 */
  cardTypeDesc = ''

  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 日期 */
  dateStr = ''

  /** 结束时间 */
  endTime = ''

  /** 实际油量(ml) */
  petrolCount = undefined

  /** OilID */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** 开始时间 */
  startTime = ''

  /** 加油站id */
  stationId = undefined

  /** 加油站名称 */
  stationName = ''

  /** 加油站来源 */
  stationSource = undefined

  /** 加油站来源 */
  stationSourceDesc = ''
}

export class ComeOnTheOverviewScreenObjects {
  /** 加油总量排名前10的加油站 */
  chartBarDto = new HistogramDataReturnObjects()

  /** 加油总量排名前10的公司 */
  chartLineDto = new TheLineChartDataReturnObjects()

  /** 加油总量排名前10的加油站 */
  chartLineSingleDto = new TheLineChartDataReturnObjects()

  /** 合作公司数 */
  companyHeadVo = new RefuelingOverviewHeadFuelStatistics()

  /** 累计加油量 */
  fuelChargeHeadVo = new RefuelingOverviewHeadFuelStatistics()

  /** 合作加油站数 */
  stationHeadVo = new RefuelingOverviewHeadFuelStatistics()
}

export class CommissionChangeParameters {
  /** 佣金金额 单位:分 */
  commissionMoney = undefined

  /** ComeOnMemberID PC需要端传入ID， APP需要后端获取ID */
  referee = undefined
}

export class CommissionManagement {
  /** 推荐人数 */
  refereeNum = undefined

  /** 剩余金额(分) */
  remainingCommision = undefined

  /** 所属加油站 */
  stationName = ''

  /** 提现金额(分) */
  totalCashOut = undefined

  /** 累计佣金总额(分) */
  totalCommissionMoney = undefined

  /** 累计加油金额(分) */
  totalOilMoney = undefined

  /** ComeOnMemberID */
  userId = undefined

  /** 加油员名称 */
  userName = ''
}

export class CommissionManagementPagingQueryParameters {
  /** 加油站名称 */
  stationName = ''

  /** 加油员名称 */
  userName = ''
}

export class CommissionSetList {
  /** 新增时间 */
  addTime = ''

  /** 消费成功佣金千分比(‰) */
  consumeCommissionMoney = undefined

  /** 安装并注册成功佣金(分) */
  installCommissionMoney = undefined

  /** 是否启用 0-否 1-是 */
  isEnabled = undefined

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** 加油站id */
  stationId = undefined

  /** 加油站名称 */
  stationName = ''
}

export class CommissionSetThePagingQueryParameters {
  /** 加油站id */
  stationId = undefined
}

export class CommissionSetUpDetails {
  /** 消费成功佣金千分比(‰) */
  consumeCommissionMoney = undefined

  /** 安装并注册成功佣金(分) */
  installCommissionMoney = undefined

  /** 加油站id */
  stationId = undefined

  /** 加油站名称 */
  stationName = ''
}

export class CommissionSetUpToModifyParameters {
  /** 消费成功佣金千分比(‰) */
  consumeCommissionMoney = undefined

  /** 安装并注册成功佣金(分) */
  installCommissionMoney = undefined

  /** 加油站id */
  stationId = undefined
}

export class CompanyComeOnStatisticalPagingConditions {
  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  cardType = undefined

  /** 城市编码 */
  cityCode = ''

  /** 公司id */
  companyId = undefined

  /** 结束日期 格式:yyyy-MM-dd 23:59:59 */
  endTime = ''

  /** Oil类型ID 字典数据 */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** 省份编码 */
  provinceCode = ''

  /** 地区编码 */
  regionCode = ''

  /** 开始日期 格式:yyyy-MM-dd 00:00:00 */
  startTime = ''

  /** 油站来源 */
  stationSource = undefined
}

export class CompanyComeOnStatisticalSubsidiaryConditions {
  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  cardType = undefined

  /** 公司ID */
  companyId = undefined

  /** 结束日期 格式:yyyy-MM-dd 23:59:59 */
  endTime = ''

  /** OilID */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** 开始日期 格式:yyyy-MM-dd 00:00:00 */
  startTime = ''

  /** 加油站ID */
  stationId = undefined

  /** 加油站名称 */
  stationName = ''
}

export class CompanyPagingQueryParameters {
  /** 地市编码 */
  cityCode = ''

  /** 公司ID */
  orgId = undefined

  /** 公司名称 */
  orgName = ''

  /** 组织类型 0公司 1部门 */
  orgType = undefined

  /** 省份编码 */
  provinceCode = ''

  /** 区县编码 */
  regionCode = ''
}

export class CompanyUsersToModifyParameters {
  /** 状态  0：禁用   1：正常 */
  accountStatus = undefined

  /** 所属公司id */
  companyId = undefined

  /** 所属公司名称 */
  companyName = ''

  /** 手机号 */
  contactPhone = ''

  /** 所属部门id */
  deptId = undefined

  /** 所属部门名称 */
  deptName = ''

  /** 图片地址 */
  headImgAddr = ''

  /** 图片ID */
  headImgId = ''

  /** 用户帐号 */
  loginName = ''

  /** 角色ID列表 */
  roleIdList = []

  /** 用户ID */
  userId = undefined

  /** 用户姓名 */
  userName = ''
}

export class CompanyVehicleInformation {
  /** 新增时间 */
  addTime = ''

  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 部门id */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 驾驶员ID */
  driverId = undefined

  /** 驾驶员名称 */
  driverName = ''

  /** id,修改时必填 */
  id = undefined

  /** 是否默认车辆 0-否 1-是 */
  isDefault = undefined

  /** 是否删除  0-否 1-是 */
  isDeleted = undefined

  /** 驾驶员登录名 */
  loginName = ''

  /** 油卡类型 多个用英文逗号隔开 */
  petrolCardTypes = ''

  /** OilID集合 */
  petrolIds = ''

  /** Oil名称集合 */
  petrolNames = ''

  /** Oil类型 0-柴油 1-汽油 2-天然气 */
  petrolTypeName = ''

  /** 车辆Oil集合 */
  resVehiclePetrols = []

  /** 车牌号 */
  vehicleNum = ''

  /** 车辆来源 0-后台添加 1-加盟 */
  vehicleSource = undefined

  /** 车辆来源 0-后台添加 1-加盟 */
  vehicleSourceName = ''

  /** 车辆类型 0-自有车辆 1-外协车辆 */
  vehicleType = undefined

  /** 车辆类型 */
  vehicleTypeDesc = ''

  /** Modelsid */
  vehicleTypeId = undefined

  /** Models名称 */
  vehicleTypeName = ''
}

export class CorporateUsersOfNewParameters {
  /** 状态  0：禁用   1：正常 */
  accountStatus = undefined

  /** 所属公司id */
  companyId = undefined

  /** 所属公司名称 */
  companyName = ''

  /** 手机号 */
  contactPhone = ''

  /** 所属部门id */
  deptId = undefined

  /** 所属部门名称 */
  deptName = ''

  /** 图片地址 */
  headImgAddr = ''

  /** 图片ID */
  headImgId = ''

  /** 用户帐号 */
  loginName = ''

  /** 角色ID列表 */
  roleIdList = []

  /** 用户姓名 */
  userName = ''
}

export class CreditAccount {
  /** 授信额度 分 */
  creditLine = undefined

  /** 授信余额 分 */
  creditRemainingLine = undefined

  /** 入账金额 分 */
  inMoney = undefined

  /** 消费金额 分 */
  totalConsumeMoney = undefined
}

export class CreditTransactionDetails {
  /** 交易时间 */
  addTime = ''

  /** 交易金额 分 */
  changeMoney = undefined

  /** 交易类型 1消费 12入账 */
  changeType = undefined

  /** 交易类型描述 1消费 12入账 */
  changeTypeDesc = ''

  /** id */
  id = undefined

  /** 操作人名称 */
  operatorName = ''

  /** 交易卡号 */
  petrolCardNum = ''

  /** 备注 */
  remark = ''
}

export class CreditTransactionsQueryConditions {
  /** 交易类型 1消费 12入账 */
  changeType = undefined

  /** 公司ID */
  companyId = undefined

  /** 结束日期 yyyy-MM-dd */
  endDate = ''

  /** 结束日期 yyyy-MM-dd HH:mm:ss */
  endTime = ''

  /** 结束日期 yyyy-MM-dd HH:mm:ss */
  endTimeStr = ''

  /** 操作人 */
  operatorName = ''

  /** 交易卡号 */
  petrolCardNum = ''

  /** 开始日期 yyyy-MM-dd */
  startDate = ''

  /** 开始时间 yyyy-MM-dd HH:mm:ss */
  startTime = ''

  /** 开始时间 yyyy-MM-dd HH:mm:ss */
  startTimeStr = ''
}

export class DeleteTheParameterInARelease {
  /** id */
  id = undefined

  /** 是否管理员 0-否 1-是 */
  isAdmin = undefined
}

export class DepartmentOfNewParameters {
  /** 联系人姓名 */
  contactName = ''

  /** 联系人电话 */
  contactPhone = ''

  /** 名称 */
  orgName = ''

  /** 父级ID */
  parentOrgId = undefined
}

export class DepartmentToModifyParameters {
  /** 联系人姓名 */
  contactName = ''

  /** 联系人电话 */
  contactPhone = ''

  /** 组织ID */
  orgId = undefined

  /** 名称 */
  orgName = ''

  /** 父级ID */
  parentOrgId = undefined
}

export class DetailedListOfMakeOutInvoice {
  /** 实付消费总价(分) */
  actTotalPrice = undefined

  /** 申请人姓名 */
  applicantName = ''

  /** 申请时间 */
  applyTime = ''

  /** id */
  id = undefined

  /** 开票id */
  openInvoiceId = undefined

  /** 订单ID */
  orderId = undefined

  /** 订单流水号 */
  orderSerialNo = ''

  /** 订单时间 */
  orderTime = ''

  /** Oil名称 */
  petrolName = ''

  /** 加油站名称 */
  stationName = ''

  /** 车牌号 */
  vehicleNum = ''

  /** Models名称 */
  vehicleTypeName = ''
}

export class Details {
  /** 新增时间 */
  addTime = ''

  /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
  checkStatus = undefined

  /** 审核时间 */
  checkTime = ''

  /** 审核人id */
  checkUserId = undefined

  /** 审核人姓名 */
  checkUserName = ''

  /** 审核人手机号 */
  checkUserPhone = ''

  /** 发布内容 */
  content = ''

  /** id */
  id = undefined

  /** 是否自己发布的数据 0否 1是 */
  isSelfPublish = undefined

  /** 发布时间 */
  publishTime = ''

  /** 附件列表 */
  resPublishAppendixList = []

  /** 发布人id */
  userId = undefined

  /** 发布人姓名 */
  userName = ''

  /** 发布人手机 */
  userPhone = ''
}

export class ElectronicOilCardQueryObject {
  /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
  cardStatus = undefined

  /** 公司Id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 部门id */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 登录名 */
  loginName = ''

  /** 卡号 */
  petrolCardNum = ''

  /** 油卡类型 */
  petrolCardType = undefined

  /** 车牌号 */
  vehicleNum = ''

  /** 车辆类型 0-自有车辆 1-外协车辆 */
  vehicleType = undefined
}

export class ElectronicOilCardStatistics {
  /** 实体油卡总数量 张 */
  entityCardTotalNum = undefined

  /** 实体油卡已使用 (分) */
  entityConsumeTotalMoney = undefined

  /** 实体油卡加盟公司 (个) */
  entityJoinCompanyNum = undefined

  /** 实体油卡已充值(分) */
  entityTotalRechargeMoney = undefined

  /** 本月加盟车辆同比上月 (%) */
  monthJoinVehicleRate = undefined

  /** 本月加盟车辆  辆 */
  monthJoinVehicleTotal = undefined

  /** 本月加油总量同比上月 (%) */
  monthReFuelRate = undefined

  /** 本月加油总量  ml */
  monthRefuelTotal = undefined

  /** 车队油卡总数量 张 */
  vehicleCardTotalNum = undefined

  /** 车队油卡已加油 ml */
  vehicleConsumePetrolTotal = undefined

  /** 车队油卡订单数 单 */
  vehicleOrderTotal = undefined

  /** 车队油卡累计抵扣运费(分) */
  vehicleTotalDeductionCost = undefined

  /** 车队油卡未使用 张 */
  vehicleUnusedTotalNum = undefined

  /** 车队油卡已使用 张 */
  vehicleUsedTotalNum = undefined

  /** 本周加盟车辆同比上月 (%) */
  weekJoinVehicleRate = undefined

  /** 本周加盟车辆  辆 */
  weekJoinVehicleTotal = undefined

  /** 本周加油总量同比上月 (%) */
  weekReFuelRate = undefined

  /** 本周加油总量  ml */
  weekRefuelTotal = undefined

  /** 云途油卡已使用 (分) */
  yuntuConsumeTotalMoney = undefined

  /** 云途油卡加盟公司  (个) */
  yuntuJoinCompanyNum = undefined

  /** 云途油卡总数量 张 */
  yutuCardTotalNum = undefined
}

export class EnumVo {
  /** 编码 */
  code = undefined

  /** 描述 */
  desc = ''

  /** 名称 */
  name = ''
}

export class ExtractTheCommissionRecord {
  /** 新增时间 */
  addTime = ''

  /** 提现后剩余佣金(分) */
  afterRemainingCommision = undefined

  /** 总提现佣金(分) */
  applyTime = ''

  /** 提现前剩余佣金(分) */
  beforeRemainingCommision = undefined

  /** 提现佣金(分) */
  cashOutCommision = undefined

  /** id */
  id = undefined

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** 推荐人id */
  referee = undefined

  /** 推荐人加油站id */
  refereeStationId = undefined

  /** 加油站名称 */
  stationName = ''

  /** 总提现佣金(分) */
  totalCashOut = undefined

  /** 用户姓名 */
  userName = ''
}

export class FileUploadResponse {
  /** 文件ID */
  fileId = ''

  /** 文件名 */
  fileName = ''

  /** 文件路径 */
  filePath = ''

  /** 文件类型 */
  fileType = ''

  /** 文件http请求地址 */
  httpUrl = ''

  /** 访问文件的时效性 */
  token = ''
}

export class FillOneParameter {
  /** 油卡id */
  cardId = undefined

  /** 加油撬设备ID */
  deviceId = undefined

  /** 加油枪ID */
  gunId = undefined

  /** 油量(ml) */
  petrolCount = undefined

  /** Oilid */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** 价格（分） */
  price = undefined

  /** 加油站id */
  stationId = undefined
}

export class G7RestResult {
  /** code */
  code = undefined

  /** data */
  data = undefined

  /** msg */
  msg = ''
}

export class GasOil {
  /** 加油枪信息 */
  resStation2GunList = []

  /** GasOil信息 */
  station2PetrolList = []

  /** 加油站加油撬信息 */
  stationDeviceList = []

  /** 0 GasOil 1加油撬 2加油枪 */
  type = undefined
}

export class GasStationAccountParameters {
  /** 返点(分)比例 */
  rebateRate = undefined

  /** 账户充值(分) */
  rechargeMoney = undefined

  /** 加油站id */
  stationId = undefined
}

export class GasStationCollation {
  /** 新增时间 */
  addTime = ''

  /** 规则id */
  id = undefined

  /** 启用  0-停用 1-启用 */
  isEnabled = undefined

  /** 规则名称 */
  ruleName = ''
}

export class GasStationIDParameter {
  /** 加油站ID */
  stationId = undefined
}

export class GroupIDParameter {
  /** id */
  orgId = undefined
}

export class HistogramDataReturnObjects {
  /** xline */
  xline = []

  /** yline */
  yline = []
}

export class IdParameter {
  /** id */
  id = undefined
}

export class IdParamsObject {
  /** 查询对应的Id */
  id = undefined
}

export class JoinThePagingParametersList {
  /** 申请结束时间 yyyy-MM-dd HH:mm:ss */
  applyEndTime = ''

  /** 申请开始时间 yyyy-MM-dd HH:mm:ss */
  applyStartTime = ''

  /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
  auditStatus = undefined

  /** 电话号码 */
  contactPhone = ''

  /** 驾驶员 */
  userName = ''

  /** 车牌号 */
  vehicleNum = ''
}

export class LoginParameters {
  /** 终端系统类型 1-ios 2-android 3-winphone  4-其他 */
  appOs = undefined

  /** app系统类型 */
  appVersion = ''

  /** 绑定设备 */
  bindingDevice = ''

  /** 登录账号 */
  loginName = ''

  /** 终端品牌 */
  osBrand = ''

  /** 终端型号 */
  osModel = ''

  /** 终端系统版本 */
  osVersion = ''

  /** 登录密码 */
  password = ''

  /** 终端推送token */
  pushToken = ''

  /** 用户类型 0-加油员 1-驾驶员 2-公司人员 */
  userType = undefined
}

export class MallGoods {
  /** 新增时间 */
  addTime = ''

  /** 商品简介 */
  goodsDesc = ''

  /** 商品名称 */
  goodsName = ''

  /** 商品积分 */
  goodsPoints = undefined

  /** id */
  id = undefined

  /** 是否删除  0-否 1-是 */
  isDeleted = undefined

  /** 是否上架 0-否 1-是 */
  isOnline = undefined
}

export class MallGoodsImg {
  /** 新增时间 */
  addTime = ''

  /** 大图地址 */
  bigImgAddr = ''

  /** 大图id */
  bigImgId = ''

  /** 商品id */
  goodsId = undefined

  /** id */
  id = undefined

  /** 小图地址 */
  smallImgAddr = ''

  /** 小图id */
  smallImgId = ''
}

export class MallGoodsPageQueryParams {
  /** 结束积分 */
  endPoints = undefined

  /** 商品名称 */
  goodsName = ''

  /** 商品积分 */
  goodsPoints = undefined

  /** 是否上架 0-否 1-是 */
  isOnline = undefined

  /** 开始积分 */
  startPoints = undefined
}

export class MallGoodsWithImg {
  /** 新增时间 */
  addTime = ''

  /** 商品简介 */
  goodsDesc = ''

  /** 商品图片列表 */
  goodsImgs = []

  /** 商品名称 */
  goodsName = ''

  /** 商品积分 */
  goodsPoints = undefined

  /** id */
  id = undefined

  /** 是否删除  0-否 1-是 */
  isDeleted = undefined

  /** 是否上架 0-否 1-是 */
  isOnline = undefined
}

export class MallOrder {
  /** 新增时间 */
  addTime = ''

  /** 新增时间 */
  addTimeStr = ''

  /** 地址id */
  addrId = undefined

  /** 申请退款时间 */
  applyRefundTime = ''

  /** 申请退款时间 */
  applyRefundTimeStr = ''

  /** 地市编码 */
  cityCode = ''

  /** 地市名称 */
  cityName = ''

  /** 联系电话 */
  contactPhone = ''

  /** 处理时间 */
  dealTime = ''

  /** 处理时间 */
  dealTimeStr = ''

  /** 详细地址 */
  detailAddr = ''

  /** id */
  id = undefined

  /** 是否已处理 0-否 1-是 */
  isDeal = undefined

  /** isDealStr */
  isDealStr = ''

  /** 订单商品列表 */
  orderList = []

  /** 订单流水号 */
  orderSerialNo = ''

  /** 订单状态 0-正常 1-已完成 2-已取消 */
  orderStatus = undefined

  /** orderStatusStr */
  orderStatusStr = ''

  /** 订单时间 */
  orderTime = ''

  /** 订单时间 */
  orderTimeStr = ''

  /** 支付状态 0-待支付 1-已支付 2-退款中 3-已退款 */
  payStatus = undefined

  /** payStatusStr */
  payStatusStr = ''

  /** 支付时间 */
  payTime = ''

  /** 支付时间 */
  payTimeStr = ''

  /** 支付方式 0-积分 1-微信 2-支付宝 */
  payWay = undefined

  /** payWayStr */
  payWayStr = ''

  /** 省份编码 */
  provinceCode = ''

  /** 省份名称 */
  provinceName = ''

  /** 退款时间 */
  refundTime = ''

  /** 退款时间 */
  refundTimeStr = ''

  /** 区县编码 */
  regionCode = ''

  /** 区县名称 */
  regionName = ''

  /** 总积分 */
  totalPoints = undefined

  /** 总金额(分) */
  totalPrice = undefined

  /** 用户id */
  userId = undefined

  /** 用户姓名 */
  userName = ''
}

export class MallOrderApplyParams {
  /** 地址id */
  addrId = undefined

  /** 订单商品列表 */
  orderApplyList = []
}

export class MallOrderDealParams {
  /** 订单id */
  orderId = undefined
}

export class MallOrderGoods {
  /** 新增时间 */
  addTime = ''

  /** 新增时间 */
  addTimeStr = ''

  /** 商品数量 */
  goodsCnt = undefined

  /** 商品id */
  goodsId = undefined

  /** 商品名称 */
  goodsName = ''

  /** 商品积分 */
  goodsPoints = undefined

  /** 商品单价(分) */
  goodsPrice = undefined

  /** id */
  id = undefined

  /** 订单id */
  orderId = undefined

  /** 订单商品图片列表 */
  orderImgList = []
}

export class MallOrderGoodsParams {
  /** 商品数量 */
  goodsCnt = undefined

  /** 商品id */
  goodsId = undefined
}

export class MallOrderImg {
  /** 新增时间 */
  addTime = ''

  /** 新增时间 */
  addTimeStr = ''

  /** 大图地址 */
  bigImgAddr = ''

  /** 大图id */
  bigImgId = ''

  /** id */
  id = undefined

  /** 订单商品id */
  orderGoodsId = undefined

  /** 小图地址 */
  smallImgAddr = ''

  /** 小图id */
  smallImgId = ''
}

export class MallOrderPageQueryParams {
  /** 新增时间 */
  addTime = ''

  /** 申请退款时间 */
  applyRefundTime = ''

  /** 地市编码 */
  cityCode = ''

  /** 地市名称 */
  cityName = ''

  /** 联系电话 */
  contactPhone = ''

  /** 处理时间 */
  dealTime = ''

  /** 详细地址 */
  detailAddr = ''

  /** 结束积分 */
  endPoints = undefined

  /** 商品名称 */
  goodsName = ''

  /** 是否已处理 0-否 1-是 */
  isDeal = undefined

  /** isDealStr */
  isDealStr = ''

  /** 订单流水号 */
  orderSerialNo = ''

  /** 订单状态 0-正常 1-已完成 2-已取消 */
  orderStatus = undefined

  /** orderStatusStr */
  orderStatusStr = ''

  /** 订单时间 */
  orderTime = ''

  /** 支付状态 0-待支付 1-已支付 2-退款中 3-已退款 */
  payStatus = undefined

  /** payStatusStr */
  payStatusStr = ''

  /** 支付时间 */
  payTime = ''

  /** 支付方式 0-积分 1-微信 2-支付宝 */
  payWay = undefined

  /** payWayStr */
  payWayStr = ''

  /** 省份编码 */
  provinceCode = ''

  /** 省份名称 */
  provinceName = ''

  /** 退款时间 */
  refundTime = ''

  /** 区县编码 */
  regionCode = ''

  /** 区县名称 */
  regionName = ''

  /** 开始积分 */
  startPoints = undefined

  /** 总积分 */
  totalPoints = undefined

  /** 总金额(分) */
  totalPrice = undefined

  /** 用户id */
  userId = undefined

  /** 用户姓名 */
  userName = ''
}

export class MenuIDParameter {
  /** 菜单ID */
  menuId = undefined
}

export class MenuToModifyParameters {
  /** 菜单图标 */
  icon = ''

  /** 菜单ID */
  menuId = undefined

  /** 菜单类型 0-司机端APP 1-运营平台 2-加油员端APP */
  menuType = undefined

  /** 名称 */
  name = ''

  /** 排序 */
  orderNum = undefined

  /** 父级ID */
  parentMenuId = undefined

  /** 类型   0：目录   1：菜单   2：按钮 */
  type = undefined

  /** 菜单URL */
  url = ''
}

export class Models {
  /** 新增时间 */
  addTime = ''

  /** id */
  id = undefined

  /** Models名称 */
  vehicleTypeName = ''
}

export class ModifyTheParameterInARelease {
  /** 附件 */
  appendixList = []

  /** 发布内容 */
  content = ''

  /** id */
  id = undefined
}

export class NewParametersInANewsRelease {
  /** 附件 */
  appendixList = []

  /** 发布内容 */
  content = ''
}

export class NewVersionControlParameters {
  /** 版本下载地址 */
  appDownUrl = ''

  /** app类型 0-油卡app 1加油员app */
  appType = undefined

  /** 版本号，如1.0.1 */
  appVersion = ''

  /** 版本序号，如101 */
  appVersionNum = undefined

  /** 是否强制升级：0-不是 ，1-是 */
  isEnforceUpgrade = undefined

  /** 终端系统类型：操作系统 0-ios 1-android 2-harmony */
  opSystem = undefined
}

export class NotifyEntity {
  /** companyCode */
  companyCode = ''

  /** data */
  data = ''

  /** timestamp */
  timestamp = undefined
}

export class Oil {
  /** id */
  id = undefined

  /** 排序 */
  orderby = undefined

  /** Oil名称 */
  petrolName = ''

  /** Oil类型 0-柴油 1-汽油 2-天然气 */
  petrolType = undefined

  /** Oil类型 0-柴油 1-汽油 2-天然气 */
  petrolTypeDesc = ''

  /** 单位 */
  units = ''
}

export class OilCardDetailedQuery {
  /** 业务交易流水号(运输订单号) */
  busiTradeNo = ''

  /** 变更类型 0-充值 1-消费 2-划出 3-划入 4-转出 5-转入 */
  changeType = undefined

  /** 结束日期 yyyy-MM-dd */
  endDate = ''

  /** 结束日期 yyyy-MM-dd HH:mm:ss */
  endTime = ''

  /** 结束日期 yyyy-MM-dd HH:mm:ss */
  endTimeStr = ''

  /** 卡id */
  petrolCardId = undefined

  /** 开始日期 yyyy-MM-dd */
  startDate = ''

  /** 开始时间 yyyy-MM-dd HH:mm:ss */
  startTime = ''

  /** 开始时间 yyyy-MM-dd HH:mm:ss */
  startTimeStr = ''
}

export class OilCardDisabledStateIsEnabled {
  /** 油卡状态 0-禁用 1-正常 */
  cardStatus = undefined

  /** 卡ID */
  id = undefined
}

export class OilCardOperationParameters {
  /** 油卡ID */
  cardId = undefined

  /** 金额 单位：分 */
  money = undefined

  /** 操作类型 1 余额退回 2余额冻结 3取消冻结 */
  opType = undefined

  /** 备注 */
  remark = ''
}

export class OilCardStatisticalQueryParameters {
  /** 结束日期 yyyy-MM-dd */
  endDate = ''

  /** 油卡类型 0-车队油卡 1-云图油卡 2-实体油卡 */
  petrolCardType = undefined

  /** 查询类型 今日-1 本周-2 本月3 */
  queryType = undefined

  /** 开始日期 yyyy-MM-dd */
  startDate = ''
}

export class OilCardTopUpParameters {
  /** 订单号(业务交易流水号) */
  busiTradeNo = ''

  /** 卡id */
  cardId = undefined

  /** -35#柴油充值油量(ml) */
  change2Petrol = undefined

  /** 0#柴油充值油量(ml) */
  changePetrol = undefined

  /** 抵扣运费(分) */
  deductionCost = undefined

  /** 车辆id */
  vehicleId = undefined
}

export class OilCardTransferDetailedQuery {
  /** 结束日期 yyyy-MM-dd */
  endDate = ''

  /** 结束日期 yyyy-MM-dd HH:mm:ss */
  endTime = ''

  /** 结束日期 yyyy-MM-dd HH:mm:ss */
  endTimeStr = ''

  /** 开始日期 yyyy-MM-dd */
  startDate = ''

  /** 开始时间 yyyy-MM-dd HH:mm:ss */
  startTime = ''

  /** 开始时间 yyyy-MM-dd HH:mm:ss */
  startTimeStr = ''

  /** 公司id */
  zcCompanyId = undefined

  /** 公司id */
  zrCompanyId = undefined
}

export class OilCardUnlockParameters {
  /** 卡ID */
  cardId = undefined

  /** 订单ID */
  orderId = undefined
}

export class OilCompanyCardInformation {
  /** 新增时间 */
  addTime = ''

  /** 新增时间 */
  addTimeStr = ''

  /** 地市编码 */
  cityCode = ''

  /** 地市名称 */
  cityName = ''

  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 授信余额 分 */
  creditLine = undefined

  /** id */
  id = undefined

  /** 限额提醒金额 */
  limitRemindMoney = undefined

  /** 油卡id */
  petrolCardId = undefined

  /** 卡号 */
  petrolCardNum = ''

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardType = undefined

  /** 油卡类型中文名称 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardTypeName = ''

  /** 省份编码 */
  provinceCode = ''

  /** 省份名称 */
  provinceName = ''

  /** 区县编码 */
  regionCode = ''

  /** 区县名称 */
  regionName = ''
}

export class OilCompanyCardQueryParameters {
  /** 油卡状态 */
  cardStatus = undefined

  /** 使用卡种 */
  cardType = undefined

  /** 地市编码 */
  cityCode = ''

  /** 合作公司id */
  orgId = undefined

  /** 省份编码 */
  provinceCode = ''

  /** 区县编码 */
  regionCode = ''
}

export class OilCompanyCardTopUpEntities {
  /** 充值时间 */
  addTime = ''

  /** 充值后金额 */
  afterMoney = undefined

  /** 充值前金额 */
  beforeMoney = undefined

  /** 变更金额 */
  changeMoney = undefined

  /** 变更类型（交易类型） 0-充值 1-消费 2-划出 3-划入 */
  changeType = undefined

  /** 变更类型 （交易类型） 0-充值 1-消费 2-划出 3-划入 */
  changeTypeName = ''

  /** 交易部门 */
  deptName = ''

  /** 搜索结束时间 */
  endTime = ''

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** 油卡id */
  petrolCardId = undefined

  /** 备注 */
  remark = ''

  /** 搜索开始时间 */
  startTime = ''

  /** 转出卡 */
  transCardNum = ''
}

export class OilCompanyStatisticalInterfaceCardObjects {
  /** 油卡数量 */
  cardNum = undefined

  /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
  cardStatus = undefined

  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 主卡卡号 */
  mainCardNo = ''

  /** 主卡剩余金额 分 */
  mainRemainingSum = undefined

  /** 主卡充值金额 分 */
  mainTotalDepositMoney = undefined

  /** 主卡id */
  petrolCardId = undefined

  /** 卡种 */
  petrolCardType = ''

  /** 副卡总充值金额 分 */
  sonDepositMoney = undefined

  /** 副卡总剩余金额 分 */
  sonRemainingSum = undefined

  /** 副卡退回金额 分 */
  sonReturnMoney = undefined

  /** 副卡总消费金额 分 */
  sonTotalConsumeMoney = undefined

  /** 车辆数量 */
  vehicleNum = undefined
}

export class OilTeamElectronicCard {
  /** 新增时间 */
  addTime = ''

  /** 油卡平台 0-云途 1-G7 */
  cardPlatform = undefined

  /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
  cardStatus = undefined

  /** 油卡状态描述 */
  cardStatusDesc = ''

  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 部门id */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 驾驶员id */
  driverId = undefined

  /** 驾驶员姓名 */
  driverName = ''

  /** 即将过期的剩余油量2(ml) */
  expireRemainConsume2PetrolWarn = undefined

  /** 即将过期的剩余油量(ml) */
  expireRemainConsumePetrolWarn = undefined

  /** id */
  id = undefined

  /** 是否主卡 0-否 1-是 */
  isPri = undefined

  /** 是否主卡描述 */
  isPriDesc = ''

  /** 登录名 */
  loginName = ''

  /** 开卡时间 */
  openTime = ''

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** 父id */
  parentId = undefined

  /** Oil2id */
  petrol2Id = undefined

  /** Oil2名称 */
  petrol2Name = ''

  /** 卡号 */
  petrolCardNum = ''

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardType = undefined

  /** 油卡类型描述 */
  petrolCardTypeDesc = ''

  /** Oilid */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** 剩余2油量(ml) */
  remaining2PetrolSum = undefined

  /** 剩余油量(ml) */
  remainingPetrolSum = undefined

  /** 累计消费2油量(ml) */
  totalConsume2Petrol = undefined

  /** 累计消费油量(ml) */
  totalConsumePetrol = undefined

  /** 累计抵扣运费(分) */
  totalDeductionCost = undefined

  /** 累计充值2油量(ml) */
  totalDeposit2Petrol = undefined

  /** 累计充值油量(ml) */
  totalDepositPetrol = undefined

  /** 车辆id */
  vehicleId = undefined

  /** 车牌号 */
  vehicleNum = ''

  /** 车辆来源 0-后台添加 1-加盟 */
  vehicleSource = undefined

  /** 车辆来源描述 */
  vehicleSourceDesc = ''

  /** 车辆类型 0-自有车辆 1-外协车辆 */
  vehicleType = undefined

  /** 车辆类型描述 */
  vehicleTypeDesc = ''

  /** Modelsid */
  vehicleTypeId = undefined

  /** Models名称 */
  vehicleTypeName = ''

  /** 云途油卡类型 0-个人云途油卡 1-公司云途油卡 2-非云途油卡 */
  ytCardType = undefined

  /** 云途油卡类型描述 */
  ytCardTypeDesc = ''
}

export class OperationLogsPagingQueryParameters {
  /** 操作结束时间 格式:yyyy-MM-dd HH:mm:ss */
  endTime = ''

  /** 用户帐号 */
  loginName = ''

  /** 操作模块 */
  opModule = ''

  /** 用户姓名 */
  operatorName = ''

  /** 操作开始时间 格式:yyyy-MM-dd HH:mm:ss */
  startTime = ''
}

export class PageBean {
  /** 总数 */
  count = undefined

  /** 当前页 */
  curPage = undefined

  /** 业务数据 */
  data = []

  /** 请求结果(http请求是否成功) */
  httpStatus = undefined

  /** 业务信息描述 */
  msg = ''

  /** 数据量/页 */
  pageSize = undefined

  /** 处理结果(业务处理是否成功) */
  resultStatus = undefined

  /** success */
  success = false
}

export class PageRequest {
  /** 当前页 */
  curPage = undefined

  /** 数据量/页 */
  pageSize = undefined

  /** startIndex */
  startIndex = undefined

  /** 查询条件 */
  where = new MallGoodsPageQueryParams()
}

export class PetrolStationNameEntity {
  /** 详细地址 */
  detailAddr = ''

  /** id */
  id = undefined

  /** OilID列表 */
  petrolIdList = []

  /** 加油站编码 */
  stationCode = ''

  /** 加油站纬度 */
  stationLat = undefined

  /** 加油站经度 */
  stationLng = undefined

  /** 加油站名称 */
  stationName = ''

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 5-G7 6-星油 7-团油 */
  stationSource = undefined

  /** 油站来源 */
  stationSourceDesc = ''
}

export class PhysicalOilBindingLogCardVehicles {
  /** 部门id */
  deptId = undefined

  /** 公司id */
  orgId = undefined

  /** 油卡ID */
  petrolCardId = undefined

  /** 车辆id */
  vehicleId = undefined
}

export class PhysicalOilCardBindingQueryParameters {
  /** 油卡id */
  cardId = undefined
}

export class PlatformOffersInformationToModifyParameters {
  /** 大图地址 */
  bigImgAddr = ''

  /** 大图id */
  bigImgId = ''

  /** id */
  id = undefined

  /** 优惠Details */
  proDetail = ''

  /** 优惠结束时间 格式:yyyy-MM-dd HH:mm:ss */
  proEndTime = ''

  /** 优惠开始时间 格式:yyyy-MM-dd HH:mm:ss */
  proStartTime = ''

  /** 优惠标题 */
  proTitle = ''

  /** 小图地址 */
  smallImgAddr = ''

  /** 小图id */
  smallImgId = ''

  /** 加油站ID */
  stationIds = []
}

export class PreferentialInformationPlatform {
  /** 新增时间 */
  addTime = ''

  /** 新增时间 */
  addTimeStr = ''

  /** 大图地址 */
  bigImgAddr = ''

  /** 大图id */
  bigImgId = ''

  /** id */
  id = undefined

  /** 优惠Details */
  proDetail = ''

  /** 优惠结束时间 */
  proEndTime = ''

  /** 优惠结束时间 */
  proEndTimeStr = ''

  /** 优惠开始时间 */
  proStartTime = ''

  /** 优惠开始时间 */
  proStartTimeStr = ''

  /** 优惠标题 */
  proTitle = ''

  /** 小图地址 */
  smallImgAddr = ''

  /** 小图id */
  smallImgId = ''

  /** 加油站ID */
  stationIds = []

  /** 加油站名称 多个逗号分隔 */
  stationNames = ''
}

export class PreferentialInformationPlatformPagingQueryParameters {
  /** 结束时间 格式:yyyy-MM-dd HH:mm:ss */
  endTime = ''

  /** 开始时间 格式:yyyy-MM-dd HH:mm:ss */
  startTime = ''

  /** 加油站Id */
  stationIds = []

  /** 加油站名称 */
  stationName = ''
}

export class PrincipalCardTopUpParameterClass {
  /** 卡种 */
  cardType = undefined

  /** 公司id */
  orgId = undefined

  /** 卡号 */
  petrolCardNum = ''

  /** 充值金额 */
  rechargeAmount = undefined

  /** 剩余金额 */
  remainAmount = undefined
}

export class ProductModificationParameters {
  /** Oilid */
  id = undefined

  /** Oil名称 */
  petrolName = ''

  /** Oil类型 0-柴油 1-汽油 2-天然气 */
  petrolType = undefined

  /** 单位 */
  units = ''
}

export class ProductOfNewParameters {
  /** Oil名称 */
  petrolName = ''

  /** Oil类型 0-柴油 1-汽油 2-天然气 */
  petrolType = undefined

  /** 单位 */
  units = ''
}

export class Provinces {
  /** 城市编码 */
  cityCode = ''

  /** 城市名称 */
  cityName = ''

  /** 省份编码 */
  provinceCode = ''

  /** 省份名称 */
  provinceName = ''

  /** 地区编码 */
  regionCode = ''

  /** 地区名称 */
  regionName = ''
}

export class QueryConditionsAppVersion {
  /** app类型 0-油卡app 1加油员app */
  appType = undefined

  /** 操作系统 0-ios 1-android 2-harmony */
  opSystem = undefined
}

export class QueryConditionsOfMakeOutInvoice {
  /** 申请结束时间 yyyy-MM-dd HH:mm:ss */
  applyEndTime = ''

  /** 申请开始时间 yyyy-MM-dd HH:mm:ss */
  applyStartTime = ''

  /** 开票结束时间 yyyy-MM-dd HH:mm:ss */
  dealEndTime = ''

  /** 开票开始时间 yyyy-MM-dd HH:mm:ss */
  dealStartTime = ''

  /** 是否已处理 0-否 1-是 */
  isDeal = undefined

  /** 发票抬头 */
  title = ''
}

export class QueryParameterClassPrincipalCardAccount {
  /** 卡种 */
  cardType = undefined

  /** 公司id */
  companyId = undefined
}

export class RefuelingOverviewHeadFuelStatistics {
  /** 统计数 */
  countNum = undefined

  /** 比率 */
  rate = undefined

  /** 标题 */
  title = ''
}

export class RegionEncodingParameters {
  /** 编码 */
  regionCode = ''
}

export class ReleaseInformationAttachment {
  /** 文件id */
  fileId = ''

  /** 文件名称 */
  fileName = ''

  /** 文件地址 */
  fileUrl = ''

  /** 附件id */
  id = undefined

  /** 发布消息id */
  publishId = undefined
}

export class ReleaseInformationAttachmentParameters {
  /** 文件id */
  fileId = ''

  /** 文件名称 */
  fileName = ''

  /** 文件地址 */
  fileUrl = ''
}

export class ReleaseInformationQueryConditions {
  /** 审核状态 */
  checkStatus = undefined

  /** 结束日期 yyyy-MM-dd */
  endDate = ''

  /** 结束日期 yyyy-MM-dd HH:mm:ss */
  endTime = ''

  /** 开始日期 yyyy-MM-dd */
  startDate = ''

  /** 开始时间 yyyy-MM-dd HH:mm:ss */
  startTime = ''

  /** 用户姓名 */
  userName = ''

  /** 用户手机号 */
  userPhone = ''
}

export class ResPetrolPrice {
  /** id */
  id = undefined

  /** 挂牌价(分) */
  listingPrice = undefined

  /** Oilid */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** Oil价格(分) */
  petrolPrice = undefined

  /** Oil类型 0-柴油 1-汽油 2-天然气 */
  petrolType = undefined

  /** Oil单位 */
  petrolUnit = ''

  /** 优惠价(分) */
  preferentialPrice = undefined

  /** 加油站id */
  stationId = undefined

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
  stationSource = undefined

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
  stationSourceStr = ''

  /** 发改委价格(分) */
  suggestPrice = undefined
}

export class ResPetrolPriceDto {
  /** //是否调价 0 否  1 是 */
  isAdjust = undefined

  /** //油价列表 */
  priceList = []

  /** //加油站编码 */
  stationCode = ''

  /** 油站id */
  stationId = undefined

  /** //加油站名称 */
  stationName = ''

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 5-G7 6-星油 */
  stationSource = undefined

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 5-G7 6-星油 */
  stationSourceDesc = ''
}

export class ResPetrolStation {
  /** 新增时间 */
  addTime = ''

  /** 银行账号 */
  bankAccount = ''

  /** 计费方式 0-金额 1-升 */
  calWay = undefined

  /** 审核人id */
  checkId = undefined

  /** 审核人姓名 */
  checkName = ''

  /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
  checkStatus = undefined

  /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
  checkStatusStr = ''

  /** 审核时间 */
  checkTime = ''

  /** 地市编码 */
  cityCode = ''

  /** 地市名称 */
  cityName = ''

  /** 联系人姓名 */
  contactName = ''

  /** 联系人电话 */
  contactPhone = ''

  /** 详细地址 */
  detailAddr = ''

  /** 加油撬编号集合  多个用英文逗号隔开 */
  deviceCodes = ''

  /** 加油站距离 km */
  distance = undefined

  /** 油枪数量 */
  gunNum = undefined

  /** id */
  id = undefined

  /** 图片 */
  imgUrl = ''

  /** 是否删除  0-否 1-是 */
  isDeleted = undefined

  /** 是否已启用  0-停用 1-启用 */
  isEnabled = undefined

  /** isEnabledStr */
  isEnabledStr = ''

  /** 油站是否在高速上 0-否  1-是 */
  isHighSpeed = undefined

  /** 是否锁卡 0-否 1-是 */
  isLockCard = undefined

  /** 是否显示 0-否 1-是 */
  isShow = undefined

  /** 加入时间 */
  joinTime = ''

  /** 组合名称 */
  merName = ''

  /** 开户地址 */
  openAddr = ''

  /** 开户银行 */
  openBank = ''

  /** 订单是否需要加油枪 0-否 1-是 */
  orderNeedGun = undefined

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardType = undefined

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardTypeStr = ''

  /** Oilid集合 */
  petrolIds = ''

  /** Oil名称集合 */
  petrolNames = ''

  /** 省份编码 */
  provinceCode = ''

  /** 省份名称 */
  provinceName = ''

  /** 返点(分)比例 */
  rebateRate = undefined

  /** 区县编码 */
  regionCode = ''

  /** 区县名称 */
  regionName = ''

  /** 加油站编码 */
  stationCode = ''

  /** 加油站纬度 */
  stationLat = undefined

  /** 加油站经度 */
  stationLng = undefined

  /** 加油站名称 */
  stationName = ''

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 5-G7 */
  stationSource = undefined

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 5-G7 */
  stationSourceStr = ''

  /** 第三方id */
  thirdId = ''

  /** 交易方式 0-司机出示二维码(加油员扫码) 1-司机主动支付 */
  tradeType = undefined

  /** 加盟方式  0-主动申请 1-后台添加 */
  unionWay = undefined

  /** 加盟方式  0-主动申请 1-后台添加 */
  unionWayStr = ''

  /** 更新时间 */
  updateTime = ''
}

export class ResPetrolStationAuditParams {
  /** //审核人id */
  checkId = undefined

  /** //审核人姓名 */
  checkName = ''

  /** //审核状态 0-待审核 1-审核通过 2-审核不通过 */
  checkStatus = undefined

  /** //id */
  id = undefined
}

export class ResPetrolStationEnableParams {
  /** //id */
  id = undefined

  /** 是否已启用  0-停用 1-启用 */
  isEnabled = undefined
}

export class ResPetrolStationLockCardParams {
  /** //id */
  id = undefined

  /** 是否显示  0-否 1-是 */
  isLockCard = undefined
}

export class ResPetrolStationOrderbyEnableParams {
  /** //id */
  id = undefined

  /** 是否已启用  0-停用 1-启用 */
  isEnabled = undefined
}

export class ResPetrolStationPageParams {
  /** 计费方式 0-金额 1-升 2-金额+升 */
  calWay = undefined

  /** //审核状态 0-待审核 1-审核通过 2-审核不通过 */
  checkStatus = undefined

  /** //地市编码 */
  cityCode = ''

  /** 联系人电话 */
  contactPhone = ''

  /** 申请结束时间  yyyy-MM-dd HH:mm:ss  2021-06-02 23:59:59 */
  endTimeStr = ''

  /** 是否已启用  0-停用 1-启用 */
  isEnabled = undefined

  /** 油站是否在高速上 0-否  1-是 */
  isHighSpeed = undefined

  /** 是否锁卡  0-否 1-1是 */
  isLockCard = undefined

  /** //油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardType = undefined

  /** //省份编码 */
  provinceCode = ''

  /** //区县编码 */
  regionCode = ''

  /** 申请开始时间  yyyy-MM-dd HH:mm:ss  2021-06-01 00:00:00 */
  startTimeStr = ''

  /** //加油站名称 */
  stationName = ''

  /** 油站来源 */
  stationSource = undefined

  /** 交易方式 0-司机出示二维码(加油员扫码) 1-司机主动支付 */
  tradeType = undefined
}

export class ResPetrolStationSaveParams {
  /** 银行账号 */
  bankAccount = ''

  /** 计费方式 0-金额 1-升 */
  calWay = undefined

  /** 审核人id */
  checkId = undefined

  /** 审核人姓名 */
  checkName = ''

  /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
  checkStatus = undefined

  /** 地市编码 */
  cityCode = ''

  /** 地市名称 */
  cityName = ''

  /** 联系人姓名 */
  contactName = ''

  /** 联系人电话 */
  contactPhone = ''

  /** 详细地址 */
  detailAddr = ''

  /** 加油撬编号集合  多个用英文逗号隔开 */
  deviceCodes = ''

  /** id */
  id = undefined

  /** 是否已启用  0-停用 1-启用 */
  isEnabled = undefined

  /** 油站是否在高速上 0-否  1-是 */
  isHighSpeed = undefined

  /** 是否锁卡 0-否 1-是 */
  isLockCard = undefined

  /** 是否显示 0-否 1-是 */
  isShow = undefined

  /** 组合名称 */
  merName = ''

  /** 开户地址 */
  openAddr = ''

  /** 开户银行 */
  openBank = ''

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardType = undefined

  /** Oilid集合 */
  petrolIds = ''

  /** Oil名称集合 */
  petrolNames = ''

  /** 省份编码 */
  provinceCode = ''

  /** 省份名称 */
  provinceName = ''

  /** 返点(分)比例 */
  rebateRate = undefined

  /** 区县编码 */
  regionCode = ''

  /** 区县名称 */
  regionName = ''

  /** 加油枪信息 */
  resStation2GunList = []

  /** GasOil信息 */
  station2PetrolList = []

  /** 加油站编码 */
  stationCode = ''

  /** 加油站加油撬信息 */
  stationDeviceList = []

  /** 加油站图片 */
  stationImgList = []

  /** 加油站纬度 */
  stationLat = undefined

  /** 加油站经度 */
  stationLng = undefined

  /** 加油站名称 */
  stationName = ''

  /** 加油站来源  0-自有加油撬  1-自有加盟  2-万金油  3-传化  4-路歌 */
  stationSource = undefined

  /** 第三方加油站ID */
  thirdId = ''

  /** 交易方式 0-司机出示二维码(加油员扫码) 1-司机主动支付 */
  tradeType = undefined
}

export class ResPetrolStationShowParams {
  /** //id */
  id = undefined

  /** 是否显示  0-隐藏 1-显示 */
  isShow = undefined
}

export class ResPhysicalBindingLog {
  /** 新增时间 */
  addTime = ''

  /** 部门id */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 驾驶员id */
  driverId = undefined

  /** 驾驶员名称 */
  driverName = ''

  /** id */
  id = undefined

  /** 设置操作时间 */
  opTime = ''

  /** 操作类型 0-绑定 1-解绑 */
  opType = undefined

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** 公司id */
  orgId = undefined

  /** 公司名称 */
  orgName = ''

  /** 油卡ID */
  petrolCardId = undefined

  /** 卡编号 */
  petrolCardNum = ''

  /** 油卡类型 */
  petrolCardType = undefined

  /** TheThirdPartyInstitution编码 */
  thirdOrgCode = ''

  /** TheThirdPartyInstitutionid */
  thirdOrgId = undefined

  /** TheThirdPartyInstitution平台 0-G7 */
  thirdOrgPlatform = undefined

  /** 车辆id */
  vehicleId = undefined

  /** 车牌号 */
  vehicleNum = ''

  /** 车辆来源 0-后台添加 1-加盟 */
  vehicleSource = undefined

  /** 车辆类型 0-自有车辆 1-外协车辆 */
  vehicleType = undefined
}

export class ResStation2GunObject {
  /** 新增时间 */
  addTime = ''

  /** 加油枪编号 */
  gunCode = ''

  /** id */
  id = undefined

  /** 是否删除  0-否 1-是 */
  isDeleted = undefined

  /** 挂牌价(分) */
  listingPrice = undefined

  /** Oilid */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** Oil类型 0-柴油 1-汽油 2-天然气 */
  petrolType = undefined

  /** 加油站id */
  stationId = undefined

  /** 三方Oil编码 */
  thirdPetrolCode = ''
}

export class ResStation2PetrolObject {
  /** 新增时间 */
  addTime = ''

  /** id */
  id = undefined

  /** 是否删除  0-否 1-是 */
  isDeleted = undefined

  /** Oil级别 例：国 V、国 IV  G7专用 */
  oilLevel = ''

  /** Oil类型 例：柴油、汽油  G7专用 */
  oilName = ''

  /** Oil标号 例：0#、97#  G7专用 */
  oilType = ''

  /** Oilid */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** Oil类型 0-柴油 1-汽油 2-天然气 */
  petrolType = undefined

  /** 加油站id */
  stationId = undefined

  /** 三方Oil编码 */
  thirdPetrolCode = ''
}

export class ResStationDeviceObject {
  /** 新增时间 */
  addTime = ''

  /** 加油撬编号 */
  deviceCode = ''

  /** id */
  id = undefined

  /** 是否删除  0-否 1-是 */
  isDeleted = undefined

  /** 是否自有 0-否 1-是 */
  isSelfDevice = undefined

  /** Oilid */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** Oil类型 0-柴油 1-汽油 2-天然气 */
  petrolType = undefined

  /** 加油站id */
  stationId = undefined
}

export class ResStationImgObject {
  /** 新增时间 */
  addTime = ''

  /** 大图地址 */
  bigImgAddr = ''

  /** 大图id */
  bigImgId = ''

  /** id */
  id = undefined

  /** 是否封面 0-否 1-是 */
  isFace = undefined

  /** 小图地址 */
  smallImgAddr = ''

  /** 小图id */
  smallImgId = ''

  /** 加油站id */
  stationId = undefined
}

export class ResStationPromotion {
  /** 优惠结束时间 */
  activityEndTime = ''

  /** 优惠开始时间 */
  activityStartTime = ''

  /** 新增时间 */
  addTime = ''

  /** 优惠信息 */
  content = ''

  /** 优惠信息id */
  id = undefined

  /** 是否删除  0-否 1-是 */
  isDeleted = undefined

  /** 加油站id */
  stationId = undefined

  /** 修改时间 */
  updateTime = ''
}

export class ResStationPromotionDto {
  /** 优惠结束时间 */
  activityEndTime = ''

  /** 优惠开始时间 */
  activityStartTime = ''

  /** 新增时间 */
  addTime = ''

  /** 优惠信息 */
  content = ''

  /** 优惠信息id */
  id = undefined

  /** 优惠信息列表 */
  promotionList = []

  /** 加油站id */
  stationId = undefined

  /** 加油站名称 */
  stationName = ''

  /** 修改时间 */
  updateTime = ''
}

export class RestResult {
  /** code */
  code = undefined

  /** message */
  message = ''

  /** result */
  result = undefined
}

export class ResultBean {
  /** 业务数据 */
  data = new CardInfoExtObject()

  /** 请求结果(http请求是否成功) */
  httpStatus = undefined

  /** 业务信息描述 */
  msg = ''

  /** 处理结果(业务处理是否成功) */
  resultStatus = undefined

  /** success */
  success = false
}

export class ReturnsTheEntityManagementList {
  /** 新增时间 */
  addTime = ''

  /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
  cardStatus = undefined

  /** 油卡类型 */
  cardTypeName = ''

  /** 地市名称 */
  cityName = ''

  /** 联系人姓名 */
  contactName = ''

  /** 联系人电话 */
  contactPhone = ''

  /** 授信余额(分) */
  creditRemainingLine = undefined

  /** 详细地址 */
  detailAddr = ''

  /** id */
  orgId = undefined

  /** 名称 */
  orgName = ''

  /** 省份名称 */
  provinceName = ''

  /** 区县名称 */
  regionName = ''
}

export class ReviewTheParametersInARelease {
  /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
  checkStatus = undefined

  /** id */
  id = undefined
}

export class RoleChangeParameters {
  /** 菜单ID */
  menuIdList = []

  /** 机构ID */
  orgId = undefined

  /** 备注 */
  remark = ''

  /** 角色ID */
  roleId = undefined

  /** 角色名称 */
  roleName = ''
}

export class RoleIDParameter {
  /** 角色ID */
  roleId = undefined
}

export class RoleOfPagingQueryConditions {
  /** 公司ID */
  companyId = undefined
}

export class StarRestResult {
  /** code */
  code = undefined

  /** data */
  data = undefined

  /** msg */
  msg = ''
}

export class StarSyncCommonParams {
  /** params */
  params = ''
}

export class StateOilCompanyCardIsDisabled {
  /** 油卡状态 0-禁用 1-正常 */
  cardStatus = undefined

  /** 公司ID */
  companyId = undefined
}

export class SysAccountPwdEditParams {
  /** 新密码 */
  newPassword = ''

  /** 旧密码 */
  password = ''
}

export class SysConfigEntity {
  /** addTime */
  addTime = ''

  /** addTimeStr */
  addTimeStr = ''

  /** configType */
  configType = undefined

  /** id */
  id = undefined

  /** textArea */
  textArea = ''

  /** textChar */
  textChar = ''

  /** updateTime */
  updateTime = ''

  /** updateTimeStr */
  updateTimeStr = ''
}

export class SysDeptEntityObject {
  /** 新增时间 */
  addTime = ''

  /** 银行账号 */
  bankAccount = ''

  /** 地市编码 */
  cityCode = ''

  /** 地市名称 */
  cityName = ''

  /** 联系人姓名 */
  contactName = ''

  /** 联系人电话 */
  contactPhone = ''

  /** 详细地址 */
  detailAddr = ''

  /** 是否默认  0-否 1-是 */
  isDefault = undefined

  /** 是否删除  0-否 1-是 */
  isDeleted = undefined

  /** 开户地址 */
  openAddr = ''

  /** 开户银行 */
  openBank = ''

  /** id */
  orgId = undefined

  /** 组织纬度 */
  orgLat = undefined

  /** 组织经度 */
  orgLng = undefined

  /** 名称 */
  orgName = ''

  /** 组织类型 0公司 1部门 */
  orgType = undefined

  /** 父级ID */
  parentOrgId = undefined

  /** 父级名称 */
  parentOrgName = ''

  /** 省份编码 */
  provinceCode = ''

  /** 省份名称 */
  provinceName = ''

  /** 区县编码 */
  regionCode = ''

  /** 区县名称 */
  regionName = ''

  /** 顶级机构ID */
  topOrgId = undefined
}

export class SysMenuEntityObject {
  /** 新增时间 */
  addTime = ''

  /** 菜单图标 */
  icon = ''

  /** 菜单ID */
  menuId = undefined

  /** 菜单类型 0-司机端APP 1-运营平台 2-加油员端APP */
  menuType = undefined

  /** 密码 */
  name = ''

  /** 排序 */
  orderNum = undefined

  /** 父级ID */
  parentMenuId = undefined

  /** 类型   0：目录   1：菜单   2：按钮 */
  type = undefined

  /** 菜单URL */
  url = ''
}

export class SysMsgEntityObject {
  /** 新增时间 */
  addTime = ''

  /** id */
  id = undefined

  /** 消息内容 */
  msgContent = ''

  /** 消息所属系统 0-APP 1-PC */
  msgFrom = undefined

  /** 消息标签 订单标签格式:{orderId:123456} */
  msgTag = ''

  /** 消息时间 */
  msgTime = ''

  /** 消息类型 1：订单消息 */
  msgType = undefined

  /** 消息类型说明 */
  msgTypeDesc = ''
}

export class SysRoleEntityObject {
  /** 创建时间 */
  addTime = ''

  /** 菜单ID */
  menuIdList = []

  /** 机构ID */
  orgId = undefined

  /** 公司名称 */
  orgName = ''

  /** 备注 */
  remark = ''

  /** 角色ID */
  roleId = undefined

  /** 角色名称 */
  roleName = ''

  /** 用户人数 */
  userNum = undefined
}

export class SysUserEntityObject {
  /** 状态  0：禁用   1：正常 */
  accountStatus = undefined

  /** 新增时间 */
  addTime = ''

  /** 绑定设备 */
  bindingDevice = ''

  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 联系电话 */
  contactPhone = ''

  /** 部门id */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 头像图片地址 */
  headImgAddr = ''

  /** 头像图片id */
  headImgId = ''

  /** 用户ID */
  id = undefined

  /** 身份证号码 */
  idCard = ''

  /** 是否管理员 0-否 1-是 */
  isAdmin = undefined

  /** 是否删除  0-否 1-是 */
  isDeleted = undefined

  /** 是否启用绑定设备 0-否 1-是 */
  isEnableBinding = undefined

  /** 登录账号 */
  loginName = ''

  /** 角色ID列表 */
  roleIdList = []

  /** 角色名称 */
  roleName = ''

  /** 加油站编码 */
  stationCode = ''

  /** 加油站id */
  stationId = undefined

  /** 加油站名称 */
  stationName = ''

  /** 用户姓名 */
  userName = ''

  /** 用户类型 0-加油员 1-驾驶员 2-公司人员 */
  userType = undefined
}

export class SystemConfigurationModificationParameters {
  /** id */
  id = undefined

  /** 富文本内容 */
  textArea = ''

  /** 字符串内容 */
  textChar = ''
}

export class SystemConfigurationQueryParameters {
  /** 配置类型 0-云途油卡用户章程 1-云途加油用户章程 2-云途油卡隐私条款 3-云途加油隐私条款 4-云途油卡帮助中心 5-云途加油帮助中心 6-管理员手机号码 */
  sysConfigType = undefined
}

export class SystemMessagePagingQueryConditions {}

export class TheAppVersionNumberQuery {
  /** app类型 0-油卡app 1加油员app */
  appType = undefined

  /** 终端系统类型：操作系统 0-ios 1-android 2-harmony */
  opSystem = undefined
}

export class TheCompanyComeOnDetailedInformation {
  /** 实付消费总价(分) */
  actTotalPrice = undefined

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  cardType = undefined

  /** 卡类型 */
  cardTypeDesc = ''

  /** 日期 */
  dateStr = ''

  /** 驾驶员 */
  driverName = ''

  /** 实际油量(ml) */
  petrolCount = undefined

  /** Oil名称 */
  petrolName = ''

  /** 加油员 */
  stationEmpName = ''

  /** 油站名称 */
  stationName = ''

  /** 车牌号 */
  vehicleNum = ''
}

export class TheDriverManagementQueryParameters {
  /** 油卡类型 */
  cardType = undefined

  /** 公司id */
  companyId = undefined

  /** 驾驶员姓名 */
  driverName = ''

  /** 手机号 */
  loginName = ''

  /** 车牌号 */
  vehicleNum = ''
}

export class TheDriverToAuditStatusParameters {
  /** 审核意见 */
  auditOpinion = ''

  /** 审核状态中文 0-待审核 1-审核通过 2-审核不通过 */
  auditStatus = undefined

  /** id */
  id = undefined
}

export class TheDriverToJoinAudit {
  /** 新增时间 */
  addTime = ''

  /** 申请时间 */
  applyTime = ''

  /** 审核意见 */
  auditOpinion = ''

  /** 审核状态 0-待审核 1-审核通过 2-审核不通过 */
  auditStatus = undefined

  /** 审核状态中文 0-待审核 1-审核通过 2-审核不通过 */
  auditStatusStr = ''

  /** 审核时间 */
  auditTime = ''

  /** 联系电话 */
  contactPhone = ''

  /** id */
  id = undefined

  /** 身份证 */
  idCard = ''

  /** Oil类型中文  */
  petrolTypeStr = ''

  /** 用户id */
  userId = undefined

  /** 用户姓名 */
  userName = ''

  /** 车辆ID */
  vehicleId = undefined

  /** 车牌号 */
  vehicleNum = ''

  /** ModelsID */
  vehicleTypeId = undefined

  /** Models名称 */
  vehicleTypeName = ''
}

export class TheInformationOfMakeOutInvoice {
  /** 新增时间 */
  addTime = ''

  /** 申请人id */
  applicantId = undefined

  /** 申请人姓名 */
  applicantName = ''

  /** 申请时间 */
  applyTime = ''

  /** 地市编码 */
  cityCode = ''

  /** 地市名称 */
  cityName = ''

  /** 企业名称 */
  companyName = ''

  /** 企业税号 */
  companyTaxNum = ''

  /** 联系电话 */
  contactPhone = ''

  /** 处理时间 */
  dealTime = ''

  /** 详细地址 */
  detailAddr = ''

  /** id */
  id = undefined

  /** 是否已处理 0-否 1-是 */
  isDeal = undefined

  /** 是否已处理 */
  isDealDesc = ''

  /** 操作人id */
  operatorId = undefined

  /** 操作人姓名 */
  operatorName = ''

  /** 省份编码 */
  provinceCode = ''

  /** 省份名称 */
  provinceName = ''

  /** 区县编码 */
  regionCode = ''

  /** 区县名称 */
  regionName = ''

  /** 发票抬头 */
  title = ''

  /** 抬头类型 0-个人 1-企业 */
  titleType = undefined

  /** 抬头类型 */
  titleTypeDesc = ''

  /** 总金额(分) */
  totalMoney = undefined

  /** 用户姓名 */
  userName = ''
}

export class TheLineChartDataReturnObjects {
  /** xline */
  xline = []

  /** yline */
  yline = []
}

export class TheLoginInformation {
  /** 登陆过期时间 */
  loginExpiredTime = ''

  /** 登陆token */
  loginToken = ''

  /** 刷新过期时间 */
  refreshExpiredTime = ''

  /** TheRefreshToken */
  refreshToken = ''
}

export class TheNewCooperationCompanyParameters {
  /** 银行账号 */
  bankAccount = ''

  /** 油卡类型集合 */
  cardTypes = []

  /** 地市编码 */
  cityCode = ''

  /** 地市名称 */
  cityName = ''

  /** 油卡信息集合 */
  companyPetrolCards = []

  /** 联系人姓名 */
  contactName = ''

  /** 联系人电话 */
  contactPhone = ''

  /** 详细地址 */
  detailAddr = ''

  /** 开户地址 */
  openAddr = ''

  /** 开户银行 */
  openBank = ''

  /** orgId */
  orgId = undefined

  /** 名称 */
  orgName = ''

  /** 省份编码 */
  provinceCode = ''

  /** 省份名称 */
  provinceName = ''

  /** 区县编码 */
  regionCode = ''

  /** 区县名称 */
  regionName = ''
}

export class TheNewMenuParameters {
  /** 菜单图标 */
  icon = ''

  /** 菜单类型 0-司机端APP 1-运营平台 2-加油员端APP */
  menuType = undefined

  /** 名称 */
  name = ''

  /** 排序 */
  orderNum = undefined

  /** 父级ID */
  parentMenuId = undefined

  /** 类型   0：目录   1：菜单   2：按钮 */
  type = undefined

  /** 菜单URL */
  url = ''
}

export class TheOilCardSubsidiaryQueryParameters {
  /** 使用卡种 */
  cardType = undefined

  /** 部门id */
  deptId = undefined

  /** 驾驶员id */
  driverId = undefined

  /** 驾驶员名称 */
  driverName = ''

  /** 合作公司id */
  orgId = undefined

  /** 油卡类型  */
  petrolCardType = undefined

  /** 车辆id */
  vehicleId = undefined

  /** 车牌号 */
  vehicleNum = ''
}

export class TheOilCardSubsidiaryReturnDetails {
  /** 卡状态  油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
  cardStatus = undefined

  /** 卡状态描述 */
  cardStatusDesc = ''

  /** 部门id */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 驾驶员id */
  driverId = undefined

  /** 驾驶员姓名 */
  driverName = ''

  /** 冻结金额（元） */
  freezeRemainingSum = undefined

  /** 卡号 */
  petrolCardNum = ''

  /** 油卡类型 0-车队油卡 1-云途油卡 2-实体油卡 */
  petrolCardType = undefined

  /** 剩余金额（元） */
  remainingSum = undefined

  /** 退回金额（元） */
  returnMoney = undefined

  /** 加油总额（元） */
  totalConsumeMoney = undefined

  /** 充值总额（元） */
  totalDepositMoney = undefined

  /** 车辆id */
  vehicleId = undefined

  /** 车牌号 */
  vehicleNum = ''
}

export class TheOperationLog {
  /** 描述 */
  description = ''

  /** 登录名 */
  loginName = ''

  /** 操作模块 */
  opModule = ''

  /** 操作时间 */
  operateTime = ''

  /** 操作人姓名 */
  operatorName = ''
}

export class TheOperatorsOfNewParameters {
  /** 状态  0：禁用   1：正常 */
  accountStatus = undefined

  /** 手机号 */
  contactPhone = ''

  /** 是否管理员 0否 1是 */
  isAdmin = undefined

  /** 加油站编号 WEB端传入,APP后端获取 */
  stationCode = ''

  /** 加油站ID WEB端传入,APP后端获取 */
  stationId = undefined

  /** 加油站名称 WEB端传入,APP后端获取 */
  stationName = ''

  /** 用户姓名 */
  userName = ''
}

export class TheOperatorsToModifyParameters {
  /** 状态  0：禁用   1：正常 */
  accountStatus = undefined

  /** 手机号 */
  contactPhone = ''

  /** 是否管理员 0否 1是 */
  isAdmin = undefined

  /** 加油站编号 WEB端传入,APP后端获取 */
  stationCode = ''

  /** 加油站ID WEB端传入,APP后端获取 */
  stationId = undefined

  /** 加油站名称 WEB端传入,APP后端获取 */
  stationName = ''

  /** 用户ID */
  userId = undefined

  /** 用户姓名 */
  userName = ''
}

export class ThePilotListManagementReturnObjects {
  /** 绑定设备 */
  bindingDevice = ''

  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 部门id */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 驾驶员ID */
  driverId = undefined

  /** 驾驶员名称 */
  driverName = ''

  /** 车辆驾驶员关联id */
  id = undefined

  /** 是否启用绑定设备 0-否 1-是 */
  isEnableBinding = undefined

  /** 联系电话 */
  loginName = ''

  /** 油卡类型 多个用英文逗号隔开 */
  petrolCardTypes = ''

  /** 车牌号 */
  vehicleNum = ''

  /** Models名称 */
  vehicleTypeName = ''
}

export class ThePilotOfNewParameterObject {
  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 驾驶员电话 */
  contactPhone = ''

  /** 部门id */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 驾驶员姓名 */
  driverName = ''

  /** 驾驶员ID */
  id = undefined

  /** 身份证号 */
  idCard = ''

  /** 登录名 */
  loginName = ''

  /** 使用卡种类型 */
  petrolCardTypes = ''

  /** 车辆ids */
  vehicleIds = []

  /** 车牌号 */
  vehicleNum = ''
}

export class ThePlatformOffersNewParameters {
  /** 大图地址 */
  bigImgAddr = ''

  /** 大图id */
  bigImgId = ''

  /** 优惠Details */
  proDetail = ''

  /** 优惠结束时间 格式:yyyy-MM-dd HH:mm:ss */
  proEndTime = ''

  /** 优惠开始时间 格式:yyyy-MM-dd HH:mm:ss */
  proStartTime = ''

  /** 优惠标题 */
  proTitle = ''

  /** 小图地址 */
  smallImgAddr = ''

  /** 小图id */
  smallImgId = ''

  /** 加油站ID */
  stationIds = []
}

export class TheReconciliationSubsidiaryEntities {
  /** 返点金额(分) */
  actRebate = undefined

  /** 加油金额/抵扣运费（分） */
  actTotalPrice = undefined

  /** 油卡类型 */
  cardTypeName = ''

  /** 所属公司名称 */
  companyName = ''

  /** 加油日期 */
  dateTime = ''

  /** 所属部门名称 */
  deptName = ''

  /** 获取方式 */
  detailSource = ''

  /** 加油撬编号 */
  deviceCode = ''

  /** 驾驶员名称 */
  driverName = ''

  /** 油枪编号 */
  gunCode = ''

  /** Details大图图片,多张图片','分隔 */
  imgBigPaths = ''

  /** Details小图图片,多张图片','分隔 */
  imgSmallPaths = ''

  /** 是否确认 */
  isConfirm = ''

  /** 是否允许核销 0-否 1-是 */
  isNeedVerification = undefined

  /** 是否核销 0-否 1-是 */
  isVerification = undefined

  /** 是否核销 0-否 1-是 */
  isVerificationDesc = ''

  /** 操作类型 0-充值 1-消费 2-退款 */
  opType = undefined

  /** 操作类型 */
  opTypeDesc = ''

  /** 操作姓名 */
  operatorName = ''

  /** 加油订单号 */
  orderSerialNo = ''

  /** 油卡订单状态 */
  orderStatus = ''

  /** 油卡状态中文名称 */
  orderStatusName = ''

  /** 支付完成时间 */
  payFinishedTime = ''

  /** 油卡支付状态 */
  payStatus = ''

  /** 卡号 */
  petrolCardNum = ''

  /** 加油量（毫升） */
  petrolCount = undefined

  /** 加油型号 */
  petrolNames = ''

  /** 退款完成时间 */
  refundFinishedTime = ''

  /** 结算金额(分) */
  settleMoney = undefined

  /** 加油员 */
  stationEmpName = ''

  /** 加油站id */
  stationId = undefined

  /** 加油站名称 */
  stationName = ''

  /** 油站所属 */
  stationSource = undefined

  /** stationSourceDesc */
  stationSourceDesc = ''

  /** 操作人 （补单人） */
  supOpName = ''

  /** 万金油流水号 */
  thirdSerialNo = ''

  /** 交易方式 0-司机出示二维码(加油员扫码) 1-司机主动支付 2-实体卡 3-补单 */
  tradeType = undefined

  /** 支付方式  */
  tradeTypeDesc = ''

  /** 车牌号名称 */
  vehicleNum = ''

  /** 核销时间 */
  verificationTime = ''
}

export class TheRefreshToken {
  /** refreshToken */
  refreshToken = ''
}

export class TheRoleOfNewParameters {
  /** 菜单ID */
  menuIdList = []

  /** 机构ID */
  orgId = undefined

  /** 备注 */
  remark = ''

  /** 角色名称 */
  roleName = ''
}

export class TheTeamOpenedByParameters {
  /** 部门id */
  deptId = undefined

  /** 车辆id */
  vehicleId = undefined
}

export class TheThirdPartyInstitution {
  /** 新增时间 */
  addTime = ''

  /** 联系人姓名 */
  contactName = ''

  /** 联系人电话 */
  contactPhone = ''

  /** id */
  id = undefined

  /** 是否删除 1是 0否 */
  isDeleted = undefined

  /** 最后同步时间 */
  lastSyncTime = ''

  /** 机构地址 */
  orgAddr = ''

  /** 机构编码 */
  orgCode = ''

  /** 机构名称 */
  orgName = ''

  /** 机构平台 0-G7 */
  orgPlatform = undefined

  /** 机构类型 组织类型 0公司 1部门 */
  orgType = undefined

  /** 云图机构id */
  ytOrgId = undefined

  /** 云图机构名称 */
  ytOrgName = ''
}

export class TheUnlockCardDetails {
  /** 卡ID */
  cardId = undefined

  /** 加油撬 */
  deviceCode = ''

  /** 驾驶员 */
  driverName = ''

  /** 锁定原因 0 驾驶员未确认 1油量为手工输入 */
  lockType = undefined

  /** 锁定原因 */
  lockTypeDesc = ''

  /** 锁定时间 */
  opTime = ''

  /** 订单ID */
  orderId = undefined

  /** 实际油量(ml) */
  petrolCount = undefined

  /** 图片列表 */
  picList = []

  /** 车牌号 */
  vehicleNum = ''
}

export class ThirdPartyParametersBound {
  /** TheThirdPartyInstitutionid */
  id = undefined

  /** 云图机构id */
  ytOrgId = undefined
}

export class TigerBalmTopUpParameters {
  /** 充值金额(分) */
  depositMoney = undefined

  /** 账户id 1-万金油 2-G7 3-星油 4-团油 */
  id = undefined

  /** 备注 */
  remark = ''
}

export class TigerBalmTopUpQueryConditions {
  /** 变化类型 0-充值 1-消费 */
  changeType = undefined

  /** 结束日期 yyyy-MM-dd */
  endDate = ''

  /** 结束日期 yyyy-MM-dd HH:mm:ss */
  endTime = ''

  /** 结束日期 yyyy-MM-dd HH:mm:ss */
  endTimeStr = ''

  /** 类型 1-万金油 2-G7 3-星油 4-团油 */
  id = undefined

  /** 开始日期 yyyy-MM-dd */
  startDate = ''

  /** 开始时间 yyyy-MM-dd HH:mm:ss */
  startTime = ''

  /** 开始时间 yyyy-MM-dd HH:mm:ss */
  startTimeStr = ''
}

export class ToMakeOutAnInvoice {
  /** 开票id */
  id = undefined
}

export class UserIDParameter {
  /** 用户ID */
  userId = undefined
}

export class UserPagingQueryParameters {
  /** 所属公司id */
  companyId = undefined

  /** 用户帐号 */
  loginName = ''

  /** 推荐人id */
  referee = undefined

  /** 角色名称 */
  roleName = ''

  /** 加油站id */
  stationId = undefined

  /** 加油站名称 */
  stationName = ''

  /** 角色名称 */
  userName = ''

  /** 用户类型 0-加油员 1-驾驶员 2-公司人员 */
  userType = undefined
}

export class UsersDisableEnableParameters {
  /** 状态  0：禁用   1：正常 */
  accountStatus = undefined

  /** 用户ID不能为空 */
  userId = undefined
}

export class VehicleInformationModifyParameters {
  /** 部门id */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 车辆id */
  id = undefined

  /** 车辆Oilid集合 */
  petrolIds = []

  /** 车牌号 只有自有车辆可以修改车牌 */
  vehicleNum = ''

  /** Modelsid */
  vehicleTypeId = undefined

  /** Models名称 */
  vehicleTypeName = ''
}

export class VehicleInformationNewParameters {
  /** 公司id */
  companyId = undefined

  /** 公司名称 */
  companyName = ''

  /** 部门id */
  deptId = undefined

  /** 部门名称 */
  deptName = ''

  /** 车辆Oilid集合 */
  petrolIds = []

  /** 车牌号 */
  vehicleNum = ''

  /** 车辆类型 0-自有车辆 1-外协车辆 */
  vehicleType = undefined

  /** Modelsid */
  vehicleTypeId = undefined

  /** Models名称 */
  vehicleTypeName = ''
}

export class VehicleProductInformation {
  /** 新增时间 */
  addTime = ''

  /** id */
  id = undefined

  /** Oilid */
  petrolId = undefined

  /** Oil名称 */
  petrolName = ''

  /** Oil类型 0-柴油 1-汽油 2-天然气 */
  petrolType = undefined

  /** 车辆id */
  vehicleId = undefined
}

export class VersionControl {
  /** 新增时间 */
  addTime = ''

  /** 版本下载地址 */
  appDownUrl = ''

  /** app类型 0-油卡app 1加油员app */
  appType = undefined

  /** app类型 */
  appTypeDesc = ''

  /** 版本号，如1.0.1 */
  appVersion = ''

  /** 版本序号，如101 */
  appVersionNum = undefined

  /** ID */
  id = undefined

  /** 是否强制升级：0-不是 ，1-是 */
  isEnforceUpgrade = undefined

  /** 是否强制升级 */
  isEnforceUpgradeDesc = ''

  /** 终端系统类型：操作系统 0-ios 1-android 2-harmony */
  opSystem = undefined

  /** 终端系统类型 */
  opSystemDesc = ''
}

export class VersionControlToModifyParameters {
  /** 版本下载地址 */
  appDownUrl = ''

  /** app类型 0-油卡app 1加油员app */
  appType = undefined

  /** 版本号，如1.0.1 */
  appVersion = ''

  /** 版本序号，如101 */
  appVersionNum = undefined

  /** id */
  id = undefined

  /** 是否强制升级：0-不是 ，1-是 */
  isEnforceUpgrade = undefined

  /** 终端系统类型：操作系统 0-ios 1-android 2-harmony */
  opSystem = undefined
}

export class WJYFuel {
  /** fuel_name */
  fuel_name = ''

  /** fuel_no */
  fuel_no = ''

  /** guide_price */
  guide_price = ''

  /** is_discount */
  is_discount = undefined

  /** original_price */
  original_price = ''

  /** price */
  price = ''

  /** sf_id */
  sf_id = ''

  /** status */
  status = ''
}

export class WJYStation {
  /** address */
  address = ''

  /** areaCode */
  areaCode = ''

  /** brand_name */
  brand_name = ''

  /** channel */
  channel = ''

  /** cityCode */
  cityCode = ''

  /** fuels */
  fuels = []

  /** h_ids */
  h_ids = []

  /** isHighspeed */
  isHighspeed = undefined

  /** isStop */
  isStop = undefined

  /** is_input_money */
  is_input_money = ''

  /** lat */
  lat = ''

  /** lng */
  lng = ''

  /** logo */
  logo = ''

  /** open_time */
  open_time = ''

  /** provinceCode */
  provinceCode = ''

  /** sa_id */
  sa_id = ''

  /** stationId */
  stationId = ''

  /** stationName */
  stationName = ''

  /** status */
  status = undefined
}

export class WhetherToEnableBindingEquipmentParameters {
  /** 状态  0：否   1：是 */
  status = undefined

  /** 用户ID不能为空 */
  userId = undefined
}
