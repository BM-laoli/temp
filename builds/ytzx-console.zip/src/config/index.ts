const config = {
  development: {
    APP_VER_NUM: 1,
    APP_VER: '1.0.0',
    // API_HOST: 'http://localhost:8088/web-service',
    API_HOST: 'http://api.web.yuntuiov.com/web-service',
    OSS_KEY_SECRET: '',
    OSS_KEY_ID: '',
    OSS_ENDPOINT: '',
    OSS_BUCKET: '',
    OSS_HOST: '',
    AMAP_KEY: '4384854ececf16d830ff193e38bb8e3d',
  },
  productionDev: {
    APP_VER_NUM: 1,
    APP_VER: '1.0.0',
    API_HOST: 'http://api.web.yuntuiov.com/web-service',
    // API_HOST: 'http://101.201.73.250:8080/web-service',
    OSS_KEY_SECRET: '',
    OSS_KEY_ID: '',
    OSS_ENDPOINT: '',
    OSS_BUCKET: '',
    OSS_HOST: '',
    AMAP_KEY: '4384854ececf16d830ff193e38bb8e3d',
  },
  production: {
    APP_VER_NUM: 1,
    APP_VER: '1.0.0',
    API_HOST: 'http://api.web.yuntuiov.com/web-service',
    OSS_KEY_SECRET: '',
    OSS_KEY_ID: '',
    OSS_ENDPOINT: '',
    OSS_BUCKET: '',
    OSS_HOST: '',
    AMAP_KEY: '4384854ececf16d830ff193e38bb8e3d',
  },
};
const pro = config[process.env.CONFIG_ENV || 'development'];
export default pro;
