import React, { useEffect, useState, memo } from "react";
import * as Api from "@/api";
import { Select, SelectProps } from 'antd'
import { observer } from 'mobx-react-lite'
import { useStore } from '@/models'

const Option = Select.Option;

interface BaseSelectProps extends SelectProps<any> {
  filterData?:defs.EnumVo[]
  valueFormat?: (item: defs.EnumVo) => string
}
/**
 * 信用卡银行选择器
 */
const StationSourceSelect: React.FC<BaseSelectProps> = ({ filterData, valueFormat, ...props }) => {
  const { global } = useStore()
  const [data, setData] = useState<defs.EnumVo[]>([]);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    const res = await API.dictionary.findResStationSourceEnumList.request();
    if (res.success && res.data) {
      const names = filterData?.map(v=>v.desc)||[];
      setData(res.data.filter(v=>!names.includes(v.desc)));
    }
  }

  return (
    <Select
      placeholder={'请选择加油站来源'}
      style={{ width: '100%' }}
      showSearch
      allowClear
      filterOption={(input, option) =>
        option?.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
      }
      {...props}>
      {data.map(v => {
        return (
          <Option key={v.desc} value={valueFormat ? valueFormat(v) : v.code as any||0 }>{v.desc}</Option>
        )
      })}
    </Select>
  )
}

export default StationSourceSelect;