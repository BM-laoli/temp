/*
 * @Author: TigerLord
 * @Date: 2022-09-06 15:28:29
 * @LastEditTime: 2022-12-27 16:50:42
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/components/ExportButton.tsx
 */
import React, { useState } from 'react';
import { Button, message } from 'antd';
import { ButtonProps } from 'antd/lib/button/button';
import { Query } from '@cyber-ccx/lib';
import { requestUpload } from '@/utils/request';
import excel from '@/utils/excel';
import config from '@/config';

interface ExportButtonProps extends Omit<ButtonProps, 'onClick' | 'loading'> {
  query?: Query;
  url: string;
  title: string;
  method?: 'GET' | 'POST';
  formFormat?: (data: any) => any;
}

const ExportButton: React.FC<ExportButtonProps> = ({ query, title, url, method = 'POST', formFormat, ...props }) => {
  const [loading, setLoading] = useState(false);

  const handleClick = async () => {
    setLoading(true);
    try {
      let params = query?.get() || {};
      if (formFormat) {
        params = formFormat(params);
      }
      const res: BaseResponse<Blob> = await requestUpload({
        url: config.API_HOST + url,
        data: params,
        method: method,
        credentials: 'include',
        timeout: 180 * 1000,
      });
      if (res && res instanceof Blob) {
        excel.downloadExcel(res, title);
      } else {
        message.error('导出失败');
      }
    } catch (error) {
      message.error('导出失败');
    } finally {
      setLoading(false);
    }
  };

  return <Button {...props} loading={loading} onClick={handleClick} />;
};

export default ExportButton;
