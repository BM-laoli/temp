/*
 * @Author: TigerLord
 * @Date: 2022-09-06 15:28:29
 * @LastEditTime: 2022-10-17 17:00:48
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/components/OrgSelect.tsx
 */
import React, { useEffect, useState, memo } from "react";
import * as Api from "@/api";
import { Select, TreeSelect, TreeSelectProps, } from 'antd'
import { observer } from 'mobx-react-lite'
import { useStore } from '@/models'

interface BaseSelectProps extends TreeSelectProps<any> {
  orgId?: number
  topOrg?: boolean
}
/**
 * 信用卡银行选择器
 */
const OrgSelect: React.FC<BaseSelectProps> = ({ orgId,topOrg, ...props }) => {
  const [treeData, setTreeData] = useState<any>([])

  useEffect(() => {
    load();
  }, [orgId]);

  const load = async () => {
    if(!orgId) return ;
    const res = await API.sysOrg.selectByOrgId.request({
      orgId: orgId || 0
    });
    if (res.success && res.data) {
      console.log('-----2222222---', res.data);
      const _temp: any = [];
      const _tempObj: any = {};
      res.data?.forEach(v => {
        const m = {
          title: v.orgName,
          id: v.orgId,
          key: v.orgId,
          children: []
        }
        if (v.parentOrgId === 0) {
          _temp.push(m);
        }
        _tempObj[m.key || ''] = m;
      })

      res.data?.forEach(v => {
        if (_tempObj[v.parentOrgId || '']) {
          _tempObj[v.parentOrgId || ''].children.push(_tempObj[v.orgId || '']);
        }
      })
      if(topOrg){
        setTreeData(_temp);
      }else{
       const dataT: any = _temp[0]?.children || []
        setTreeData(dataT);
      }
      console.log('asdfasdfaf', treeData);
      
    }
  }

  return (
    <TreeSelect treeData={treeData} {...props} />
  )
}

export default OrgSelect;