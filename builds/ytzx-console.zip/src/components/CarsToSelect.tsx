/*
 * @Author: TigerLord
 * @Date: 2022-09-06 15:28:29
 * @LastEditTime: 2022-10-28 18:17:06
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/components/CarsToSelect.tsx
 */
import React, { useEffect, useState, memo } from "react";
import * as Api from "@/api";
import { Select, SelectProps } from 'antd'
import { observer } from 'mobx-react-lite'
import { useStore } from '@/models'

const Option = Select.Option;

interface BaseSelectProps extends SelectProps<any> {
  defaultId?: number
  defaultIds?: number[]
  companyId?: number
  deptId?: number
  filterData?: defs.CompanyVehicleInformation[]
  valueFormat?: (item: defs.CompanyVehicleInformation) => string
}
/**
 * 车辆选择器
 */
const CompanySelect: React.FC<BaseSelectProps> = ({ companyId, deptId, defaultIds, defaultId, filterData, valueFormat, ...props }) => {
  const [data, setData] = useState<defs.CompanyVehicleInformation[]>([]);

  useEffect(() => {
    load();
  }, [deptId]);

  const load = async () => {
    if (companyId === undefined || deptId === undefined) return;
    const res = await API.stYutuCard.getVehicleListByDeptId.request({
      companyId,
      deptId,
      vehicleId: defaultId,
      vehicleIds: defaultIds ? defaultIds : defaultId ? [defaultId] : undefined
    });
    if (res.success && res.data) {
      const names = filterData?.map(v => v.id) || [];
      setData(res.data.filter(v => !names.includes(v.id)));
    }
  }

  return (
    <Select
      placeholder={'请选择车辆'}
      style={{ width: '100%' }}
      showSearch
      allowClear
      filterOption={(input, option) =>
        option?.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
      }
      {...props}>
      {data.map(v => {
        return (
          <Option key={v.id} value={valueFormat ? valueFormat(v) : v.id || ''} data={v}>{v.vehicleNum}</Option>
        )
      })}
    </Select>
  )
}

export default CompanySelect;