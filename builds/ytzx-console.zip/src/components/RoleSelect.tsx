import React, { useEffect, useState, memo } from "react";
import * as Api from "@/api";
import { Select, SelectProps } from 'antd'
import { observer } from 'mobx-react-lite'
import { useStore } from '@/models'

const Option = Select.Option;

interface BaseSelectProps extends SelectProps<any> {
  orgId?:number
  filterData?:defs.SysRoleEntityObject[]
  valueFormat?: (item: defs.SysRoleEntityObject) => string
}
/**
 * 信用卡银行选择器
 */
const RoleSelect: React.FC<BaseSelectProps> = ({orgId, filterData, valueFormat, ...props }) => {
  const { global } = useStore()
  const [data, setData] = useState<defs.SysRoleEntityObject[]>([]);

  useEffect(() => {
    load();
  }, [orgId]);

  const load = async () => {
    if(!orgId) return ;
    let res = await API.sysRole.select.request({
      orgId
    });
    if (res.success && res.data) {
      let names = filterData?.map(v=>v.roleId)||[];
      setData(res.data.filter(v=>!names.includes(v.roleId)));
    }
  }

  return (
    <Select
      placeholder={'请选择角色'}
      style={{ width: '100%' ,maxWidth:'100%'}}
      showSearch
      allowClear
      {...props}>
      {data.map(v => {
        return (
          <Option key={v.orgId} value={valueFormat ? valueFormat(v) : v.roleId??'' }>{v.roleName}</Option>
        )
      })}
    </Select>
  )
}

export default RoleSelect;