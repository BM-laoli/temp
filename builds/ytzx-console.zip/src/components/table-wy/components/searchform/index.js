import React, { useRef, useEffect, useState } from 'react';
import { Form, Input, Select } from 'antd';
import _ from 'lodash';
const { Option } = Select;
const SearchForm = (({ children, query, formControl, btns }) => {
    const [form] = Form.useForm();
    const queryData = query.get();
    const clear = (arg) => {
        let res = form.getFieldsValue();
        for (let k in res) {
            res[k] = '';
        }
        form.setFieldsValue(res);
        if (queryData.page) {
            res.page = 1;
        }
        query.set(res);
    };
    const submit = () => {
        form.submit();
    };
    const search = (values) => {
        values.page=1;
        query.set(values);
    };
    useEffect(() => {
        if (formControl && !_.isFunction(formControl)) {
            formControl.init({
                clear,
                submit
            });
        }
    }, []);
    return (React.createElement(Form, { name: "search", form: form, onFinish: search, layout: 'horizontal', labelCol: { span: 8 }, initialValues: query },
        React.createElement("div", { style: { display: 'flex', width: '100%' } },
            React.createElement("div", { style: { flex: 1 } }, children),
            btns &&
                React.createElement("div", { style: { display: 'flex', marginLeft: '16px' } }, btns.map((v, i) => (React.createElement("div", { key: `search_btn@${i}` }, v)))))));
});
export const SearchInput = ({ option = [], placeholder = '', onSearch, name, query }) => {
    const defaultSelect = option.length ? option[0].value : '';
    const [select, setSelect] = useState(defaultSelect);
    const [inputPlaceholder, setInputPlaceholder] = useState(placeholder);
    const changeSelect = (e) => {
        let op = option.find(v => v.value === e);
        if (op === null || op === void 0 ? void 0 : op.placeholder) {
            setInputPlaceholder(op.placeholder);
        }
        setSelect(e);
    };
    const onSubmit = (value) => {
        if (query) {
            let data = Object.assign({}, query.get());
            delete data.page;
            if (name) {
                data[name] = value;
                query.set(data, true);
            }
            else if (option.length) {
                option.forEach(v => {
                    data[v.value] = undefined;
                });
                data[select] = value;
                query.set(data, true);
            }
        }
        else if (onSearch) {
            onSearch({ select, value });
        }
    };
    useEffect(() => {
        if (option.length) {
            let op = option.find(v => v.value === select);
            if (op === null || op === void 0 ? void 0 : op.placeholder) {
                setInputPlaceholder(op.placeholder);
            }
        }
    }, []);
    return (React.createElement(Input.Group, { compact: true },
        !!option.length &&
            React.createElement(Select, { value: select, onChange: changeSelect }, option.map(v => (React.createElement(Option, { value: v.value, key: v.text + v.value }, v.text)))),
        React.createElement(Input.Search, { style: { width: '220px' }, placeholder: inputPlaceholder, onSearch: onSubmit })));
};
export const useSearchForm = () => {
    const onInit = () => { throw new Error(''); };
    const form = useRef({
        clear: onInit,
        submit: onInit
    });
    return {
        init(root) {
            form.current = root;
        },
        submit() {
            form.current.submit();
        },
        clear(arg) {
            form.current.clear(arg);
        }
    };
};
export default SearchForm;
