import React from 'react';
import { Query } from '../query/index';
interface SearchFormProps {
    formControl: SearchFormControl;
    children: any;
    query: Query;
    btns?: React.ReactElement[];
}
interface SearchFormRef {
    /** 清除查询条件 */
    clear: (arg?: boolean | object) => void;
    /** 提交查询条件 */
    submit: () => void;
}
interface SearchFormControl extends SearchFormRef {
    init: (root: SearchFormRef) => void;
}
declare const SearchForm: React.FC<SearchFormProps>;
interface SearchInputProps {
    option?: {
        /** select的text */
        text: string;
        /** select的value */
        value: string;
        /** 不同select，input的placeholder */
        placeholder?: string;
    }[];
    placeholder?: string;
    onSearch?: (e: {
        select: string;
        value: string;
    }) => void;
    name?: string;
    query?: Query;
}
export declare const SearchInput: React.FC<SearchInputProps>;
export declare const useSearchForm: () => SearchFormControl;
export default SearchForm;
