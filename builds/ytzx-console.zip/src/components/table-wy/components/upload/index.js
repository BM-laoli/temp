var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
import React, { useEffect, useState } from "react";
import { Upload, Button } from "antd";
import { AntIcon } from '../icon';
import OSS from '@/utils/oss';
const UploadImg = (_a) => {
    var { value, style, filePath = '', maxLength = 100, onChange } = _a, props = __rest(_a, ["value", "style", "filePath", "maxLength", "onChange"]);
    const [fileList, setFileList] = useState([]);
    const [loading, setLoading] = useState(false);
    const uploadImg = (e) => {
        let ext = e.file.name.split('.')[1];
        let fileName = parseInt(Math.random() * 1000000 + '') + "-" + Date.now() + '.' + ext;
        setLoading(true);
        OSS.upload(`${filePath}/${fileName}`, e.file).then(function (res) {
            setLoading(false);
            e.onSuccess({ data: res.url }, {});
        });
        return {};
    };
    useEffect(() => {
        if (value) {
            let _fileList = value.map((v, i) => ({
                uid: i,
                status: 'done',
                url: v,
                response: {
                    data: v
                }
            }));
            setFileList(_fileList);
        }
    }, [value]);
    const onFileChange = (e) => {
        if (e.fileList.length <= maxLength) {
            if (e.fileList.filter((v) => v.status !== 'done').length === 0) {
                onChange && onChange(e.fileList.map((v) => v.response.data));
            }
        }
    };
    return (React.createElement(Upload, { style: style, listType: "picture-card", fileList: fileList, customRequest: uploadImg, onChange: onFileChange }, fileList.length < maxLength && (React.createElement("div", null,
        React.createElement(AntIcon, { type: "PlusOutlined" }),
        React.createElement("div", { style: { marginTop: 8 } }, "\u9009\u62E9\u56FE\u7247")))));
};
const UploadFile = (_a) => {
    var { value, style, filePath = '', maxLength = 100, onChange } = _a, props = __rest(_a, ["value", "style", "filePath", "maxLength", "onChange"]);
    const [fileList, setFileList] = useState([]);
    const [loading, setLoading] = useState(false);
    const uploadImg = (e) => {
        let ext = e.file.name.split('.')[1];
        let fileName = parseInt(Math.random() * 1000000 + '') + "-" + Date.now() + '.' + ext;
        setLoading(true);
        OSS.upload(`${filePath}/${fileName}`, e.file).then(function (res) {
            setLoading(false);
            e.onSuccess({ data: res.url, name: fileName }, {});
        });
        return {};
    };
    useEffect(() => {
        if (value) {
            let _fileList = value.map((v, i) => ({
                uid: i,
                status: 'done',
                name: `文件${i + 1}${v.substring(v.lastIndexOf('.'))}`,
                url: v,
                response: {
                    data: v
                }
            }));
            setFileList(_fileList);
        }
    }, [value]);
    const onFileChange = (e) => {
        if (e.fileList.length <= maxLength) {
            if (e.fileList.filter((v) => v.status !== 'done').length === 0) {
                onChange && onChange(e.fileList.map((v) => v.response.data));
            }
        }
    };
    return (React.createElement(Upload, { style: style, fileList: fileList, customRequest: uploadImg, onChange: onFileChange },
        React.createElement(Button, { loading: loading, icon: React.createElement(AntIcon, { type: 'UploadOutlined' }) }, "\u9009\u62E9\u6587\u4EF6")));
};
export { UploadImg, UploadFile };
