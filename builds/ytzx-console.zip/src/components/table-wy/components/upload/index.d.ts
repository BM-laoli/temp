import React from "react";
interface UploadProp {
    value?: string[];
    onChange?: (value: string) => void;
    maxLength?: number;
    filePath?: string;
    style?: React.CSSProperties;
}
declare const UploadImg: React.FC<UploadProp>;
declare const UploadFile: React.FC<UploadProp>;
export { UploadImg, UploadFile };
