import React from 'react';
interface IProps extends React.HTMLAttributes<HTMLSpanElement> {
    [key: string]: any;
    type?: string;
    url?: string;
}
export declare const AntIcon: React.FC<IProps>;
export declare const IconFont: React.FC<IProps>;
export {};
