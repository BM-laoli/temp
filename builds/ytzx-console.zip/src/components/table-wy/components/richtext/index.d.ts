import React from "react";
interface RichTextEditorProp {
    defaultValue?: string;
    value?: string;
    filePath?: string;
    onChange?: (html: string) => void;
    style?: React.CSSProperties;
    uploadFile?: (file: any) => Promise<string>;
    [key: string]: any;
}
declare const RichTextEditor: React.FC<RichTextEditorProp>;
export default RichTextEditor;
