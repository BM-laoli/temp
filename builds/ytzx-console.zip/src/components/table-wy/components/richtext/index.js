var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
import React, { useEffect, useRef } from "react";
import OSS from '@/utils/oss';
import WE from 'wangeditor';
const RichTextEditor = (_a) => {
    var { filePath, value, defaultValue, onChange, uploadFile, id = 'editor' } = _a, prop = __rest(_a, ["filePath", "value", "defaultValue", "onChange", "uploadFile", "id"]);
    const editor = useRef();
    useEffect(() => {
        editor.current = new WE(`#${id}`);
        if (onChange) {
            editor.current.config.onchange = onChange;
        }
        editor.current.config.customUploadImg = (resultFiles, insertImgFn) => __awaiter(void 0, void 0, void 0, function* () {
            if (uploadFile) {
                let res = yield uploadFile(resultFiles[0]);
                insertImgFn(res);
            }
            else {
                let ext = resultFiles[0].name.split('.')[1];
                let fileName = parseInt(Math.random() * 1000000 + "") + "-" + Date.now() + '.' + ext;
                let res = yield OSS.upload(`${filePath}/${fileName}`, resultFiles[0]);
                insertImgFn(res.url);
            }
        });
        editor.current.create();
        if (defaultValue) {
            editor.current.txt.html(defaultValue);
        }
        if (value) {
            editor.current.txt.html(value);
        }
        return () => {
            var _a;
            (_a = editor.current) === null || _a === void 0 ? void 0 : _a.destroy();
        };
    }, []);
    useEffect(() => {
        if (editor.current)
            editor.current.txt.html(value);
    }, [value]);
    return React.createElement("div", Object.assign({ id: id }, prop));
};
export default RichTextEditor;
