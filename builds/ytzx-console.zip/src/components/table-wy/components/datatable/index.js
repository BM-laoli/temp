var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
import React, { useState, useEffect, useRef, memo, useMemo, useImperativeHandle } from 'react';
import { Table, Button, Menu, Dropdown, Popover, Checkbox, Form, Tooltip } from 'antd';
import { AntIcon } from '../icon';
import _ from 'lodash';
import md5 from 'blueimp-md5';
const { Column } = Table;
const FormItem = Form.Item;
/**
 * 兼容antd table所有属性
 * @param param0
 */
const DataTable = React.forwardRef((_a, ref) => {
    var { noTools, defaultTableSize = 'large', pagination = {}, editer, query, onRowFormSubmit, title, api, rowKeyIndex, rowKey, noPagination, dataFormat, formFormat, children, toolsBtns } = _a, props = __rest(_a, ["noTools", "defaultTableSize", "pagination", "editer", "query", "onRowFormSubmit", "title", "api", "rowKeyIndex", "rowKey", "noPagination", "dataFormat", "formFormat", "children", "toolsBtns"]);
    /** 列表数据 */
    const [data, setData] = useState([]);
    /** 列表总数 */
    const [total, setTotal] = useState(0);
    const queryData = query === null || query === void 0 ? void 0 : query.get();
    const filterKeys = useRef({});
    const [tableSize, setTableSize] = useState(defaultTableSize);
    const tableKey = useRef(md5(Date.now()));
    const [editKey, setEditKey] = useState([]);
    const [form] = Form.useForm();
    useImperativeHandle(ref, () => ({
        data,
        total
    }));
    /** 默认生成key的方法 */
    const defaultRowKey = (item) => rowKey ? rowKey(item) : item[rowKeyIndex || ''];
    const directions2Query = (directions) => directions.replace('end', '');
    const query2Directions = (directions) => directions += 'end';
    /** 数据加载 */
    const load = () => __awaiter(void 0, void 0, void 0, function* () {
        let form = Object.assign({}, queryData);
        let data = [];
        let total = 0;
        if (_.isFunction(api)) {
            console.log(form,2323);
            form.page = queryData.page ? _.toNumber(queryData.page) : 1;
            form.rows = queryData.rows ? _.toNumber(queryData.rows) : 30;
            if (queryData.order) {
                form.order = [...queryData.order];
            }
            if (formFormat && _.isFunction(formFormat)) {
                form = formFormat(form);
                delete form.where?.page
                delete form.where?.rows
            }
            console.log('请求头', form);
            let res = yield api(form);
            if ((res === null || res === void 0 ? void 0 : res.success) && (res === null || res === void 0 ? void 0 : res.data)) {
                let rows = [];
                console.log('来了老弟', res.data);

                if (dataFormat && _.isFunction(dataFormat)) {
                    let _res = dataFormat(res);

                    rows = _res.rows;
                    total = _res.total;
                }
                else {
                    rows = res.data;
                    total = res.count || res.data.length;
                }
                data.push(...rows);
            }
        }
        setData(data);
        setTotal(total);
    });
    /** 改变表单的所有数据变化 */
    const changeTable = (p, f, s) => {
        console.log(p, f, s);
        let _query = {};
        /** 页码和rows */
        _query.page = p.current;
        _query.rows = p.pageSize;
        /** 过滤器 */
        let filters = _.toPairs(f);
        filters.forEach(([k, v]) => {
            _query[filterKeys.current[k]] = v ? v.join(',') : null;
        });
        /** 排序 */
        let sorts = _.isArray(s) ? s : [s];
        let order = [];
        sorts.forEach(v => {
            if (v.order) {
                order.push({
                    field: v.column.sortKey || v.field,
                    direction: directions2Query(v.order)
                });
            }
        });
        _query.order = order;
        query === null || query === void 0 ? void 0 : query.set(_query);
    };
    const createRowForm = (key) => {
        return {
            getValue: (feild) => {
                return form.getFieldValue(`${key}_${feild}`);
            },
            getValues: () => {
                let values = form.getFieldsValue();
                let res = {};
                for (let k in values) {
                    if (k.includes(key)) {
                        res[k.split('_')[1]];
                    }
                }
                return res;
            },
            setValue: (feild, value) => {
                form.setFieldsValue({ [`${key}_${feild}`]: value });
            },
            submit: () => {
                let values = form.getFieldsValue();
                let res = {};
                for (let k in values) {
                    if (k.includes(key)) {
                        res[k.split('_')[1]];
                    }
                }
                onRowFormSubmit && onRowFormSubmit(res);
            },
            eidt: () => {
                setEditKey((keys) => {
                    let _k = [...keys];
                    if (_k.includes(key)) {
                        _k.push(key);
                    }
                    return _k;
                });
            },
            close: () => {
                setEditKey((keys) => {
                    let _k = [...keys];
                    if (_k.includes(key)) {
                        _k.splice(_k.indexOf(key), 1);
                    }
                    return _k;
                });
            }
        };
    };
    const _pagination = noPagination ? false : Object.assign({ current: (queryData === null || queryData === void 0 ? void 0 : queryData.page) ? _.toNumber(queryData.page) : 1, total, pageSize: (queryData === null || queryData === void 0 ? void 0 : queryData.rows) ? _.toNumber(queryData.rows) : 30, showSizeChanger: true, pageSizeOptions: ['10', '20', '30', '40', '100'], showQuickJumper: true, showTotal: (total) => `共 ${total} 条` }, pagination);
    /**
     * antd 的table机制有点弱智，他会吧children的props抽离出来，
     * 然后重新创建一个新的children所以只能在这一级做一次包装做一次和他一样的操作来封装DataColumn
     * @param c
     */
    const createChild = (c, i) => {
        let Child = c.type;
        let filtered = false;
        let values = [];
        let sorter = false;
        let _a = c.props, { render, cellRender, formRender, tooltip } = _a, cprops = __rest(_a, ["render", "cellRender", "formRender", "tooltip"]);
        /**
         * 设置过滤器初始值
         */
        if (queryData && c.props.filters && c.props.filters.length) {
            let _fk = c.props.filterKey || c.props.dataIndex;
            filterKeys.current[c.props.dataIndex] = _fk;
            let _value = queryData[_fk];
            if (_value) {
                values = _value.split(',');
                filtered = true;
            }
        }
        /**
         * 设置多选
         */
        if (c.props.sorter && _.isArray(children)) {
            sorter = { multiple: children.length - i };
        }
        /**
         * 设置排序初始值
         */
        let sortOrder = false;
        if (queryData && queryData.order && queryData.order.find(v => v.field === c.props.dataIndex || v.field === c.props.sortKey)) {
            let _order = queryData.order.find(v => v.field === c.props.dataIndex || v.field === c.props.sortKey);
            console.log(1111111111111, _order);
            sortOrder = query2Directions(_order.direction);
        }
        let shouldCellUpdate = (record, prevRecord) => {
            let flag = false;
            if (record && prevRecord) {
                try {
                    flag = JSON.stringify(record) !== JSON.stringify(prevRecord);
                }
                catch (e) {
                    flag = false;
                }
            }
            return flag;
        };
        let baseRender = (text, record, index) => {
            let key = defaultRowKey(record);
            let rowform = createRowForm(key);
            if (editKey.includes(key)) {
                return (React.createElement(FormItem, { name: `${key}_${cprops.dataIndex}` }, formRender && formRender(text, record, index, rowform)));
            }
            else if (cellRender) {
                return cellRender(text, record, index, rowform);
            }
            else {
                return render && render(text, record, index);
            }
        };
        let tooltipRender = (text, record, index) => {
            return (React.createElement("div", { style: { whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } },
                React.createElement(Tooltip, { placement: 'topLeft', title: text }, text)));
        };
        return React.createElement(Child, Object.assign({ key: c.props.dataIndex || `${tableKey.current}-cell-${i}`, width: '150px' }, cprops, { render: render ? baseRender : tooltip ? tooltipRender : undefined, filteredValue: values, filtered: filtered, sorter: sorter, sortOrder: sortOrder }));
    };
    /**
     * 查询条件变化触发刷新
     */
    useEffect(() => {
        load();
    }, [JSON.stringify(queryData), api]);
    const menu = (React.createElement(Menu, { selectedKeys: [tableSize], onClick: (e) => setTableSize(e.key) },
        React.createElement(Menu.Item, { key: "large" }, "\u9ED8\u8BA4"),
        React.createElement(Menu.Item, { key: "middle" }, "\u4E2D\u7B49"),
        React.createElement(Menu.Item, { key: "small" }, "\u7D27\u51D1")));
    const settingCells = useMemo(() => {
        return _.isArray(children) ? children.map((c, i) => {
            return ({
                label: c.props.title,
                value: c.props.dataIndex || `${tableKey.current}-cell-${i}`
            });
        }) : [];
    }, [children]);
    const [selectCell, setSelectCell] = useState(settingCells.map(v => v.value));
    const changeSelectCell = (values) => setSelectCell(values);
    const cellSettingContent = (React.createElement("div", { className: "table-selectCell" },
        React.createElement(Checkbox.Group, { options: settingCells, defaultValue: selectCell, onChange: changeSelectCell })));
    const y = tableSize === 'large' ? 56 : tableSize === 'middle' ? 47 : 39;
    const table = (React.createElement(Table, Object.assign({ size: tableSize, onChange: changeTable, rowKey: defaultRowKey, dataSource: data, pagination: api ? _pagination : undefined, scroll: { x: '100%', y: `calc(100% - ${y}px)` } }, props), _.isArray(children) && children.map(createChild).filter(v => selectCell.includes(v.key))));
    return (React.createElement(React.Fragment, null,
        !noTools &&
            React.createElement("div", { className: "table-toolsbar" },
                React.createElement("div", { className: "title" }, title),
                React.createElement("div", { className: "btns" }, !!toolsBtns && !!toolsBtns.length && toolsBtns),
                React.createElement("ul", null,
                    React.createElement("li", null,
                        React.createElement(Dropdown, { overlay: menu, trigger: ['click'] },
                            React.createElement(Button, { icon: React.createElement(AntIcon, { type: "ColumnHeightOutlined" }) }))),
                    React.createElement("li", null,
                        React.createElement(Button, { icon: React.createElement(AntIcon, { type: "FullscreenOutlined" }) })),
                    React.createElement("li", null,
                        React.createElement(Button, { icon: React.createElement(AntIcon, { type: "ReloadOutlined" }), onClick: () => query === null || query === void 0 ? void 0 : query.refresh() })),
                    React.createElement("li", null,
                        React.createElement(Popover, { placement: "topRight", content: cellSettingContent, title: "\u5217\u5C55\u793A", trigger: "click" },
                            React.createElement(Button, { icon: React.createElement(AntIcon, { type: "SettingOutlined" }) }))))),
        editer ?
            React.createElement(Form, { form: form, style: props.className && props.className.includes('full-table') ? {
                    display: 'flex',
                    flex: '1',
                    overflow: 'hidden'
                } : {} }, table)
            : table));
});
/**
 * 兼容antd Column属性，filteredValue，filtered，sortOrder 这几个属性不会生效
 * @param param0
 */
const DataColumn = memo((_a) => {
    var { filterKey } = _a, props = __rest(_a, ["filterKey"]);
    return React.createElement(Column, Object.assign({}, props));
});
// export default memo(DataTable, (prevProps, nextProps) => {
//   return prevProps.api === nextProps.api
//     && prevProps.size === nextProps.size
//     && prevProps.query === nextProps.query
//     && prevProps.dataSource === nextProps.dataSource;
// });
export default DataTable;
export { DataColumn };
