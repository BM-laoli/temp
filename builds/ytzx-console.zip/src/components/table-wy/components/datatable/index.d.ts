import React from 'react';
import { ColumnProps } from 'antd/lib/table';
import { Query } from '../query/index';
export interface DataTableProps {
    editer?: boolean;
    noTools?: boolean;
    title?: string | React.ReactNode;
    toolsBtns?: React.ReactElement[];
    /** 加载列表数据用的api */
    api?: any;
    /** 行表单提交 */
    onRowFormSubmit?: (formData: any) => void;
    rowKeyIndex: string;
    /**
     * 自定义请求参数
     */
    formFormat?: (data: any) => any;
    /**
     * 自定义列表数据
     */
    dataFormat?: (data: any) => {
        rows: any[];
        total: number;
    };
    pagination?: any;
    /** 不需要分页器 */
    noPagination?: boolean;
    [k: string]: any;
    /** 查询条件要用的东西 */
    query?: Query;
    defaultTableSize?: 'large' | 'middle' | 'small';
}
export interface DataTableRef<T> {
    data: T;
    total: number;
}
/**
 * 兼容antd table所有属性
 * @param param0
 */
declare const DataTable: React.FC<DataTableProps>;
interface RowForm {
    getValue: (key: string) => any;
    getValues: () => any;
    setValue: (key: string, value: any) => void;
    submit: () => void;
    eidt: () => void;
    close: () => void;
}
interface ColumnsTypeProps extends ColumnProps<any> {
    /** 过滤Key */
    filterKey?: string;
    /** 排序key */
    sortKey?: string;
    formRender?: (text: any, record: any, index: number, form: RowForm, isEdit: boolean) => any;
    cellRender?: (text: any, record: any, index: number, form: RowForm, isEdit: boolean) => any;
    tooltip?: boolean;
}
/**
 * 兼容antd Column属性，filteredValue，filtered，sortOrder 这几个属性不会生效
 * @param param0
 */
declare const DataColumn: React.FC<ColumnsTypeProps>;
export default DataTable;
export { DataColumn };
