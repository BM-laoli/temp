import React from 'react';
declare const AuthRoute: React.FC<any>;
export default AuthRoute;
