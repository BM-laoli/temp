export interface Query<T = any> {
    get: () => T;
    set: (q: T, isAll?: boolean, isRefresh?: boolean) => void;
    refresh: (...props: any[]) => void;
}
export declare function useQuery<T = any>(initQuery?: T): Query<T>;
