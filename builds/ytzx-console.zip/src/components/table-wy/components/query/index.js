import useRenderRef from '../../hooks/useRenderRef';
export function useQuery(initQuery) {
    const [queryData, setQuery] = useRenderRef(initQuery || {});
    const query = {
        get() {
            return queryData.current;
        },
        set(q, isAll, isRefresh) {
            if (isRefresh) {
                q.__time = Date.now();
            }
            if (isAll) {
                setQuery(q);
            }
            else {
                let _q = Object.assign(Object.assign({}, queryData.current), q);
                setQuery(_q);
            }
        },
        refresh() {
            let q = Object.assign(Object.assign({}, queryData.current), { __time: Date.now() });
            setQuery(q);
        }
    };
    return query;
}
