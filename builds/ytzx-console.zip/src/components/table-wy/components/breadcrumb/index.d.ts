import React from 'react';
interface BreadcrumbProps {
    home?: string;
    title?: string;
    size?: 'small' | 'big';
}
declare const _default: React.NamedExoticComponent<BreadcrumbProps>;
export default _default;
