
import React, { useMemo, memo } from 'react';
import { Breadcrumb as AntBreadcrumb } from 'antd';
import { useLocation } from 'react-router-dom';
import { RouterUtil } from '@/router';
import { useHistory } from '@/utils/history/index';
const Breadcrumb = ({ title, home, children, size = 'small' }) => {
    const history = useHistory();
    const location = useLocation();
    const routeConfig = RouterUtil.getRouterConfig();
    const resources = useMemo(() => RouterUtil.makeFlattenResources(RouterUtil.getRouterConfig()), [routeConfig]);
    const itemlist = useMemo(() => {
        let lastPath = '';
        return location.pathname.split('/').filter(v => !!v).map(path => {
            lastPath += '/' + path;
            let item = resources.find((r) => r.routerUrl === lastPath);
            return item ? { url: lastPath, isClick: !!item.component, name: item.resourceName } : null;
        }).filter(v => !!v);
    }, []);
    return (React.createElement("div", null,
        React.createElement("div", { style: { display: 'flex', width: '100%' } },
            React.createElement(AntBreadcrumb, null, itemlist.map((item, index) => (item.isClick && index !== itemlist.length - 1 ?
                React.createElement(AntBreadcrumb.Item, { key: item.url },
                    React.createElement("a", { onClick: () => history.push(index === 0 && home ? home : item.url) }, index === itemlist.length - 1 && title ? title : item.name)) :
                React.createElement(AntBreadcrumb.Item, { key: item.url }, index === itemlist.length - 1 && title ? title : item.name)))),
            React.createElement("div", { style: { flex: 1 } }, children)),
        size === 'big' &&
            React.createElement("div", { style: { marginTop: '10px' } },
                React.createElement("h1", null, title ? title : itemlist[itemlist.length - 1].name))));
};
export default memo(Breadcrumb);
