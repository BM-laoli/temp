var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import React, { useState } from 'react';
import _ from 'lodash';
import { Modal as AModal } from 'antd';
import { ExclamationCircleOutlined } from '@ant-design/icons';
/**
 * 弹出层
 */
export function useFormModal() {
    const [isShow, setIsShow] = useState(false);
    const [params, setParams] = useState();
    const [query, setQurey] = useState();
    const open = (p, q) => {
        setQurey(q);
        setParams(p);
        setIsShow(true);
    };
    const close = () => {
        setQurey(undefined);
        setIsShow(false);
    };
    return {
        isShow,
        params,
        query,
        open,
        close
    };
}
/**
 * 快捷删除
 * @param form
 * @param api
 */
export const MLModal = {
    openWarningModal(title, content, form, api, query) {
        AModal.confirm({
            title,
            icon: React.createElement(ExclamationCircleOutlined, null),
            content,
            okText: '确认',
            cancelText: '取消',
            onOk: () => __awaiter(this, void 0, void 0, function* () {
                if (_.isFunction(api)) {
                    let res = yield api(form);
                    if (res === null || res === void 0 ? void 0 : res.success) {
                        // message.success({
                        //   message: '操作成功'
                        // });
                        if (_.isFunction(query)) {
                            query(res);
                        }
                        else {
                            query === null || query === void 0 ? void 0 : query.refresh();
                        }
                    }
                }
            })
        });
    },
    openDeleteModal(form, api, query) {
        AModal.confirm({
            title: '刪除',
            icon: React.createElement(ExclamationCircleOutlined, null),
            content: '确认是否删除该数据',
            okText: '确认',
            cancelText: '取消',
            onOk: () => __awaiter(this, void 0, void 0, function* () {
                if (_.isFunction(api)) {
                    let res = yield api(form);
                    if (res === null || res === void 0 ? void 0 : res.success) {
                        // notification.success({
                        //   message: '删除成功'
                        // });
                        if (_.isFunction(query)) {
                            query(res);
                        }
                        else {
                            query === null || query === void 0 ? void 0 : query.refresh();
                        }
                    }
                }
            })
        });
    }
};
