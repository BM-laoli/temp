import { Query } from '../query';
export declare namespace MLModal {
    interface FormModalComponent<T = any, Q = any> {
        /** 控制对象 */
        modal: {
            /** 是否显示 */
            isShow: boolean;
            /** 传递参数 */
            params: T;
            query?: Query<Q>;
            /** 打开弹出层 */
            open: (params?: T, query?: Query<Q>) => void;
            /** 关闭弹出层 */
            close: () => void;
        };
        query?: Query<Q>;
    }
}
/**
 * 弹出层
 */
export declare function useFormModal<T = any, Q = any>(): {
    isShow: boolean;
    params: T | undefined;
    query: Query<Q> | undefined;
    open: (p?: T | undefined, q?: Query<Q> | undefined) => void;
    close: () => void;
};
/**
 * 快捷删除
 * @param form
 * @param api
 */
export declare const MLModal: {
    openWarningModal<T = any, Q = any>(title: string, content: string, form: any, api: T, query?: Query<Q> | ((res: any) => void) | undefined): void;
    openDeleteModal<T_1 = any, Q_1 = any>(form: any, api: T_1, query?: Query<Q_1> | ((res: any) => void) | undefined): void;
};
