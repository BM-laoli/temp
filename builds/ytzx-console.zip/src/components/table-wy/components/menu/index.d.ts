/*
 * @Author: wuxu
 * @Date: 2022-06-08 17:04:25
 * @LastEditTime: 2022-06-08 17:16:17
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /tianbao-operation/src/components/table-wy/components/menu/index.d.ts
 */
import React from 'react';
import { Resources } from '@/router';
import { MenuProps as AntMenuProps } from "antd/lib/menu";
declare type onMenuEvent = () => void;
declare type EventType = 'changeHasChildren' | 'changeCurrentRoot';
interface MenuControl {
    current: {
        /** 当前选中根菜单 */
        currentRoot: string;
        /** 根菜单发生变化 */
        hasChildren: boolean;
    };
    setDefaultCurrentRoot: (currentRoot: string) => void;
    setCurrentRoot: (currentRoot: string) => void;
    setHasChildren: (hasChildren: boolean) => void;
    on: (eventType: EventType, cb: onMenuEvent) => void;
    off: (eventType: EventType, cb: onMenuEvent) => void;
    emit: (eventType: EventType) => void;
}
export declare const useMenuControl: () => MenuControl;
interface MenuProps extends AntMenuProps {
    resources?: Resources[];
    collapsed?: boolean;
    menuType?: string | number;
    autoMenu?: boolean;
    rootMenu?: boolean;
    menuControl?: MenuControl;
}
declare const _default: React.NamedExoticComponent<MenuProps>;
export default _default;
