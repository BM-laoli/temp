var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
import React, { useState, useEffect, useRef, useMemo, memo } from 'react';
import { Menu as AntMenu } from 'antd';
import { AntIcon, IconFont } from '../icon';
import { useLocation } from 'react-router-dom';
import { ResourceType, RouterUtil } from '@/router';
import _ from 'lodash';
import { useHistory } from '@/utils/history';
const { SubMenu } = AntMenu;
export const useMenuControl = () => {
    const control = useRef({
        currentRoot: '',
        hasChildren: false
    });
    const event = useRef({});
    const on = (eventType, cb) => {
        let _events = event.current[eventType] || [];
        _events.push(cb);
        event.current[eventType] = _events;
    };
    const off = (eventType, cb) => {
        let _events = event.current[eventType] || [];
        let index = _events.indexOf(cb);
        if (index > -1) {
            _events.splice(index, 1);
            event.current[eventType] = _events;
        }
    };
    const emit = (eventType) => {
        let _events = event.current[eventType];
        if (_events && _events.length) {
            _events.forEach((fnc) => fnc());
        }
    };
    return {
        on,
        off,
        emit,
        current: control.current,
        setDefaultCurrentRoot(currentRoot) {
            if (control.current.currentRoot !== currentRoot) {
                control.current.currentRoot = currentRoot;
            }
        },
        setCurrentRoot(currentRoot) {
            if (control.current.currentRoot !== currentRoot) {
                control.current.currentRoot = currentRoot;
                emit('changeCurrentRoot');
            }
        },
        setHasChildren(hasChildren) {
            let _control = Object.assign({}, control);
            if (control.current.hasChildren !== hasChildren) {
                control.current.hasChildren = hasChildren;
                emit('changeHasChildren');
            }
        },
    };
};
const Icon = ({ type }) => {
    return type ? type.includes('icon') ?
        React.createElement(IconFont, { type: type }) :
        React.createElement(AntIcon, { type: type }) :
        React.createElement(React.Fragment, null);
};
const Menu = (_a) => {
    var { resources = [], autoMenu, rootMenu, menuType, menuControl, collapsed } = _a, props = __rest(_a, ["resources", "autoMenu", "rootMenu", "menuType", "menuControl", "collapsed"]);
    const location = useLocation();
    const history = useHistory();
    const [rootMenuUrl, setRootMenuUrl] = useState("");
    useEffect(() => {
        if (autoMenu && rootMenu) {
            let key = menuControl === null || menuControl === void 0 ? void 0 : menuControl.current.currentRoot;
            if (!key) {
                let _openkeys = makeDefaultOpenKeys(_resource, location.pathname);
                key = _.last(_openkeys);
            }
            setSelectedKeys(key);
        }
        if (!autoMenu && rootMenu) {
            setSelectedKeys(location.pathname);
        }
        if (autoMenu && !rootMenu) {
            let key = menuControl === null || menuControl === void 0 ? void 0 : menuControl.current.currentRoot;
            if (!key) {
                let _openkeys = makeDefaultOpenKeys(_resource, location.pathname);
                key = _.last(_openkeys) || '';
            }
            let rootitem = flattenResources.filter(item => item.routerUrl === key)[0];
            if (rootitem && rootitem.children && rootitem.children.filter(v => v.type === '0').length) {
                menuControl === null || menuControl === void 0 ? void 0 : menuControl.setHasChildren(true);
            }
            else {
                menuControl === null || menuControl === void 0 ? void 0 : menuControl.setHasChildren(false);
            }
            setRootMenuUrl(key);
        }
        if (autoMenu && !rootMenu && menuControl) {
            menuControl.on('changeCurrentRoot', onRootMenuSelect);
        }
        return () => {
            if (menuControl) {
                menuControl.off('changeCurrentRoot', onRootMenuSelect);
            }
        };
    }, [autoMenu]);
    useEffect(() => {
        if (props.mode === 'horizontal') {
            setOpenKeys([]);
        }
    }, [props.mode]);
    const onRootMenuSelect = () => {
        if (menuControl) {
            let rootitem = flattenResources.filter(item => !item.hide && item.routerUrl === menuControl.current.currentRoot)[0];
            let selectItem = findMenuSelect(rootitem);
            history.push(selectItem.routerUrl);
            setSelectedKeys(selectItem.routerUrl);
            setRootMenuUrl(menuControl.current.currentRoot);
        }
    };
    /*菜单顺序根据后端返回的resource顺序来进行展示,不鉴权的情况下根据是否有子菜单判断*/
    let _resource = useMemo(() => {
        let _router = _.flatten(RouterUtil.getRouterConfig().filter(v => v.menuRoot).map(v => v.children ? v.children : []));
        _router = resources.length ? resources : _router;
        return resources.length
            ? [..._router] :
            [..._router].sort((a, b) => !b.children ? !a.children ? 0 : 1 : -1);
    }, [RouterUtil.getRouterConfig(), resources]);
    /*将resources树形结构展平*/
    const makeFlattenResources = (resources) => {
        let flattenResources = [];
        const flatteningResources = (resources) => {
            resources.forEach((item) => {
                flattenResources.push(item);
                if (item.children) {
                    flatteningResources(item.children);
                }
            });
        };
        flatteningResources(resources);
        return flattenResources;
    };
    let flattenResources = useMemo(() => makeFlattenResources(_resource), [_resource]);
    /*根据当前选中往父级递归设置展开菜单*/
    const makeDefaultOpenKeys = (resources, defaultSelectedKeys) => {
        let defaultOpenKeys = [];
        const filterSelected = (curKeys) => {
            let current = flattenResources.filter((item) => item.routerUrl === curKeys)[0];
            if (current && current.parentId != '-1') {
                let currentParent = flattenResources.filter((item) => item.resourceId === (current === null || current === void 0 ? void 0 : current.parentId))[0];
                if (currentParent) {
                    defaultOpenKeys.push(currentParent.routerUrl);
                    filterSelected(currentParent.routerUrl);
                }
            }
        };
        filterSelected(defaultSelectedKeys);
        return defaultOpenKeys;
    };
    /*用来判断是否为菜单渲染的值*/
    let acMenuType = menuType ? menuType : ResourceType.MENU;
    let rootMenuSelect = (item) => {
        menuControl === null || menuControl === void 0 ? void 0 : menuControl.setCurrentRoot(item.routerUrl);
        if (item.children && item.children.length) {
            menuControl === null || menuControl === void 0 ? void 0 : menuControl.setHasChildren(true);
        }
        else {
            menuControl === null || menuControl === void 0 ? void 0 : menuControl.setHasChildren(false);
        }
    };
    let findMenuSelect = (item) => {
        if (item.children && item.children.filter(v => v.type === '0' && !v.hide).length) {
            for (let c_item of item.children.filter(v => v.type === '0' && !v.hide)) {
                return findMenuSelect(c_item);
            }
        }
        else {
            return item;
        }
    };
    const transferMenu = (resources, isFirst) => {
        return resources.map((item) => {
            if (autoMenu && rootMenu && item.type === acMenuType && !item.hide) {
                return (React.createElement(AntMenu.Item, { key: item.routerUrl, icon: React.createElement(Icon, { type: item.resourceIcon }), onClick: () => history.push(item.routerUrl) }, item.resourceName));
            }
            else if (autoMenu && !rootMenu && !isFirst) {
                if (item.routerUrl === rootMenuUrl) {
                    if (item.children && item.children.length) {
                        return transferMenu(item.children, true);
                    }
                    else {
                        return null;
                    }
                }
                else {
                    return null;
                }
            }
            else if (item.children && Array.isArray(item.children) && item.children.filter(a => a.type === acMenuType).length > 0 && item.type === acMenuType && !item.hide) {
                return (React.createElement(SubMenu, { key: item.routerUrl, icon: React.createElement(Icon, { type: item.resourceIcon }), title: item.resourceName }, transferMenu(item.children, true)));
            }
            else if ((!item.children || item.children.length === 0 || item.children.filter(a => a.type === acMenuType).length === 0) && item.type === acMenuType && !item.hide) {
                return (React.createElement(AntMenu.Item, { key: item.routerUrl, icon: React.createElement(Icon, { type: item.resourceIcon }), onClick: () => history.push(item.routerUrl) }, item.resourceName));
            }
        });
    };
    const onOpenChange = cOpenKeys => {
        setOpenKeys(cOpenKeys);
        // const latestOpenKey = cOpenKeys.find(key => openKeys.indexOf(key) === -1);
        // if (flattenResources.filter((item) => item.routerUrl === latestOpenKey)
        //   .length === 0) {
        // } else {
        //   setOpenKeys(latestOpenKey ? [latestOpenKey] : [])
        // }
    };
    // const onSelect = ({key})=>{
    //   setSelectedKeys(key)
    // }
    const findKey = (key) => {
        let findlist = flattenResources.filter(a => a.routerUrl === key && a.type === acMenuType && !a.hide);
        let _p = key.split('/');
        if (findlist.length > 0) {
            return key;
        }
        else if (_p.length > 1) {
            _p.pop();
            return findKey(_p.join('/'));
        }
        else {
            return null;
        }
    };
    const findFristKey = (key) => {
        let findlist = _resource.filter(a => key.includes(a.routerUrl) && a.type === acMenuType && !a.hide);
        if (findlist.length > 0) {
            return findlist[0].routerUrl;
        }
        else {
            return null;
        }
    };
    let defaultKey = useMemo(() => autoMenu && rootMenu ? findFristKey(location.pathname) : findKey(location.pathname), []);
    let [selectedKeys, setSelectedKeys] = useState(defaultKey);
    let defaultOpenKeys = useMemo(() => makeDefaultOpenKeys(_resource, selectedKeys), []);
    defaultOpenKeys = props.mode === 'horizontal' ? [] : defaultOpenKeys;
    const [openKeys, setOpenKeys] = useState(defaultOpenKeys);
    const newProps = collapsed ? Object.assign({}, props) : Object.assign(Object.assign({}, props), { openKeys: openKeys });
    useEffect(() => {
        const _sk = autoMenu && rootMenu ? findFristKey(location.pathname) : findKey(location.pathname);
        if (_sk && _sk !== selectedKeys && autoMenu && rootMenu) {
            let findlist = _resource.filter(a => location.pathname.includes(a.routerUrl) && a.type === acMenuType && !a.hide);
            if (findlist[0]) {
                rootMenuSelect(findlist[0]);
            }
        }
        else if ((_sk !== selectedKeys || !_sk) && autoMenu && rootMenu) {
            menuControl === null || menuControl === void 0 ? void 0 : menuControl.setHasChildren(false);
        }
        setSelectedKeys(_sk);
    }, [location.pathname]);
    return (React.createElement(AntMenu, Object.assign({ mode: "inline", onOpenChange: onOpenChange, openKeys: openKeys, selectedKeys: selectedKeys ? [selectedKeys] : undefined }, newProps), transferMenu(_resource)));
};
export default memo(Menu);
