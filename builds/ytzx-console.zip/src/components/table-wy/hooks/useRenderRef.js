import { useState, useRef } from 'react';
export default function useRenderRef(init) {
    const [refState, setState] = useState(init);
    const ref = useRef(init);
    const res = {
        get current() {
            return ref.current;
        }
    };
    const change = (data) => {
        ref.current = data;
        setState(data);
    };
    return [res, change];
}
