import React, { useMemo } from 'react';
import { Select, SelectProps } from 'antd';
import { observer } from 'mobx-react-lite';
import { useStore } from '@/models';

interface OilSelectProps extends Omit<SelectProps<any>, 'options' | 'children'> {}

const OilSelect: React.FC<OilSelectProps> = observer((props) => {
  const { global } = useStore();
  const options = useMemo(() => global.oils.map((v) => ({ label: v.petrolName || '', value: v.id ?? '' })), [global.oils]);
  return <Select {...props} options={options} />;
});

export default OilSelect;
