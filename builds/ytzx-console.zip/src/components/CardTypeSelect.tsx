import React, { useMemo } from 'react';
import { Select, SelectProps } from 'antd';
import { observer } from 'mobx-react-lite';
import { useStore } from '@/models';

interface CardTypeSelectProps extends Omit<SelectProps<any>, 'options' | 'children'> {}

const CardTypeSelect: React.FC<CardTypeSelectProps> = observer((props) => {
  const { global } = useStore();
  const options = useMemo(() => global.cardTypes.map((v) => ({ label: v.desc || '', value: Number(v.code) ?? '' })), [global.cardTypes]);
  return <Select {...props} options={options} />;
});

export default CardTypeSelect;
