import React, { useCallback, useMemo, useReducer, useRef, useState } from 'react';
import AMapLoader from '@amap/amap-jsapi-loader';
import { Input, InputProps, Modal, Space, Typography, AutoComplete, Form } from 'antd';
import { AimOutlined } from '@ant-design/icons';
import config from '@/config';
import _ from 'lodash';

export interface FormMapAddressProps extends Omit<InputProps, 'value' | 'onChange'> {
  /** 值：地址 */
  value?: string;
  /** 地图宽度 */
  width?: number;
  /** 地图高度 */
  height?: number;
  /** Change 事件 */
  onChange?: (address?: string, point?: any) => void;
  pointValue?: {
    lng?: number;
    lat?: number;
  };
}

declare type AutoCompleteOption = {
  label: string;
  value: string;
};

declare type DataType = {
  address?: string;
  point?: any;
};

/** 地图选择地址FormItem组件 */
const FormMapAddress: React.FC<FormMapAddressProps> = ({ value, pointValue, width = 760, height = 400, onChange, ...props }) => {
  const [form] = Form.useForm();

  const mapRef = useRef<any>();
  const geocoderRef = useRef<any>();
  const autoCompleteRef = useRef<any>();
  const centerRef = useRef<any>();
  const markerRef = useRef<any>();

  const mapElement = useRef<HTMLDivElement>(null);

  const [inputValue, setInputValue] = useState(value);
  const [visible, setVisible] = useState(false);
  const [{ address, point }, dispatchData] = useReducer((state: DataType, news: DataType) => ({ ...state, ...news }), {});

  const [autoDataSource, setAutoDataSource] = useState<any[]>([]);
  const autoOptions = useMemo<Array<AutoCompleteOption>>(() => autoDataSource.map((v) => ({ label: `${v.name} - ${v.district}`, value: `${v.name} - ${v.district}`, ...v })), [autoDataSource]);

  React.useEffect(() => {
    initMap();
    return () => {
      geocoderRef.current = null;
      autoCompleteRef.current = null;
      centerRef.current = null;
      markerRef.current = null;
      mapRef.current?.destroy();
    };
  }, []);

  React.useEffect(() => {
    setInputValue(value);
  }, [value]);

  /** 初始化地图 */
  const initMap = useCallback(() => {
    AMapLoader.load({
      key: config.AMAP_KEY,
      version: '2.0',
      plugins: ['AMap.Geocoder', 'AMap.AutoComplete'],
    }).then((AMap) => {
      mapRef.current = new AMap.Map(mapElement.current, { zoom: 11 });
      centerRef.current = mapRef.current?.getCenter();
      geocoderRef.current = new AMap.Geocoder();
      autoCompleteRef.current = new AMap.AutoComplete();
      regisMapEvent();
    });
  }, []);

  /** 注册地图事件 */
  const regisMapEvent = useCallback(() => {
    mapRef.current?.on('click', (e: any) => {
      setPoint(e.lnglat);
    });
  }, []);

  const setPoint = (lnglat: any) => {
    setMerker(lnglat);

    /** 地图选点的经纬度转为地址 */
    geocoderRef.current?.getAddress(lnglat, (_status: string, result: any) => {
      const address = result?.regeocode?.formattedAddress;
      const point = result?.regeocode?.addressComponent;
      dispatchData({ address, point });
    });
  };

  /** 设置marker */
  const setMerker = useCallback((lnglat: any) => {
    if (markerRef.current) {
      markerRef.current?.setPosition(lnglat);
    } else {
      markerRef.current = new AMap.Marker({ position: lnglat });
      mapRef.current?.add(markerRef.current);
    }
  }, []);

  /** 自动补全搜索 */
  const handleAutoSearch = useCallback(
    _.debounce((keyword: string) => {
      if (!keyword) return setAutoDataSource([]);
      autoCompleteRef.current?.search(keyword, (_status: any, result: any) => {
        const tips = result?.tips || [];
        setAutoDataSource(tips);
      });
    }, 300),
    []
  );

  /** 自动补全选择 */
  const handleAutoSelect = useCallback((_value: string, option: any) => {
    if (option) {
      const center = [option.location?.lng, option.location?.lat];
      mapRef.current?.setZoomAndCenter(15, center);

      const lnglat = new AMap.LngLat(option.location?.lng, option.location?.lat);
      setPoint(lnglat);
    }
  }, []);

  /** 显示地图弹窗 */
  const handleShowMapModal = useCallback(() => {
    if (props.disabled || props.readOnly) return;
    setVisible(true);
    dispatchData({ address: inputValue });
    // if (inputValue) {
    //   geocoderRef.current?.getLocation(inputValue, (_status: any, result: any) => {
    //     const geocodes = result?.geocodes || [];
    //     const point = _.first(geocodes) as any;
    //     if (point && point.location) {
    //       setMerker(point.location);
    //       mapRef.current?.setCenter(point.location);
    //     }
    //   });
    // } else {
    //   if (markerRef.current) {
    //     mapRef.current?.remove(markerRef.current);
    //     markerRef.current = null;
    //   }
    // }
    if (pointValue && pointValue.lat && pointValue.lng) {
      const p = new AMap.LngLat(pointValue.lng, pointValue.lat);
      setMerker(p);
      mapRef.current?.setCenter(p);
    } else {
      mapRef.current?.remove(markerRef.current);
      markerRef.current = null;
    }
  }, [inputValue, pointValue, props.disabled, props.readOnly]);

  /** 确定选择地址 */
  const handleAddressOk = useCallback(() => {
    setInputValue(address);
    const p = markerRef.current?.getPosition();
    onChange?.(address, { ...point, ...p });
    setVisible(false);
  }, [address]);

  /** Input Change */
  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const v = e.currentTarget.value;
      setInputValue(v);
      onChange?.(v);
    },
    [onChange]
  );

  /** 清理 */
  const clearModal = useCallback(() => {
    dispatchData({ address: undefined, point: undefined });
    setAutoDataSource([]);
    form.resetFields();
  }, []);

  return (
    <>
      <Input autoComplete={'off'} {...props} suffix={<AimOutlined />} value={inputValue} onChange={handleInputChange} onClick={handleShowMapModal} />

      <Modal
        title="选择地址"
        visible={visible}
        width={width}
        bodyStyle={{ padding: '10px 16px' }}
        okButtonProps={{ disabled: !address }}
        onOk={handleAddressOk}
        onCancel={() => setVisible(false)}
        afterClose={clearModal}
        forceRender
      >
        <Space direction="vertical" style={{ width: '100%' }}>
          <Form form={form}>
            <Form.Item name="keywords" noStyle>
              <AutoComplete options={autoOptions} onSearch={handleAutoSearch} onSelect={handleAutoSelect} placeholder="搜索地址" allowClear style={{ width: '100%' }} />
            </Form.Item>
          </Form>
          <div style={{ height: height }}>
            <div ref={mapElement} style={{ width: '100%', height: '100%' }}></div>
          </div>
          <Typography.Text>选择的地址：{address}</Typography.Text>
        </Space>
      </Modal>
    </>
  );
};

export default FormMapAddress;
