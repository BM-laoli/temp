import React, { useMemo } from 'react';
import { Upload, message, Modal, Image, Space, Button } from 'antd';
import { RcFile } from 'antd/lib/upload';
import { UploadFile } from 'antd/lib/upload/interface';
import config from '@/config';
import { UploadOutlined } from '@ant-design/icons';
import models from '@/models';
import _ from 'lodash';

export declare type ResourceFile = {
  /** 资源id */
  resourceId: string;
  /** 资源地址 */
  fileUrl: string;
};

interface FormUploadFileProps {
  /** 上传服务器地址 */
  action?: string;
  /** 单张文件大小，单位M，默认100 */
  size?: number;
  /** 最大文件数量 */
  max?: number;
  /** 默认文件 */
  value?: Array<ResourceFile>;
  /** change回调 */
  onChange?: (v: Array<ResourceFile>) => void;
  /** 是否禁用 */
  disabled?: boolean;
}

const FormUploadFile: React.FC<FormUploadFileProps> = ({ action = '/upload/uploadFile', size = 100, max = 1, value = [], disabled = false, onChange }) => {
  /** 请求头授权 */
  const headers = useMemo(
    () => ({
      access_token: models.global.user?.loginToken || '',
    }),
    [models.global.user?.loginToken]
  );
  const [imgFiles, setImgFiles] = React.useState<any[]>([]);
  const actionUrl = useMemo(() => config.API_HOST + action, [action]);

  React.useEffect(() => {
    if (value.length > 0) {
      const imgs = value.map((v) => ({
        uid: v.resourceId,
        url: v.fileUrl,
        status: 'done',
        name: v.fileUrl ? _.last(v.fileUrl.split('/')) : '',
      }));
      setImgFiles(imgs);
    }
  }, [value]);

  /** 移除错误文件 */
  const removeErrorFile = (file: RcFile, fileList: Array<RcFile>) => {
    const index = fileList.findIndex((v) => v.uid === file.uid);
    fileList.splice(index, 1);
  };

  /** 上传之前，检查文件 */
  const handleBeforeUpload = (file: RcFile, fileList: Array<RcFile>) => {
    if (!(file.size / 1024 / 1024 <= size)) {
      removeErrorFile(file, fileList);
      message.error(`文件必须小于${size}MB!`);
      return false;
    }
    if (fileList.length + imgFiles.length > max) {
      const newlist = _.take(fileList, max - imgFiles.length);
      const has = newlist.some((v) => v.uid === file.uid);
      if (!has) removeErrorFile(file, fileList);
      return has;
    }
    return true;
  };

  /**
   * 通用上传文件
   * @param param0 Upload组件的参数对象
   * @param callback 回调
   */
  const handleUploadChange = ({ fileList }) => {
    const list: Array<UploadFile<RcFile>> = fileList
      .filter((v: UploadFile<RcFile>) => v.status)
      .map((v: any) => ({
        ...v,
        ...(v.response?.data ? { uid: v.response.data?.fileId, url: v.response.data?.httpUrl } : {}),
      }));
    setImgFiles(list);

    if (onChange && list.every((v: UploadFile<RcFile>) => v.status === 'done')) {
      const v: Array<ResourceFile> = list.map((v: UploadFile<RcFile>) => ({ resourceId: v.uid, fileUrl: v.url || '' }));
      onChange(v);
    }
  };

  return (
    <Upload action={actionUrl} beforeUpload={handleBeforeUpload} headers={headers} fileList={imgFiles} onChange={handleUploadChange} multiple={max > 1} disabled={disabled}>
      <Button icon={<UploadOutlined />}>上传文件</Button>
    </Upload>
  );
};

export default FormUploadFile;
