import React, { useMemo } from 'react';
import { Upload, message, Modal, Image, Space } from 'antd';
import { RcFile } from 'antd/lib/upload';
import { UploadFile } from 'antd/lib/upload/interface';
import config from '@/config';
import { PlusOutlined } from '@ant-design/icons';
import models from '@/models';
import ImgCrop, { ImgCropProps } from 'antd-img-crop';
import _ from 'lodash';

export declare type ResourceFile = {
  /** 资源id */
  resourceId: string;
  /** 资源地址 */
  fileUrl: string;
};

interface UploadImageProps {
  /** 上传服务器地址 */
  action?: string;
  /** 单张图片大小，单位M，默认5 */
  size?: number;
  /** 最大图片数量 */
  max?: number;
  /** 默认图片 */
  value?: Array<ResourceFile>;
  /** change回调 */
  onChange?: (v: Array<ResourceFile>) => void;
  /** 是否禁用 */
  disabled?: boolean;
  /** 是否开启裁剪 */
  crop?: boolean;
  /** 图片裁剪选项 */
  cropOptions?: ImgCropProps;
}

const FormUploadImage: React.FC<UploadImageProps> = ({ action = '/upload/uploadFile', size = 5, max = 9, value = [], crop = false, disabled = false, cropOptions, onChange }) => {
  /** 请求头授权 */
  const headers = useMemo(
    () => ({
      access_token: models.global.user?.loginToken || '',
    }),
    [models.global.user?.loginToken]
  );
  const [imgFiles, setImgFiles] = React.useState<any[]>([]);
  const [preview, setPreview] = React.useState<any>(null);
  const actionUrl = useMemo(() => config.API_HOST + action, [action]);
  const cropProps = useMemo<ImgCropProps>(() => ({ aspect: 4 / 3, modalWidth: 800, rotate: true, ...cropOptions }), [cropOptions]);

  React.useEffect(() => {
    if (value.length > 0) {
      const imgs = value.map((v) => ({
        uid: v.resourceId,
        url: v.fileUrl,
        status: 'done',
        name: v.resourceId ? _.last(v.resourceId.split('/')) : '',
      }));      
      setImgFiles(imgs);
    }
  }, [value]);

  /** 移除错误文件 */
  const removeErrorFile = (file: RcFile, fileList: Array<RcFile>) => {
    const index = fileList.findIndex((v) => v.uid === file.uid);
    fileList.splice(index, 1);
  };

  /** 上传之前，检查图片 */
  const handleBeforeUpload = (file: RcFile, fileList: Array<RcFile>) => {
    if (!(file.type === 'image/jpeg' || file.type === 'image/png')) {
      removeErrorFile(file, fileList);
      message.error('只能上传JPG/PNG图片');
      return false;
    }
    if (!(file.size / 1024 / 1024 <= size)) {
      removeErrorFile(file, fileList);
      message.error(`文件必须小于${size}MB!`);
      return false;
    }
    if (fileList.length + imgFiles.length > max) {
      const newlist = _.take(fileList, max - imgFiles.length);
      const has = newlist.some((v) => v.uid === file.uid);
      if (!has) removeErrorFile(file, fileList);
      return has;
    }
    return true;
  };

  /**
   * 通用上传文件
   * @param param0 Upload组件的参数对象
   * @param callback 回调
   */
  const handleUploadChange = ({ fileList }) => {
    const list: Array<UploadFile<RcFile>> = fileList
      .filter((v: UploadFile<RcFile>) => v.status)
      .map((v: any) => ({
        ...v,
        ...(v.response?.data ? { uid: v.response.data?.fileId, url: v.response.data?.httpUrl } : {}),
      }));
    setImgFiles(list);      
    if (onChange && list.every((v: UploadFile<RcFile>) => v.status === 'done')) {
      const v: Array<ResourceFile> = list.map((v: UploadFile<RcFile>) => ({ resourceId: v.uid, fileUrl: v.url || '', fileName: v.name }));
      onChange(v);
    }
  };

  /** 预览图片 */
  const handlePreviewImage = (file: UploadFile<RcFile>) => {
    if (file.status === 'done') {
      setPreview(file);
    }
  };

  return (
    <>
      {disabled ? (
        <Image.PreviewGroup>
          <Space>
            {imgFiles.map((v, i) => (
              <Image width={100} height={100} src={v.url} key={`images-${v.uid}-${i}`} />
            ))}
          </Space>
        </Image.PreviewGroup>
      ) : (
        <>
          {crop ? (
            <ImgCrop {...cropProps}>
              <Upload
                action={actionUrl}
                listType="picture-card"
                accept="image/png,image/jpeg"
                beforeUpload={handleBeforeUpload}
                headers={headers}
                fileList={imgFiles}
                onChange={handleUploadChange}
                onPreview={handlePreviewImage}
                multiple={max > 1}
              >
                {imgFiles.length < max && (
                  <div>
                    <PlusOutlined />
                    <div style={{ marginTop: 8 }}>上传图片</div>
                  </div>
                )}
              </Upload>
            </ImgCrop>
          ) : (
            <Upload
              action={actionUrl}
              listType="picture-card"
              accept="image/png,image/jpeg"
              beforeUpload={handleBeforeUpload}
              headers={headers}
              fileList={imgFiles}
              onChange={handleUploadChange}
              onPreview={handlePreviewImage}
              multiple={max > 1}
            >
              {imgFiles.length < max && (
                <div>
                  <PlusOutlined />
                  <div style={{ marginTop: 8 }}>上传图片</div>
                </div>
              )}
            </Upload>
          )}
        </>
      )}

      <Modal visible={!!preview} title="查看图片" footer={null} onCancel={() => setPreview(null)}>
        <img src={preview?.url} alt={preview?.name} style={{ width: '100%' }} />
      </Modal>
    </>
  );
};

export default FormUploadImage;
