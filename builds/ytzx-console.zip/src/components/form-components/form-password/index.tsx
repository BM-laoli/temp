import React, { useCallback } from 'react';
import { Button, Input, Space } from 'antd';
import { PasswordProps } from 'antd/lib/input';

export interface FormPasswordProps extends Omit<PasswordProps, 'value' | 'onChange'> {
  /** Input 值 */
  value?: string;
  /** 默认密码 */
  defaultPassword?: string;
  /** Input Change 事件 */
  onChange?: (v?: string) => void;
}

/** FormItem密码组件（包含重置密码按钮） */
const FormPassword: React.FC<FormPasswordProps> = ({ value, defaultPassword = '888888', onChange, ...props }) => {
  React.useEffect(() => {
    onChange?.(defaultPassword);
  }, []);

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      onChange?.(e.currentTarget.value);
    },
    [onChange]
  );

  const handleReset = useCallback(() => {
    onChange?.(defaultPassword);
  }, [defaultPassword, onChange]);

  return (
    <Space>
      <Input.Password {...props} value={value || defaultPassword} visibilityToggle onChange={handleChange} />
      <Button children="重置密码" size={props.size} onClick={handleReset} />
    </Space>
  );
};

export default FormPassword;
