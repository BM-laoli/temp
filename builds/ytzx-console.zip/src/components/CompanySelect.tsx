import React, { useEffect, useState, memo } from "react";
import * as Api from "@/api";
import { Select, SelectProps } from 'antd'
import { observer } from 'mobx-react-lite'
import { useStore } from '@/models'

const Option = Select.Option;

interface BaseSelectProps extends SelectProps<any> {
  filterData?:defs.SysDeptEntityObject[]
  valueFormat?: (item: defs.SysDeptEntityObject) => string
}
/**
 * 信用卡银行选择器
 */
const CompanySelect: React.FC<BaseSelectProps> = ({ filterData, valueFormat, ...props }) => {
  const { global } = useStore()
  const [data, setData] = useState<defs.SysDeptEntityObject[]>([]);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    let res = await API.sysOrg.selectOrgList.request();
    if (res.success && res.data) {
      let names = filterData?.map(v=>v.orgId)||[];
      setData(res.data.filter(v=>!names.includes(v.orgId)));
    }
  }

  return (
    <Select
      placeholder={'请选择公司'}
      style={{ width: '100%' }}
      showSearch
      allowClear
      filterOption={(input, option) =>
        option?.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
      }
      {...props}>
      {data.map(v => {
        return (
          <Option key={v.orgId} value={valueFormat ? valueFormat(v) : v.orgId||'' }>{v.orgName}</Option>
        )
      })}
    </Select>
  )
}

export default CompanySelect;