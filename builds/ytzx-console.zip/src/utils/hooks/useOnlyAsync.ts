import { useRef } from 'react';

export default function useOnlyAsync<T extends Function>(fn: T): T {
  const isActive = useRef(false);
  const refn: any = async (...props: any) => {
    if (isActive.current) return;
    isActive.current = true;
    try {
      await fn(...props);
    } catch (error) {
    } finally {
      isActive.current = false;
    }
  };
  return refn;
}
