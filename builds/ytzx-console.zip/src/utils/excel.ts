// import ExcelJS from 'exceljs'

interface ExcelData {
  header: Array<{ header: string; key: string }>;
  data: Array<{ [key: string]: any }>;
}

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

export default {
  /** 导出数据到excel */
  export(excelData: ExcelData) {
    // const workbook = new ExcelJS.Workbook()
    // const sheet = workbook.addWorksheet('导出数据')
    // sheet.columns = excelData.header
    // sheet.addRows(excelData.data)
    // workbook.xlsx.writeBuffer().then((buffer) => {
    //   const blob = new Blob([buffer], { type: EXCEL_TYPE })
    //   const a = document.createElement('a')
    //   const url = URL.createObjectURL(blob)
    //   a.href = url
    //   a.download = new Date().getTime() + EXCEL_EXTENSION
    //   a.click()
    //   URL.revokeObjectURL(url)
    // })
  },

  downloadExcel(data: Blob, fileName?: string) {
    const file = [fileName, new Date().getTime()].filter((v) => !!v).join('_');
    const a = document.createElement('a');
    const url = URL.createObjectURL(data);
    a.href = url;
    a.download = file + EXCEL_EXTENSION;
    a.click();
    URL.revokeObjectURL(url);
  },
};
