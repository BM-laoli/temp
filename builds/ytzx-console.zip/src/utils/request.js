import axios from 'axios'
import config from '@/config'
import _ from 'lodash'
import models from '@/models'
import { message } from 'antd';
import { history } from '@cyber-ccx/lib';


const request = (options = {}) => {
  options.headers = {

  }

  if (models.global.user?.loginToken) {
    options.headers['access_token'] = models.global.user?.loginToken;
  }

  return axios(options)
    .then(checkStatus)
    .then(parseJSON)
    .then(business)
    .then(res => {
      return res;
    })
    .then(checkDataSta).catch(data => {
      console.error(data);
      return { sta: 300, msg: '网络异常' };
    })
}

function parseJSON(response) {
  return response.data;
}


function checkStatus(response) {

  if (response.status >= 200 && response.status < 300) {
    return response;
  }
  const error = new Error(response.statusText);
  error.response = response;
  throw error;
}

function business(response) {
  if (response.head && response.head.code === 0) {
    throw response.head.msg;
  } else {
    return response;
  }
}

function checkDataSta(res) {
  res.success = res.resultStatus === 200;
  if (!res.success) {
    if (res.resultStatus === 403) {
      history.replace('/login');
    } else {
      message.error(res.msg);
    }
  }
  return res;
}

const post = (url, data = {}) => {
  let h = config.API_HOST;

  return request({
    method: 'POST',
    url: h + url,
    credentials: "include",
    timeout: 20 * 1000,
    data
  })
}

const get = (url, data) => {
  let h = config.API_HOST;
  if (data) {
    url += '?' + serialization(data);
  }
  return request({
    method: 'GET',
    url: h + url,
    headers: { 'authorization': base.user.token },
    timeout: 180 * 1000,
    credentials: "include"
  })
}

const serialization = (form, isRemove = true) => {
  let res = [];
  _.forIn(form, (v, k) => {
    if (isRemove) {
      if (v) {
        res.push(`${k}=${v}`);
      }
    } else {
      res.push(`${k}=${v === undefined || v === null ? '' : v}`);
    }
  });
  return res.join('&');
}

const upload = (file) => {
  const formData = new FormData();
  formData.append('file', file);
  return post('/upload/uploadFile', formData);
}

const uploadUrl = async (file) => {
  const res = await upload(file);
  if (res.success && res.data) {
    return res.data.httpUrl;
  } else {
    return "";
  }
}

const downExcel = (url, data) => {
  const downloadElement = document.createElement('a')  // 创建下载的链接
  downloadElement.href = config.API_HOST;
  downloadElement.download = `${moment().format('YYYYMMDDHHmmss')}.xls`  // 下载后的文件名
  downloadElement.style.display = "none";
  downloadElement.target = "_blank";
  document.body.appendChild(downloadElement)
  downloadElement.click() // 下载
  document.body.removeChild(downloadElement) // 下载完成 移除 a
}


export default request;
export { post, get, upload, uploadUrl, downExcel };



export const requestUpload = (options = {}) => {
  options.headers = {

  }

  if (models.global.user?.loginToken) {
    options.headers['access_token'] = models.global.user?.loginToken;
  }

  return axios({...options, responseType: 'blob' })
    .then(checkStatus)
    .then(parseJSON)
    .then(res => {
      return res;
    }).catch(data => {
      return { sta: 300, msg: '网络异常' };
    })
}
