/*
 * @Author: TigerLord
 * @Date: 2022-10-08 13:55:44
 * @LastEditTime: 2023-01-13 10:04:52
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/utils/rules.ts
 */
import _ from 'lodash';
import { Rule } from 'rc-field-form/lib/interface';

const validate: { [k: string]: Rule } = {
  required: { required: true },
  requiredNumber: {  required: true },
  // (-|\+)?
  number: { pattern: /^\d+(\.\d{1,2})?$/, message: '请输入正确的数字,可保留两位小数' },
  integer: { pattern: /^\d+$/, message: '请输入正确的整数' },
  email: { type: 'email' },
  phone: { pattern: /^1(3\d|4[5-9]|5[0-35-9]|6[2567]|7[0-8]|8\d|9[0-35-9])\d{8}$/, message: '请输入正确格式的手机号'},
  priceTwo:{pattern:/^(([1-9]{1}\d*)|(0{1}))(\.\d{1,2})?$/,message:'请输入正确的金额，可保留两位'}
};

type ruleType = 'required'|'priceTwo' | 'requiredNumber' | 'number' | 'integer' | 'email' | 'phone' | RegExp | Rule;

const Rules = (...rules: ruleType[]) => {
  let isRequired = false;
  const res = rules.map((v) => {
    if (_.isString(v)) {
      if (v === 'required') {
        isRequired = true;
      }
      return validate[v];
    } else if (_.isRegExp(v)) {
      return { pattern: v, message: `请输入正确的格式` };
    } else {
      return v;
    }
  });
  const required = isRequired
    ? {
      className: 'required',
      required: true,
    }
    : {};
  return {
    ...required,
    rules: res,
  };
};

export default Rules;
