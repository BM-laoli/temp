export const mobileRegExp = /^1[0-9]{10}$/
export const telephoneRegExp = /\d{3}-\d{8}|\d{4}-\d{7}/
export const idcardRegExp = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/
