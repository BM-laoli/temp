interface OSSConfig {
    region: string;
    accessKeyId: string;
    accessKeySecret: string;
    bucket: string;
}
declare const _default: {
    /**
     * 初始化oss设置
     * @param config
     */
    init(config: OSSConfig): void;
    /**
     * 上传文件
     * @param path
     * @param file
     */
    upload(path: string, file: File | Blob): any;
};
export default _default;
