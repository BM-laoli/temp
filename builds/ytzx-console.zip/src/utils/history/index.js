import { createBrowserHistory } from 'history';
import { useHistory as useRootHistory } from 'react-router-dom';
import _ from 'lodash';
let history = null;
let init = (basename = '') => {
    if (!history) {
        history = createBrowserHistory({ basename });
        Object.assign(aghistory, history);
    }
};
/**
 * 得到url的参数
 */
const getQuery = () => {
    let res = {};
    let search = history.location.search.split('?')[1];
    search = search ? search.split('&') : [];
    search.forEach((v) => {
        let value = v.split('=');
        if (value[0] === '_ref_temp_time_')
            return;
        res[value[0]] = decodeURI(value[1]);
    });
    return res;
};
/**
 * 增量设置url的参数，如果参数和当前参数一致不会触发设置
 * @param data
 * @param isRef 是否强制刷新，查询条件不变也会触发刷新
 * @param isRemove 是否删除空值字段
 */
const setQuery = (data, isRef = false, isRemove) => {
    let query = getQuery();
    let search = '';
    if (isRef) {
        search = `?${serialization(data)}&_ref_temp_time_=${Date.now()}`;
    }
    else {
        search = `?${serialization(Object.assign(Object.assign({}, query), data))}`;
    }
    if (search !== history.location.search) {
        history.replace(`${history.location.pathname}${search}`);
    }
};
/**
 * 专用于刷新table，清除查询条件，只保留每页条数，重置页码到1页
 */
const refTable = () => {
    let query = getQuery();
    let data = {};
    if (query.rows) {
        data.page = 1;
        data.rows = query.rows;
    }
    setQuery(data, true);
};
const serialization = (form, isRemove = true) => {
    let res = [];
    _.forIn(form, (v, k) => {
        if (isRemove) {
            if (v !== undefined && v !== null) {
                res.push(`${k}=${v}`);
            }
        }
        else {
            res.push(`${k}=${v === undefined || v === null ? '' : v}`);
        }
    });
    return res.join('&');
};
const aghistory = Object.assign(Object.assign({}, history), { refTable,
    getQuery,
    setQuery,
    serialization });
export default aghistory;
export { init };
export const useHistory = () => useRootHistory();
