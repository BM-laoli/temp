declare class LocalStorage {
    /** 设置键值，该方法是异步 */
    static set(k: string, v: any): void;
    /** 获取值，该方法是异步 */
    static get(k: string): any;
    static remove(k: string): void;
}
export default LocalStorage;
