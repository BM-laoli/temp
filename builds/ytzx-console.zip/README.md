
<!-- 分页查询 必须改node—modules 配置文件 查询分页才能重置-->
searchform
const search = (values) => {
    queryData.page = 1 // 查询数据必须重置
    query.set(values);
};