import { observable, computed, action, makeObservable } from 'mobx';
import PageConfig from '@/theme/PageConfig';
import { LocalStorage } from '@cyber-ccx/lib';
import _ from 'lodash';
import config from '../config';

export class GlobalModel {
  constructor() {
    makeObservable(this);
  }
  /**
   * 是否登录
   */
  @observable isLogin = true;
  /**
   * 加载中计数器
   */
  @observable _loadingNum = 0;

  @observable user: defs.TheLoginInformation = LocalStorage.get('user');

  @observable
  userInfo: any;
  /**
   * 页面配置信息
   */
  @observable pageConfig: PageConfig = _.assign(new PageConfig(), LocalStorage.get('pageConfig'));

  /** 油品 */
  @observable oils: defs.Oil[] = [];
  /** 加油撬油品 */
  @observable qiaoOils: defs.Oil[] = [];
  /** 油卡类型 */
  @observable cardTypes: defs.EnumVo[] = [];

  @action.bound
  changePageConfig(config: PageConfig) {
    this.pageConfig = config;
    LocalStorage.set('pageConfig', config);
  }

  /**
   * 全局是否加载中
   */
  @computed get loading() {
    return this._loadingNum !== 0;
  }

  /**
   * 登陆完成
   */
  @action.bound
  login(user: any) {
    this.user = user;
    LocalStorage.set('user', user);
  }

  @observable menus:defs.SysMenuEntityObject[] = LocalStorage.get('menus')||[];
  async loadMenu(){
    const res = await API.sysUser.nav.request();
    if(res.success){
      this.menus = res.data||[];
      LocalStorage.set('menus', res.data);
    }
  }

  /** 加载油品 */
  @action.bound
  async loadOils() {
    const res: API.dictionary.findPetrolList.Response = await API.dictionary.findPetrolList.request();
    if (res.success) {
      this.oils = res.data || [];
    }
  }

  /** 加载加油撬油品 */
  @action.bound
  async loadQiaoOilds() {
    const res = await API.dictionary.findDevicePetrolList.request();
    if (res.success) {
      this.qiaoOils = res.data || [];
    }
  }

  /** 加载油卡类型 */
  @action.bound
  async loadCardTypes() {
    const res: API.dictionary.findResPetrolCardTypeEnumList.Response = await API.dictionary.findResPetrolCardTypeEnumList.request();
    if (res.success) {
      this.cardTypes = res.data || [];
    }
  }

  @action.bound
  async loadUser() {
    const res = await API.sysLogin.findUserByToken.request();
    if (res.success) {
      this.userInfo = res.data;
    }
  }
  /**
   * 登出
   */
  @action.bound
  logout() {
    this.isLogin = false;
  }
}

export default new GlobalModel();
