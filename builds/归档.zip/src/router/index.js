import React from 'react';
import { Route, Switch, Redirect, Router } from 'react-router-dom';
import AuthRoute from '@/components/table-wy/components/auth/AuthRoute';
import history, { init as HistoryInit } from '@/utils/history';
import _ from 'lodash';
const createRouter = ({ routerJson, notFound, root, onBeforeRouterRender }) => {
    return _.flatten(routerJson.map((config, index) => {
        const { routerUrl, noparent, component: Component = (props) => React.createElement(React.Fragment, null, props.children), needLogin, children } = config;
        if (children && children.length && !noparent) {
            return React.createElement(AuthRoute, { key: routerUrl + index, path: routerUrl, onBeforeRouterRender: onBeforeRouterRender, config: config, render: (props) => (React.createElement(Component, Object.assign({}, props),
                    React.createElement(RouterConfig, { routerJson: children, onBeforeRouterRender: onBeforeRouterRender }))) });
        }
        else if (children && children.length && noparent) {
            return ([React.createElement(AuthRoute, { key: routerUrl + index, path: routerUrl, onBeforeRouterRender: onBeforeRouterRender, config: config, exact: true, component: Component }), ...createRouter({ routerJson: children, onBeforeRouterRender })]);
        }
        else {
            return React.createElement(AuthRoute, { key: routerUrl + index, path: routerUrl, onBeforeRouterRender: onBeforeRouterRender, config: config, component: Component });
        }
    }));
};
/**
 * 配置Router的公共方法
 * @param param0
 */
export const RouterConfig = ({ routerJson, notFound, root, onBeforeRouterRender }) => {
    return (React.createElement(Switch, null,
        root && React.createElement(Redirect, { exact: true, from: '/', to: root }),
        createRouter({ routerJson, notFound, root, onBeforeRouterRender }),
        notFound &&
            React.createElement(Route, null, notFound)));
};
export const BrowserRouter = (props) => {
    HistoryInit(props.basename);
    return (React.createElement(Router, { history: history, children: props.children, basename: props.basename }));
};
export var ResourceType;
(function (ResourceType) {
    /**
     * 会显示在左侧里面
     */
    ResourceType["MENU"] = "0";
    /**
     * 路由但是不会显示在左侧菜单
     */
    ResourceType["ROUTE"] = "2";
    /**
     * 按钮
     */
    ResourceType["BUTTON"] = "1";
})(ResourceType || (ResourceType = {}));
let _rootConfig = [];
export const RouterUtil = {
    getRouterConfig: () => _rootConfig,
    deepFlatten: (configs, path = '', parentId) => {
        return _.flatten(configs).map(v => {
            v.routerUrl = path + v.routerUrl;
            v.resourceId = v.routerUrl;
            if (parentId) {
                v.parentId = parentId;
            }
            if (v.children) {
                v.children = RouterUtil.deepFlatten(v.children, v.routerUrl, v.resourceId);
            }
            return v;
        });
    },
    /**将resources树形结构展平**/
    makeFlattenResources: (resources) => {
        let flattenResources = [];
        const flatteningResources = (resources) => {
            resources.forEach((item) => {
                flattenResources.push(item);
                if (item.children) {
                    flatteningResources(item.children);
                }
            });
        };
        flatteningResources(resources);
        return flattenResources;
    },
    createConfig: (configs, path = '') => {
        _rootConfig = RouterUtil.deepFlatten(configs, path);
        return _rootConfig;
    }
};
