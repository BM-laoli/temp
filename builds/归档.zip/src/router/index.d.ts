import React from 'react';
interface RouterConfigType {
    /** 默认地址 */
    root?: string;
    routerJson: Resources[];
    notFound?: any;
    onBeforeRouterRender?: (router: Resources) => boolean | React.ReactNode;
}
/**
 * 配置Router的公共方法
 * @param param0
 */
export declare const RouterConfig: React.FC<RouterConfigType>;
export declare const BrowserRouter: React.FC<any>;
export declare enum ResourceType {
    /**
     * 会显示在左侧里面
     */
    MENU = "0",
    /**
     * 路由但是不会显示在左侧菜单
     */
    ROUTE = "2",
    /**
     * 按钮
     */
    BUTTON = "1"
}
export interface Resources {
    needLogin?: boolean;
    menuRoot?: boolean;
    resourceId?: string;
    hide?: boolean;
    type?: ResourceType | string;
    parentId?: string;
    resourceName: string;
    routerUrl: string;
    resourceIcon?: string;
    buttons?: any[];
    component?: any;
    noparent?: boolean;
    children?: Resources[];
}
export interface ResourcesConfig {
    /** 是否需要登录 */
    needLogin?: boolean;
    menuRoot?: boolean;
    resourceId?: string;
    type?: ResourceType | string;
    parentId?: string;
    resourceName: string;
    routerUrl: string;
    hide?: boolean;
    resourceIcon?: string;
    buttons?: any[];
    component?: any;
    children?: (Resources | Resources[])[];
}
export declare const RouterUtil: {
    getRouterConfig: () => Resources[];
    deepFlatten: (configs: (ResourcesConfig | ResourcesConfig[])[], path?: string, parentId?: string | undefined) => Resources[];
    /**将resources树形结构展平**/
    makeFlattenResources: (resources: Resources[]) => Resources[];
    createConfig: (configs: (ResourcesConfig | ResourcesConfig[])[], path?: string) => Resources[];
};
export {};
