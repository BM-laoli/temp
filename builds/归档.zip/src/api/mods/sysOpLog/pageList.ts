/**
 * @desc 分页查询TheOperationLog
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.OperationLogsPagingQueryParameters>): Promise<BaseResponse<defs.PageBean<Array<defs.TheOperationLog>>>> {
  return fetch({
    url: config.API_HOST + '/sys/opLog/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
