/**
 * @desc 导出车辆列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.TheDriverManagementQueryParameters): Promise<BaseResponse<any>> {
  return fetch({
    url: config.API_HOST + '/base/driver/export',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
