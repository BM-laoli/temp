/**
 * @description 驾驶员管理
 */
import * as add from './add'
import * as del from './del'
import * as deviceBindSwitch from './deviceBindSwitch'
import * as exporting from './exporting'
import * as findBindingLogList from './findBindingLogList'
import * as getDetail from './getDetail'
import * as importFile from './importFile'
import * as pageList from './pageList'
import * as passwordReset from './passwordReset'
import * as unbind from './unbind'
import * as update from './update'

export { add, del, deviceBindSwitch, exporting, findBindingLogList, getDetail, importFile, pageList, passwordReset, unbind, update }
