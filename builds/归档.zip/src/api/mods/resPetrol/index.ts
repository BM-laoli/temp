/**
 * @description Oil管理
 */
import * as findPetrolList from './findPetrolList'
import * as savePetrol from './savePetrol'
import * as updatePetrol from './updatePetrol'

export { findPetrolList, savePetrol, updatePetrol }
