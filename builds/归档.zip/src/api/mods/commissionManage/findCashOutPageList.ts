/**
 * @desc 分页查询提现记录
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.ComeOnMemberID>): Promise<BaseResponse<defs.PageBean<Array<defs.ExtractTheCommissionRecord>>>> {
  return fetch({
    url: config.API_HOST + '/commissionManage/findCashOutPageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
