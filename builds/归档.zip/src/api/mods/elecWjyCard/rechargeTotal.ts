/**
 * @desc 充值统计
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.TigerBalmTopUpQueryConditions): Promise<BaseResponse<defs.ResultBean<defs.AllAccountInformation>>> {
  return fetch({
    url: config.API_HOST + '/elecCard/wjy/rechargeTotal',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
