/**
 * @desc syncPetrolStations
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: string): Promise<BaseResponse<defs.G7RestResult>> {
  return fetch({
    url: config.API_HOST + '/g7/syncPetrolStations',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
