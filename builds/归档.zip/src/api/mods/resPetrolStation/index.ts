/**
 * @description 加油站信息管理
 */
import * as resPetrolStationAudit from './resPetrolStationAudit'
import * as auditPageList from './auditPageList'
import * as delResPetrolStationById from './delResPetrolStationById'
import * as findPetrolIdsByFuzzyStationName from './findPetrolIdsByFuzzyStationName'
import * as findPetrolListByFuzzyStationName from './findPetrolListByFuzzyStationName'
import * as getResPetrolStationById from './getResPetrolStationById'
import * as getResPetrolStationByPage from './getResPetrolStationByPage'
import * as resPetrolStationEnable from './resPetrolStationEnable'
import * as resPetrolStationLockCard from './resPetrolStationLockCard'
import * as resPetrolStationShow from './resPetrolStationShow'
import * as save from './save'

export {
  resPetrolStationAudit,
  auditPageList,
  delResPetrolStationById,
  findPetrolIdsByFuzzyStationName,
  findPetrolListByFuzzyStationName,
  getResPetrolStationById,
  getResPetrolStationByPage,
  resPetrolStationEnable,
  resPetrolStationLockCard,
  resPetrolStationShow,
  save,
}
