/**
 * @desc 加油站隐藏显示
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.ResPetrolStationShowParams): Promise<BaseResponse<defs.ResultBean<number>>> {
  return fetch({
    url: config.API_HOST + '/base/resPetrolStation/resPetrolStationShow',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
