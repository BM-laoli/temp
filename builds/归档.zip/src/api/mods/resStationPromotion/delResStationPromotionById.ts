/**
 * @desc 根据id删除加油站优惠信息
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 优惠信息id */
  id?: number
}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/base/resStationPromotion/delResStationPromotionById',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
