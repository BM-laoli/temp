/**
 * @description 加油站优惠信息管理
 */
import * as delResStationPromotionById from './delResStationPromotionById'
import * as getResStationPromotionById from './getResStationPromotionById'
import * as resStationPromotionPage from './resStationPromotionPage'
import * as resStationPromotionSave from './resStationPromotionSave'

export { delResStationPromotionById, getResStationPromotionById, resStationPromotionPage, resStationPromotionSave }
