/**
 * @desc 获取加油站优惠信息分页列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.ResPetrolStationPageParams>): Promise<BaseResponse<defs.PageBean<Array<defs.ResStationPromotionDto>>>> {
  return fetch({
    url: config.API_HOST + '/base/resStationPromotion/resStationPromotionPage',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
