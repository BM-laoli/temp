/**
 * @desc notify
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.NotifyEntity): Promise<BaseResponse<string>> {
  return fetch({
    url: config.API_HOST + '/groupOil/notify',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
