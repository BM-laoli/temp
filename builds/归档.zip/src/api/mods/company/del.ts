/**
     * @desc 删除合作公司
companyId
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.GroupIDParameter): Promise<BaseResponse<defs.ResultBean<defs.TheNewCooperationCompanyParameters>>> {
  return fetch({
    url: config.API_HOST + '/base/company/del',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
