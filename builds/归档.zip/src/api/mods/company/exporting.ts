/**
 * @desc 导出合作公司列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.CompanyPagingQueryParameters): Promise<BaseResponse<any>> {
  return fetch({
    url: config.API_HOST + '/base/company/export',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
