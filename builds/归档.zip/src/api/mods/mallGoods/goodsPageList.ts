/**
 * @desc 获取商品列表数据
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.MallGoodsPageQueryParams>): Promise<BaseResponse<defs.PageBean<Array<defs.MallGoods>>>> {
  return fetch({
    url: config.API_HOST + '/mall/goods/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
