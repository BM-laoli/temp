/**
     * @desc 获取车辆Details
id
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 唯一id */
  id: number
}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean<defs.CompanyVehicleInformation>>> {
  return fetch({
    url: config.API_HOST + '/base/vehicle/getDetail',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
