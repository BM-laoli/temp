/**
 * @desc 修改登录用户密码
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.SysAccountPwdEditParams): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/auth/user/passwordUpd',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
