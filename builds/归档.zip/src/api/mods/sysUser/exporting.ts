/**
 * @desc 导出用户列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 用户帐号 */
  loginName?: string
  /** 角色名称 */
  userName?: string
  /** 所属公司id */
  companyId?: number
  /** 角色名称 */
  roleName?: string
  /** 加油站名称 */
  stationName?: string
  /** 加油站id */
  stationId?: number
  /** 用户类型 0-加油员 1-驾驶员 2-公司人员 */
  userType?: number
  /** 推荐人id */
  referee?: number
}

export function request(data: QueryParams): Promise<BaseResponse<any>> {
  return fetch({
    url: config.API_HOST + '/auth/user/export',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
