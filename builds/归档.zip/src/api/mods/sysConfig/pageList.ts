/**
 * @desc 分页查询列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest): Promise<BaseResponse<defs.PageBean<Array<defs.SysConfigEntity>>>> {
  return fetch({
    url: config.API_HOST + '/sys/sysConfig/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
