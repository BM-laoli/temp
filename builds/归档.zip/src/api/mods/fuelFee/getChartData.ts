/**
 * @desc 加油总览列表数据
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean<defs.ComeOnTheOverviewScreenObjects>>> {
  return fetch({
    url: config.API_HOST + '/fuel/fee/getChartData',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
