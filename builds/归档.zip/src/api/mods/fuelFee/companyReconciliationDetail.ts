/**
 * @desc 公司对账明细
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<defs.ResultBean<Array<defs.TheReconciliationSubsidiaryEntities>>>> {
  return fetch({
    url: config.API_HOST + '/fuel/fee/companyReconciliationDetail',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
