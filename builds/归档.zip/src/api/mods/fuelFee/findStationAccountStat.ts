/**
 * @desc 查看预充值统计
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.ComeOnReconciliationQueryParameters): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/fuel/fee/findStationAccountStat',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
