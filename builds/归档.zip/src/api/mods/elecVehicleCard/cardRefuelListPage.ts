/**
 * @desc ComeOnDetail列表分页
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.OilCardDetailedQuery>): Promise<BaseResponse<defs.PageBean<Array<defs.ComeOnDetail>>>> {
  return fetch({
    url: config.API_HOST + '/elecCard/vehicle/CardRefuelListPage',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
