/**
 * @desc 油卡列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.ElectronicOilCardQueryObject>): Promise<BaseResponse<defs.PageBean<Array<defs.OilTeamElectronicCard>>>> {
  return fetch({
    url: config.API_HOST + '/elecCard/vehicle/cardInfoListPage',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
