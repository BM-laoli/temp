/**
 * @desc 查询油卡解锁Details
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.IdParamsObject): Promise<BaseResponse<defs.ResultBean<defs.TheUnlockCardDetails>>> {
  return fetch({
    url: config.API_HOST + '/elecCard/vehicle/findUnLockCardDetail',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
