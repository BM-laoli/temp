/**
 * @desc 油站加盟审核状态枚举
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(): Promise<BaseResponse<defs.ResultBean<Array<defs.EnumVo>>>> {
  return fetch({
    url: config.API_HOST + '/dict/findResCheckStatusEnumList',
    data: undefined,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
