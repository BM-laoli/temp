/**
 * @desc 获取订单信息列表数据
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.MallOrderPageQueryParams>): Promise<BaseResponse<defs.PageBean<Array<defs.MallOrder>>>> {
  return fetch({
    url: config.API_HOST + '/mall/order/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
