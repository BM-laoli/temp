import * as cardCompanyConfig from './cardCompanyConfig'
import * as cardOpenInvoice from './cardOpenInvoice'
import * as cardRechargeXls from './cardRechargeXls'
import * as commissionManage from './commissionManage'
import * as commissionStat from './commissionStat'
import * as company from './company'
import * as companyCard from './companyCard'
import * as dictionary from './dictionary'
import * as elecCard from './elecCard'
import * as elecVehicleCard from './elecVehicleCard'
import * as elecWjyCard from './elecWjyCard'
import * as elecYutuCard from './elecYutuCard'
import * as excel from './excel'
import * as fileUpload from './fileUpload'
import * as fuelFee from './fuelFee'
import * as g7 from './g7'
import * as groupOil from './groupOil'
import * as mallGoods from './mallGoods'
import * as mallOrder from './mallOrder'
import * as oilUser from './oilUser'
import * as resCompanyVehicle from './resCompanyVehicle'
import * as resPetrol from './resPetrol'
import * as resPetrolPrice from './resPetrolPrice'
import * as resPetrolStation from './resPetrolStation'
import * as resPetrolStationOrderby from './resPetrolStationOrderby'
import * as resPlatPromotion from './resPlatPromotion'
import * as resPublishInfo from './resPublishInfo'
import * as resSelfDriverAudit from './resSelfDriverAudit'
import * as resStationPromotion from './resStationPromotion'
import * as resVehicleDriver from './resVehicleDriver'
import * as resVehicleType from './resVehicleType'
import * as stYutuCard from './stYutuCard'
import * as star from './star'
import * as stationCommission from './stationCommission'
import * as statistics from './statistics'
import * as sysAppVersion from './sysAppVersion'
import * as sysConfig from './sysConfig'
import * as sysLogin from './sysLogin'
import * as sysMenu from './sysMenu'
import * as sysMsg from './sysMsg'
import * as sysOpLog from './sysOpLog'
import * as sysOrg from './sysOrg'
import * as sysRole from './sysRole'
import * as sysUser from './sysUser'
import * as task from './task'
import * as thirdOrgSet from './thirdOrgSet'

;(window as any).API = {
  cardCompanyConfig,
  cardOpenInvoice,
  cardRechargeXls,
  commissionManage,
  commissionStat,
  company,
  companyCard,
  dictionary,
  elecCard,
  elecVehicleCard,
  elecWjyCard,
  elecYutuCard,
  excel,
  fileUpload,
  fuelFee,
  g7,
  groupOil,
  mallGoods,
  mallOrder,
  oilUser,
  resCompanyVehicle,
  resPetrol,
  resPetrolPrice,
  resPetrolStation,
  resPetrolStationOrderby,
  resPlatPromotion,
  resPublishInfo,
  resSelfDriverAudit,
  resStationPromotion,
  resVehicleDriver,
  resVehicleType,
  stYutuCard,
  star,
  stationCommission,
  statistics,
  sysAppVersion,
  sysConfig,
  sysLogin,
  sysMenu,
  sysMsg,
  sysOpLog,
  sysOrg,
  sysRole,
  sysUser,
  task,
  thirdOrgSet,
}
