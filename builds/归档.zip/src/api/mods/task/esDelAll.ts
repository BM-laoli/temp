/**
 * @desc es删除所有加油站数据
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/task/esDelAll',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
