/*
 * @Author: TigerLord
 * @Date: 2022-10-08 13:55:44
 * @LastEditTime: 2022-12-27 16:51:41
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/api/mods/task/parsingWjyRestResult.ts
 */
/**
 * @desc 万金油油站变更 推送接口
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.WJYStation): Promise<BaseResponse<defs.RestResult>> {
  return fetch({
    url: config.API_HOST + '/task/parsingWjyRestResult',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 180 * 1000,
  })
}
