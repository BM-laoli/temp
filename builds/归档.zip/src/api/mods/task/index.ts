/**
 * @description Task Controller
 */
import * as createPetrolIndex from './createPetrolIndex'
import * as esDelAll from './esDelAll'
import * as esSaveAll from './esSaveAll'
import * as parsingWjyRestResult from './parsingWjyRestResult'
import * as syncWjyOilSiteInfo from './syncWjyOilSiteInfo'

export { createPetrolIndex, esDelAll, esSaveAll, parsingWjyRestResult, syncWjyOilSiteInfo }
