/**
 * @desc 分页菜单列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest): Promise<BaseResponse<defs.PageBean<Array<defs.SysMenuEntityObject>>>> {
  return fetch({
    url: config.API_HOST + '/auth/menu/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
