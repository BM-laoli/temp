/**
 * @desc 获取加油站加盟审核列表数据
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.Models>): Promise<BaseResponse<defs.PageBean<Array<defs.Models>>>> {
  return fetch({
    url: config.API_HOST + '/api/base/vehicleType/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
