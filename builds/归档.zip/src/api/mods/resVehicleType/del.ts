/**
 * @desc 根据id删除Models信息
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** Modelsid */
  id?: number
}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/api/base/vehicleType/del',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
