/**
 * @desc 选择部门(添加、修改菜单)
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.GroupIDParameter): Promise<BaseResponse<defs.ResultBean<Array<defs.SysDeptEntityObject>>>> {
  return fetch({
    url: config.API_HOST + '/shitiCard/yuTu/selectByOrgId',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
