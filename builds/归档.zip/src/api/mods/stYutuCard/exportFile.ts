/**
 * @desc 实体油卡管理导出
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.ElectronicOilCardQueryObject): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/shitiCard/yuTu/exportFile',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
