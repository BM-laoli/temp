/**
 * @desc 分页查询CommissionSetList
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.CommissionSetThePagingQueryParameters>): Promise<BaseResponse<defs.PageBean<Array<defs.CommissionSetList>>>> {
  return fetch({
    url: config.API_HOST + '/stationCommission/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
