/**
 * @desc 启用/禁用加油站ACommissionSetUp
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.ACommissionSetUp): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/stationCommission/enabled',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
