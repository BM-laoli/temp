/**
 * @desc 根据公司获取角色列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.GroupIDParameter): Promise<BaseResponse<defs.ResultBean<Array<defs.SysRoleEntityObject>>>> {
  return fetch({
    url: config.API_HOST + '/auth/role/select',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
