/**
     * @desc app最新版本信息接口
app最新版本信息接口
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.TheAppVersionNumberQuery): Promise<BaseResponse<defs.ResultBean<Array<defs.VersionControl>>>> {
  return fetch({
    url: config.API_HOST + '/sys/appVersion/version',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
