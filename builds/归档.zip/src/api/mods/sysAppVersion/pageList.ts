/**
 * @desc 分页列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.QueryConditionsAppVersion>): Promise<BaseResponse<defs.PageBean<Array<defs.VersionControl>>>> {
  return fetch({
    url: config.API_HOST + '/sys/appVersion/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
