/**
 * @desc 分页消息列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.SystemMessagePagingQueryConditions>): Promise<BaseResponse<defs.PageBean<Array<defs.SysMsgEntityObject>>>> {
  return fetch({
    url: config.API_HOST + '/msg/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
