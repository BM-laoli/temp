/**
 * @description 系统消息
 */
import * as pageList from './pageList'

export { pageList }
