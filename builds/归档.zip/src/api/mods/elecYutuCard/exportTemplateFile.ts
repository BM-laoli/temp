/**
 * @desc 云途油卡充值模版下载
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {
  /** 公司Id */
  companyId?: number
  /** 公司名称 */
  companyName?: string
  /** 部门id */
  deptId?: number
  /** 部门名称 */
  deptName?: string
  /** 卡号 */
  petrolCardNum?: string
  /** 车牌号 */
  vehicleNum?: string
  /** 车辆类型 0-自有车辆 1-外协车辆 */
  vehicleType?: number
  /** 登录名 */
  loginName?: string
  /** 油卡状态 0-禁用 1-正常  2-锁定 3-注销 */
  cardStatus?: number
  /** 油卡类型 */
  petrolCardType?: number
}

export function request(data: QueryParams): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/elecCard/yuTu/exportTemplateFile',
    params: data,
    method: 'GET',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
