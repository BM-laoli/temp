/**
 * @desc 云途油卡明细列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.CloudOilCardChangeDetailParameters>): Promise<BaseResponse<defs.PageBean<Array<defs.CloudOilCardChangeObjects>>>> {
  return fetch({
    url: config.API_HOST + '/elecCard/yuTu/changeLogListByPage',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
