/**
 * @desc 云途油卡子卡充值（主卡划拨给子卡）
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.CloudOilClipCardTopParameters): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/elecCard/yuTu/rechargeSubCard',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
