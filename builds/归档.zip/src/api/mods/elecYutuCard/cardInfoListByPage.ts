/**
 * @desc 云途油卡管理列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.ElectronicOilCardQueryObject>): Promise<BaseResponse<defs.PageBean<Array<defs.CloudElectronicOilClipCardObjects>>>> {
  return fetch({
    url: config.API_HOST + '/elecCard/yuTu/cardInfoListPage',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
