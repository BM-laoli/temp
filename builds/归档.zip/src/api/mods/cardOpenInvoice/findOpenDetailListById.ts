/**
 * @desc 查询明细列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.IdParamsObject): Promise<BaseResponse<defs.ResultBean<Array<defs.DetailedListOfMakeOutInvoice>>>> {
  return fetch({
    url: config.API_HOST + '/invoice/findOpenDetailListById',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
