/**
 * @desc 分页查询管理列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.QueryConditionsOfMakeOutInvoice>): Promise<BaseResponse<defs.ResultBean<Array<defs.TheInformationOfMakeOutInvoice>>>> {
  return fetch({
    url: config.API_HOST + '/invoice/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
