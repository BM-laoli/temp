/**
     * @desc TheRefreshToken
token超时，调用接口TheRefreshToken
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.TheRefreshToken): Promise<BaseResponse<defs.ResultBean<defs.TheLoginInformation>>> {
  return fetch({
    url: config.API_HOST + '/auth/refreshToken',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
