/**
 * @desc 退出接口
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/auth/logout',
    data: undefined,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
