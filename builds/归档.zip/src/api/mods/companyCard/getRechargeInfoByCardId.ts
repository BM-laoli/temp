/**
 * @desc 查询公司油卡充值明细
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.OilCompanyCardTopUpEntities>): Promise<BaseResponse<defs.PageBean<Array<defs.OilCompanyCardTopUpEntities>>>> {
  return fetch({
    url: config.API_HOST + '/base/company/card/getRechargeInfoByCardId',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
