/**
     * @desc 查询油卡明细分页列表
where查询条件
     */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest<defs.TheOilCardSubsidiaryQueryParameters>): Promise<BaseResponse<defs.PageBean<Array<defs.TheOilCardSubsidiaryReturnDetails>>>> {
  return fetch({
    url: config.API_HOST + '/base/company/card/getCardDetailInfos',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
