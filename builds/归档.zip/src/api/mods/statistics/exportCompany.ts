/**
 * @desc 导出公司ComeOnStatistical列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.CompanyComeOnStatisticalPagingConditions): Promise<BaseResponse<any>> {
  return fetch({
    url: config.API_HOST + '/statistics/exportCompany',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
