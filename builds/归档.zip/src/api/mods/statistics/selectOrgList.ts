/**
 * @desc 选择公司(添加、修改菜单)
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(): Promise<BaseResponse<defs.ResultBean<Array<defs.SysDeptEntityObject>>>> {
  return fetch({
    url: config.API_HOST + '/statistics/selectOrgList',
    data: undefined,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
