/**
 * @desc 补单
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.FillOneParameter): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/statistics/supplementOrder',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
