/**
 * @desc 导出订单列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.ComeOnStatisticalQueryParameters): Promise<BaseResponse<any>> {
  return fetch({
    url: config.API_HOST + '/statistics/exportWJY',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
