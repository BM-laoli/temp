/*
 * @Author: TigerLord
 * @Date: 2022-10-08 13:55:44
 * @LastEditTime: 2022-12-27 16:51:24
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/api/mods/thirdOrgSet/bindYtOrg.ts
 */
/**
 * @desc 绑定云图机构
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.ThirdPartyParametersBound): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/base/resThirdOrg/bandYtOrg',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 180 * 1000,
  })
}
