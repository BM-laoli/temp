/*
 * @Author: TigerLord
 * @Date: 2022-10-08 13:55:44
 * @LastEditTime: 2022-12-27 16:50:50
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/api/mods/thirdOrgSet/unbandYtOrg.ts
 */
/**
 * @desc 解绑云图机构
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.IdParameter): Promise<BaseResponse<defs.ResultBean>> {
  return fetch({
    url: config.API_HOST + '/base/resThirdOrg/unbandYtOrg',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 180 * 1000,
  })
}
