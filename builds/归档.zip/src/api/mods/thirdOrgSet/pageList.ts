/*
 * @Author: TigerLord
 * @Date: 2022-10-08 13:55:44
 * @LastEditTime: 2022-12-27 16:50:59
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/api/mods/thirdOrgSet/pageList.ts
 */
/**
 * @desc 查询关联设置分页列表
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.PageRequest): Promise<BaseResponse<defs.PageBean<Array<defs.TheThirdPartyInstitution>>>> {
  return fetch({
    url: config.API_HOST + '/base/resThirdOrg/pageList',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 180 * 1000,
  })
}
