/**
 * @description 系统设置-组织架构接口
 */
import * as remove from './remove'
import * as deptPageList from './deptPageList'
import * as getById from './getById'
import * as orgPageList from './orgPageList'
import * as saveDept from './saveDept'
import * as selectByOrgId from './selectByOrgId'
import * as selectOrgList from './selectOrgList'
import * as selectOrgUserByOrgId from './selectOrgUserByOrgId'
import * as updateDeptById from './updateDeptById'

export { remove, deptPageList, getById, orgPageList, saveDept, selectByOrgId, selectOrgList, selectOrgUserByOrgId, updateDeptById }
