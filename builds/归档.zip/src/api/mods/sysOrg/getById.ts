/**
 * @desc 获取Details
 */

import fetch from '@/utils/request'
import config from '@/config'

export interface QueryParams {}

export function request(data: defs.GroupIDParameter): Promise<BaseResponse<defs.ResultBean<defs.SysDeptEntityObject>>> {
  return fetch({
    url: config.API_HOST + '/auth/org/getById',
    data: data,
    method: 'POST',
    credentials: 'include',
    timeout: 20 * 1000,
  })
}
