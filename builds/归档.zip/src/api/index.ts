import * as defs from './baseClass'
import './mods/'

;(window as any).defs = defs
