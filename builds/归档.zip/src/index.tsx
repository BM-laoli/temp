import React, { useEffect } from 'react';
import ReactDOM from 'react-dom';
import * as serviceWorker from './serviceWorker';
import { ConfigProvider, Input } from 'antd';
import zhCN from 'antd/es/locale/zh_CN';
import $ from 'jquery';
import { RouterConfig, BrowserRouter, RouterUtil, DataTable, OSS } from '@cyber-ccx/lib';
import pageRoutes from '@/pages';
import 'antd/dist/antd.css';
import '@/index.less';
import 'moment/locale/zh-cn';
import Theme from '@/theme';
import '@/api';
import models from './models';
import Layout from './pages/main/Layout';
import { Redirect } from 'react-router-dom';
DataTable.defaultProps = { ...DataTable.defaultProps, noTools: true, defaultTableSize: 'middle' };

// OSS.init({
//   region: '',
//   accessKeyId: '',
//   accessKeySecret: '',
//   bucket: ''
// })

const validateMessages = {
  required: '${label} 是必填字段',
  types: {
    number: '请输入正确的数字',
    integer: '请输入整数',
    float: '请输入正确的数字',
    email: '请输入正确的邮箱',
  },
};
(window as any).RouterUtil = RouterUtil;
const App: React.FC<any> = () => {
  useEffect(() => {
    Theme.initTheme();

    (window as any)._AMapSecurityConfig = {
      securityJsCode: 'b7001edd925b777e2439345e34325ba2',
    };
  }, []);

  return (
    <BrowserRouter>
      <ConfigProvider locale={zhCN} form={{ validateMessages }}>
        <RouterConfig
          key={'rootConfig'}
          routerJson={pageRoutes}
          onBeforeRouterRender={(router) => {
            if (router.needLogin) {
              if (!models.global.user?.loginToken) {
                return false;
              }
              if (
                router.routerUrl.startsWith('/main') && 
                router.routerUrl !== '/main' &&
                router.routerUrl !== '/main/error'&&
                !models.global.menus.find(v => v.url === router.routerUrl)) {
      
                return <Redirect to={'/main/error'}/>;
              } 
              return true;
            } else {
              return true;
            }
          }}
          root={'/login'}
        />
      </ConfigProvider>
    </BrowserRouter>
  );
};

$(() => {
  ReactDOM.render(<App />, document.getElementById('root'));
});

serviceWorker.unregister();
