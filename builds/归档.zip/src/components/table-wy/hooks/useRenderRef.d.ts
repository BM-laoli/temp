interface RenderRef<T> {
    readonly current: T;
}
export default function useRenderRef<T = undefined>(init?: T): [RenderRef<T | undefined>, (data?: T) => void];
export {};
