/*
 * @Author: TigerLord
 * @Date: 2022-09-06 15:28:29
 * @LastEditTime: 2023-01-30 17:46:19
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/components/GasStationSelect.tsx
 */
import React, { useMemo, useRef } from 'react';
import { Select, SelectProps } from 'antd';
import _ from 'lodash';

interface GasStationSelectProps extends Omit<SelectProps<any>, 'options' | 'children'> {}

const GasStationSelect: React.FC<GasStationSelectProps> = ({ ...props }) => {
  const [fetching, setFetching] = React.useState(false);
  const [dataSource, setDataSource] = React.useState<defs.PetrolStationNameEntity[]>([]);

  React.useEffect(() => {
    if (props.value !== null && props.value !== undefined && props.value !== '') {
      if (props.value instanceof Array && props.value?.length <= 0) return;
      const ids = props.value instanceof Array ? props.value.join(',') : props.value;

      console.log(ids);
      
      API.resPetrolStation.findPetrolListByFuzzyStationName.request({ stationName: ids }).then((res) => {
        if (res.success) {
          setDataSource(res.data || []);
        }
      });
    }
  }, [props.value]);

  const debounceFetcher = React.useMemo(() => {
    const loadOptions = (value: string) => {
      setDataSource([]);

      if (value) {
        setFetching(true);
        API.resPetrolStation.findPetrolListByFuzzyStationName
          .request({ stationName: value })
          .then((res) => {
            if (res.success) setDataSource(res.data || []);
          })
          .finally(() => {
            setFetching(false);
          });
      }
    };

    return _.debounce(loadOptions, 800);
  }, []);

  const options = useMemo(() => dataSource.map((v) => ({ label: v.stationName || '', value: v.id ?? '', ...v })), [dataSource]);

  return <Select {...props} showSearch options={options} filterOption={false} onSearch={debounceFetcher} loading={fetching} />;
};

export default GasStationSelect;
