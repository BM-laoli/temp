import React, { useEffect, useState, memo } from "react";
import * as Api from "@/api";
import { Select, SelectProps } from 'antd'
import { observer } from 'mobx-react-lite'
import { useStore } from '@/models'

const Option = Select.Option;

interface BaseSelectProps extends SelectProps<any> {
  orgId?: number
  filterData?: defs.SysUserEntityObject[]
  valueFormat?: (item: defs.SysUserEntityObject) => string
}
/**
 * 信用卡银行选择器
 */
const UserSelect: React.FC<BaseSelectProps> = ({ orgId, filterData, valueFormat, ...props }) => {
  const [data, setData] = useState<defs.SysUserEntityObject[]>([]);

  useEffect(() => {
    load();
  }, [orgId]);

  const load = async () => {
    if (!orgId) return setData([]);
    let res = await API.sysOrg.selectOrgUserByOrgId.request({
      orgId
    });
    if (res.success && res.data) {
      let names = filterData?.map(v => v.id) || [];
      setData(res.data.filter(v => !names.includes(v.id)));
    }
  }

  return (
    <Select
      placeholder={'请选择用户'}
      style={{ width: '100%' }}
      showSearch
      allowClear
      {...props}>
      {data.map(v => {
        return (
          <Option key={v.id} value={valueFormat ? valueFormat(v) : v.id ?? ''} data={v}>{v.userName}</Option>
        )
      })}
    </Select>
  )
}

export default UserSelect;