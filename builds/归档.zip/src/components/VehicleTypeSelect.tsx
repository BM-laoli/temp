import React, { useEffect, useState, memo } from "react";
import * as Api from "@/api";
import { Select, SelectProps } from 'antd'
import { observer } from 'mobx-react-lite'
import { useStore } from '@/models'

const Option = Select.Option;

interface BaseSelectProps extends SelectProps<any> {
  filterData?: defs.Models[]
  valueFormat?: (item: defs.Models) => string
}
/**
 * 信用卡银行选择器
 */
const VehicleTypeSelect: React.FC<BaseSelectProps> = ({ filterData, valueFormat, ...props }) => {
  const { global } = useStore()
  const [data, setData] = useState<defs.Models[]>([]);

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    let res = await API.dictionary.findVehicleTypeList.request();
    if (res.success && res.data) {
      let names = filterData?.map(v => v.id) || [];
      setData(res.data.filter(v => !names.includes(v.id)));
    }
  }

  return (
    <Select
      placeholder={'选择车型'}
      style={{ width: '100%', maxWidth: '100%' }}
      showSearch
      allowClear
      {...props}>
      {data.map(v => {
        return (
          <Option key={v.id} value={valueFormat ? valueFormat(v) : v.id ?? ''}>{v.vehicleTypeName}</Option>
        )
      })}
    </Select>
  )
}

export default VehicleTypeSelect;