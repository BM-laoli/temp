import React, { useEffect, useState, memo } from "react";
import * as Api from "@/api";
import { Select, SelectProps } from 'antd'
import { observer } from 'mobx-react-lite'
import { useStore } from '@/models'

const Option = Select.Option;

interface BaseSelectProps extends SelectProps<any> {
  defaultId?:number
  deptId?:number
  filterData?:defs.CompanyVehicleInformation[]
  valueFormat?: (item: defs.CompanyVehicleInformation) => string
}
/**
 * 信用卡银行选择器
 */
const EleCarsSelect: React.FC<BaseSelectProps> = ({deptId,defaultId,filterData, valueFormat, ...props }) => {
  const [data, setData] = useState<defs.CompanyVehicleInformation[]>([]);

  useEffect(() => {
    load();
  }, [deptId]);

  const load = async () => {
    if(deptId === undefined) return;
    let res = await API.resCompanyVehicle.getVehicleListByDeptId.request({
      deptId:deptId,
      vehicleId:defaultId
    });
    if (res.success && res.data) {
      let names = filterData?.map(v=>v.id)||[];
      setData(res.data.filter(v=>!names.includes(v.id)));
    }
  }

  return (
    <Select
      placeholder={'请选择车辆'}
      style={{ width: '100%' }}
      showSearch
      allowClear
      filterOption={(input, option) =>
        option?.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
      }
      {...props}>
      {data.map(v => {
        return (
          <Option key={v.id} value={valueFormat ? valueFormat(v) : v.id||'' } data={v}>{v.vehicleNum}</Option>
        )
      })}
    </Select>
  )
}

export default EleCarsSelect;