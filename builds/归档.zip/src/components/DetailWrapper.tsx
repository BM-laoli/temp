import React from 'react';
import { Card } from 'antd';
import _ from 'lodash';
import { LeftCircleOutlined } from '@ant-design/icons';
import PageWrapper from '@/components/PageWrapper';
import { useHistory } from '@cyber-ccx/lib';

interface DetailWrapperProps {
  title?: string
  btns?:React.ReactNode
  loading?:boolean
}

const DetailWrapper: React.FC<DetailWrapperProps> = ({ title,loading,btns, children }) => {
  const history = useHistory();

  return (
    <PageWrapper className="list-page" title={title} breadcrumbSize="small">
      <div className="detail-content">
        <Card
          // loading={loading}
          title={
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',width:'100%'}}>
              <div onClick={() => history.goBack()} className="backBtn">
                <LeftCircleOutlined style={{ marginRight: 10 }} />
                <span>{title}</span>
              </div>
              <div>
                {btns}
              </div>
            </div>
          }
        >
          {children}
        </Card>
      </div>
    </PageWrapper>
  );
};

export default DetailWrapper;
