import React, { useEffect, useState, memo } from "react";
import * as Api from "@/api";
import { TreeSelect, TreeSelectProps, } from 'antd'
import { observer } from 'mobx-react-lite'
import { useStore } from '@/models'

interface BaseSelectProps extends TreeSelectProps<any> {

}
/**
 * 信用卡银行选择器
 */
const MenuSelect: React.FC<BaseSelectProps> = ({ ...props }) => {
  const [treeData, setTreeData] = useState([])

  useEffect(() => {
    load();
  }, []);

  const load = async () => {
    const res = await API.sysMenu.select.request();
    if (res.success && res.data) {
      let _temp: any = [];
      let _tempObj: any = {};
      res.data?.forEach(v => {
        const m = {
          title: v.name,
          key: v.menuId,
          children: []
        }
        if (v.parentMenuId === 0) {
          _temp.push(m);
        }
        _tempObj[m.key || ''] = m;
      })

      res.data?.forEach(v => {
        if (_tempObj[v.parentMenuId || '']) {
          _tempObj[v.parentMenuId || ''].children.push(_tempObj[v.menuId || '']);
        }
      })
      const _re:any = [{
        title: '根节点',
        key: 0,
        children: _temp
      }]
      setTreeData(_re);
    }
  }

  return (
    <TreeSelect treeData={treeData} {...props} />
  )
}

export default MenuSelect;