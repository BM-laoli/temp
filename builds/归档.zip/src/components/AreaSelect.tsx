import React, { useEffect, useState, memo, useMemo } from 'react';
import * as Api from '@/api';
import { Cascader, CascaderProps } from 'antd';
import { observer } from 'mobx-react-lite';
import { useStore } from '@/models';
import { CascaderOptionType } from 'antd/lib/cascader';

interface BaseSelectProps extends Omit<CascaderProps, 'options'> {
  defaultOptions?: Array<CascaderOptionType>;
}
/**
 * 信用卡银行选择器
 */
const AreaSelect: React.FC<BaseSelectProps> = ({ defaultOptions = [], ...props }) => {
  const [options, setOptions] = useState<any>(defaultOptions);

  useEffect(() => {
    loadProvince();
  }, []);

  const loadProvince = async () => {
    const res = await API.dictionary.findProvinceList.request();
    if (res.success && res.data) {
      const provicnce = res.data.map((v) => ({
        label: v.regionName,
        value: v.regionCode,
        type: 0,
        isLeaf: false,
      }));

      setOptions(provicnce);
    }
  };

  const loadData = async (selectedOptions: any) => {
    const targetOption = selectedOptions[selectedOptions.length - 1];
    targetOption.loading = true;
    if (targetOption.type === 0) {
      const res = await API.dictionary.findCityListByProvince.request({
        regionCode: targetOption.value,
      });
      if (res.success && res.data) {
        targetOption.children = res.data.map((v) => ({
          label: v.regionName,
          value: v.regionCode,
          type: 1,
          isLeaf: false,
        }));
      }
    } else if (targetOption.type === 1) {
      const res = await API.dictionary.findRegionListByCity.request({
        regionCode: targetOption.value,
      });
      if (res.success && res.data) {
        targetOption.children = res.data.map((v) => ({
          label: v.regionName,
          value: v.regionCode,
          type: 2,
        }));
      }
    }
    targetOption.loading = false;
    setOptions([...options]);
  };

  const _defaultOption = useMemo(() => [options], [defaultOptions]);

  return <Cascader options={options} loadData={loadData} {...props} />;
};

export default AreaSelect;
