import React, { useMemo } from 'react';
import { Select, SelectProps } from 'antd';
import { observer } from 'mobx-react-lite';
import { useStore } from '@/models';

interface QiaoOilSelectProps extends Omit<SelectProps<any>, 'options' | 'children'> {}

const QiaoOilSelect: React.FC<QiaoOilSelectProps> = observer((props) => {
  const { global } = useStore();
  const options = useMemo(() => global.qiaoOils.map((v) => ({ label: v.petrolName || '', value: v.id ?? '' })), [global.oils]);
  return <Select {...props} options={options} />;
});

export default QiaoOilSelect;
