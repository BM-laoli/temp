export default class PageConfig {
  /** 主题颜色 */
  theme = 'skyblue';
  /** 左侧模式 */
  leftTheme: 'dark' | 'light' = 'light';

  topTheme: 'dark' | 'light' | 'primary' = 'primary';

  layoutType: 'left' | 'top' | 'topLeft' | 'auto' = 'auto';

  topFixed = true;

  leftFixed = true;

  menuPostion: 'left' | 'top' = 'left';

  showBreadcrumb = true;
}
