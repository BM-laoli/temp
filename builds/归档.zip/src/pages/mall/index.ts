import Goods from "./Goods";
import Orders from "./Orders"; //$IMPORT$

export default () => [
  {
    resourceName: "积分商城",
    routerUrl: "/mall",
    resourceIcon: "",
    type: "0",
    buttons: [],
    children: [
      Goods(),
      Orders(), //$MORE$
    ],
  },
];
