import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "佣金统计",
    routerUrl: "/Commission",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./Commission")),
    children: [
      {
        needLogin: true,
        resourceName: "新增Commission",
        routerUrl: "/CommissionForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./CommissionForm")),
      },
      //$MORE$
    ],
  },
];
