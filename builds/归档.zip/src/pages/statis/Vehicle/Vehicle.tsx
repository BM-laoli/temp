import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import VehicleFormModal from './VehicleFormModal';
import AreaSelect from '@/components/AreaSelect';
import CardTypeSelect from '@/components/CardTypeSelect';
import { Random } from 'mockjs';
import { yuan } from '@/utils';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface VehicleProps extends RouteChildrenProps {}

const Vehicle: React.FC<VehicleProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  const btns = [
    <Button onClick={() => searchFrom.submit()}>查询</Button>,
    // <Button style={{ marginLeft: '20px' }} type={'primary'} onClick={() => history.push('Vehicle/VehicleForm')}>
    //   新增
    // </Button>,
    // <Button style={{ marginLeft: '20px' }} type={'primary'} onClick={() => modal.open()}>
    //   新增(弹窗)
    // </Button>,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="加油日期" name="time">
                <RangePicker allowClear style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="车牌号" name="vehicleNum">
                <Input autoComplete={'off'} placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="所属区域" name="areas">
                <AreaSelect placeholder="请选择" changeOnSelect allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="适用油卡" name="cardType">
                <CardTypeSelect placeholder="请选择" allowClear />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="数据列表"
          className={'full-table'}
          rowKeyIndex={'resourceId'}
          rowKey={() => Random.guid()}
          api={API.statistics.getStationStatisticsPage.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const [startDate, endDate] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
            const [provinceCode, cityCode, regionCode] = data.areas || [];
            let params: any = {
              where: { startDate, endDate, provinceCode, cityCode, regionCode, vehicleNum: data.vehicleNum, cardType: data.cardType },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
        >
          <DataColumn title="加油日期" dataIndex="dateTime" />
          <DataColumn title="车牌号" dataIndex="vehicleNum" />
          <DataColumn title="驾驶员" dataIndex="driverName" />
          <DataColumn title="油站名称" dataIndex="stationName" />
          <DataColumn title="所属公司" dataIndex="companyName" ellipsis />
          <DataColumn title="加油型号" dataIndex="petrolNames" ellipsis />
          <DataColumn title="油卡类型" dataIndex="cardTypeName" />
          <DataColumn title="加油量（升）" dataIndex="petrolCount" />
          <DataColumn title="加油金额/抵扣运费（元）" dataIndex="actTotalPrice" width={200} render={(item) => yuan(item)} />
          <DataColumn title="加油员" dataIndex="stationEmpName" />
        </DataTable>
      </div>
      <VehicleFormModal modal={modal} />
    </PageWrapper>
  );
};

export default Vehicle;
