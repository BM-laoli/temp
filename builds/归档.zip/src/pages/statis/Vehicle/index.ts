import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "车辆加油统计",
    routerUrl: "/Vehicle",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./Vehicle")),
    children: [
      {
        needLogin: true,
        resourceName: "新增Vehicle",
        routerUrl: "/VehicleForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./VehicleForm")),
      },
      //$MORE$
    ],
  },
];
