import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "公司加油统计",
    routerUrl: "/Company",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./Company")),
    children: [
      {
        needLogin: true,
        resourceName: "新增Company",
        routerUrl: "/CompanyForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./CompanyForm")),
      },
      //$MORE$
    ],
  },
];
