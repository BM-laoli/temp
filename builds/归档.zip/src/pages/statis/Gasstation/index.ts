import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "加油统计",
    routerUrl: "/Gasstation",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./Gasstation")),
    children: [
      {
        needLogin: true,
        resourceName: "新增Gasstation",
        routerUrl: "/GasstationForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./GasstationForm")),
      },
      //$MORE$
    ],
  },
];
