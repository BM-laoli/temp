/*
 * @Author: TigerLord
 * @Date: 2022-09-06 15:28:29
 * @LastEditTime: 2022-10-24 10:18:31
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/pages/statis/Gasstation/GasstationFormModal.tsx
 */
import React, { useEffect, useState, useMemo } from 'react';
import { Modal, Form, Input, notification, Select, Table } from 'antd';
import _ from 'lodash';
import { MLModal, useHistory, useQuery, useSearchForm } from '@cyber-ccx/lib';
import { Random } from 'mockjs';
import useSimpleReducer from '@/utils/hooks/useSimpleReducer';
import { yuan } from '@/utils';

interface GasstationFormModalProps extends MLModal.FormModalComponent {}

const GasstationFormModal: React.FC<GasstationFormModalProps> = ({ query, ...props }) => {
  const { modal } = props;
  const params: defs.ComeOnStatisticsPagingInformationCompany = modal.params;
  const [loading, setLoading] = useState(false);
  const [{ page, size, total }, dispatchPager] = useSimpleReducer({ page: 1, size: 10, total: 0 });
  const [dataSource, setDataSource] = useState<defs.CardPetrolDepositObject[]>([]);

  useEffect(() => {
    if (modal.isShow) {
      loadPage(1);
    }
  }, [modal.isShow]);

  const loadPage = async (page: number, pageSize?: number) => {
    const s = pageSize || size;
    dispatchPager({ page, size: s });
    try {
      const query: defs.PageRequest<defs.CompanyComeOnStatisticalSubsidiaryConditions> = {
        curPage: page,
        pageSize: s,
        where: {
          cardType: params.cardType ?? -1,
          companyId: Number(params.companyId || -1),
          endTime: params.endTime || '',
          petrolId: params.petrolId ,
          startTime: params.startTime || '',
          stationId: params.stationId,
          stationName:  params.stationName ?? '',
          petrolName: params.petrolName ?? '',
        },
      };
      setLoading(true);
      const res = await API.statistics.getCompanyPetrolDetailStatPage.request(query);
      if (res.success) {
        dispatchPager({ total: res.count });
        setDataSource(res.data || []);
      }
    } catch (error) {
      // error
    } finally {
      setLoading(false);
    }
  };

  const cancel = () => {
    modal.close();
  };

  /** 分页器 */
  const pager = React.useMemo(
    () => ({
      current: page,
      pageSize: size,
      total: total,
      showSizeChanger: true,
      showQuickJumper: true,
      showTotal: (total: number) => `共 ${total} 条数据`,
      onChange: loadPage,
    }),
    [page, size, total, loadPage]
  );

  return (
    <Modal title={`车辆加油明细`} width={1200} visible={modal.isShow} onCancel={cancel} className="form-page">
      <Table dataSource={dataSource} rowKey={() => Random.guid()} scroll={{ x: 'max-content' }} loading={loading} pagination={pager} size="small" tableLayout="fixed" bordered>
        <Table.Column title="加油日期" dataIndex="dateStr" />
        <Table.Column title="车牌号" dataIndex="vehicleNum" />
        <Table.Column title="驾驶员" dataIndex="driverName" />
        <Table.Column title="油站名称" dataIndex="stationName" />
        <Table.Column title="加油型号" dataIndex="petrolName" />
        <Table.Column title="油卡类型" dataIndex="cardTypeDesc" />
        <Table.Column title="加油量（升）" dataIndex="petrolCount" render={(t) => (t / 1000).toFixed(2)} />
        <Table.Column title="加油金额（元）" dataIndex="actTotalPrice" render={(t) => yuan(t)} />
        <Table.Column title="加油员" dataIndex="stationEmpName" />
      </Table>
    </Modal>
  );
};

export default GasstationFormModal;
