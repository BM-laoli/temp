/*
 * @Author: TigerLord
 * @Date: 2022-10-17 14:41:58
 * @LastEditTime: 2022-10-17 16:14:03
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/pages/statis/UnusualOrder/index.ts
 */
import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "异常订单",
    routerUrl: "/UnusualOrder",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./UnusualOrder")),
    children: [
      {
        needLogin: true,
        resourceName: "新增UnusualOrder",
        routerUrl: "/UnusualOrderForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./UnusualOrderForm")),
      },
      //$MORE$
    ],
  },
];
