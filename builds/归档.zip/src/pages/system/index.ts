import User from "./User";
import Role from "./Role";
import Org from "./Org";
import Dict from "./Dict";
import Commission from "./Commission";
import Promotion from "./Promotion";
import Log from "./Log";
import Resources from "./Resources";
import Version from "./Version";
import VehicleType from "./VehicleType";
import ContentModeration from "./ContentModeration"; //$IMPORT$
import OlisSetting from "./OlisSetting";

export default () => [
  {
    resourceName: "系统设置",
    routerUrl: "/system",
    resourceIcon: "",
    type: "0",
    buttons: [],
    children: [
      User(),
      Role(),
      Org(),
      // Dict(),
      Commission(),
      Promotion(),
      OlisSetting(),
      Log(),
      Resources(),
      Version(),
      VehicleType(),
      ContentModeration(), //$MORE$
    ],
  },
];
