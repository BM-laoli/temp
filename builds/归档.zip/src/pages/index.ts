import loadable from "@loadable/component";
import login from "@/pages/login";
import download from "@/pages/download";
import main from "@/pages/main";
import { RouterUtil } from "@cyber-ccx/lib";
import system from "@/pages/system";
import company from "@/pages/company";
import gasstation from "@/pages/gasstation";
import mall from "@/pages/mall";
import driver from "@/pages/driver";
import message from "@/pages/message";
import oilcost from "@/pages/oilcost";
import statis from "@/pages/statis";
import electron from "@/pages/electron";
import h5 from "@/pages/h5";
import error from "@/pages/error"; //$IMPORT$

export default RouterUtil.createConfig([
  login(),
  download(),
  h5(),
  main([
    message(),
    statis(),
    system(),
    mall(),
    oilcost(),
    driver(),
    electron(),
    company(),
    gasstation(),
    error(), //$MORE$
  ]),
]);
