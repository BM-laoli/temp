import SystemMessage from "./SystemMessage"; //$IMPORT$

export default () => [
  {
    resourceName: "系统消息",
    routerUrl: "/message",
    resourceIcon: "",
    type: "2",
    buttons: [],
    noparent: true,
    children: [
      SystemMessage(), //$MORE$
    ],
  },
];
