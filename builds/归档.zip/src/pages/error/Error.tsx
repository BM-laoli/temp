import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Result, Typography } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import { CloseCircleOutlined } from '@ant-design/icons';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;
const { Paragraph, Text } = Typography;

interface ErrorProps extends RouteChildrenProps {}

const Error: React.FC<ErrorProps> = (props) => {
  const history = useHistory();

  return (
    <PageWrapper className="list-page" noBreadcrumb>
      <Result
        status="error"
        title="暂无权限"
        extra={[
          <Button type="primary" key="home" onClick={() => history.replace('/main')}>
            返回首页
          </Button>,
          <Button key="back" onClick={() => history.goBack()}>
            返回上一页
          </Button>,
        ]}
      />
    </PageWrapper>
  );
};

export default Error;
