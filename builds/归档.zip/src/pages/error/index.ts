import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "暂无权限",
    routerUrl: "/error",
    resourceIcon: "TeamOutlined",
    type: "2",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./Error")),
    children: [
      //$MORE$
    ],
  },
];
