/*
 * @Author: TigerLord
 * @Date: 2022-09-06 15:28:29
 * @LastEditTime: 2023-01-30 17:41:43
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/pages/gasstation/Preferential/PreferentialFormModal.tsx
 */
import React, { useEffect, useState, useMemo } from 'react';
import { Modal, Form, Input, notification, Select, DatePicker, message } from 'antd';
import _, { fromPairs } from 'lodash';
import { MLModal, useHistory } from '@cyber-ccx/lib';
import Rules from '@/utils/rules';
import moment from 'moment';
import GasStationSelect from '@/components/GasStationSelect';
import useOnlyAsync from '@/utils/hooks/useOnlyAsync';

const { Option } = Select;
const FormItem = Form.Item;

interface PreferentialFormModalProps extends MLModal.FormModalComponent {}

const PreferentialFormModal: React.FC<PreferentialFormModalProps> = ({ query, ...props }) => {
  const { modal } = props;
  const isNew = !modal.params;
  const params = modal.params;
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [form] = Form.useForm();
  const readonly = params?.readonly;

  useEffect(() => {
    if (modal.isShow && !isNew) {
      form.setFieldsValue({
        ...params.item,
        times: [params?.item?.activityStartTime ? moment(params.item.activityStartTime) : undefined, params?.item?.activityEndTime ? moment(params.item.activityEndTime) : undefined],
      });
    } else {
      form.resetFields();
    }
  }, [modal.isShow]);

  const loadDetail = async () => {};

  const handleSubmit = useOnlyAsync(async () => {
    form.validateFields().then(async (formData) => {
      const [activityStartTime, activityEndTime] = [formData.times?.[0]?.format('YYYY-MM-DD'), formData.times?.[1]?.format('YYYY-MM-DD')];
      const data = { ...formData, activityStartTime, activityEndTime };
      const res: API.resStationPromotion.resStationPromotionSave.Response = await API.resStationPromotion.resStationPromotionSave.request(data);
      if (res.success) {
        message.success('保存成功');
        query?.refresh();
        cancel();
      }
    });
  });

  const cancel = () => {
    modal.close();
  };

  return (
    <Modal
      title={`${isNew ? '新增' : readonly ? '预览' : '修改'}优惠信息`}
      width={1200}
      visible={modal.isShow}
      okButtonProps={{ disabled: readonly }}
      onOk={handleSubmit}
      confirmLoading={loading}
      onCancel={cancel}
      className="form-page"
    >
      <Form form={form} labelCol={{ span: 4 }} wrapperCol={{ span: 18 }}>
        <FormItem name="id" hidden>
          <Input autoComplete={'off'} />
        </FormItem>
        <FormItem name="stationId" hidden>
          <Input autoComplete={'off'} />
        </FormItem>
        <FormItem label="油站名称" name="stationName" {...Rules('required')}>
          <GasStationSelect
            placeholder="请输入加油站关键词"
            onChange={(_e, option: any) => {
              form.setFieldsValue({ stationName: option.stationName, stationId: option.stationId });
            }}
          />
        </FormItem>
        <FormItem label="优惠信息" name="content" {...Rules('required')}>
          <Input.TextArea rows={5} maxLength={1000} placeholder="请填写优惠信息" />
        </FormItem>
        <FormItem label="优惠时限" name="times" {...Rules('required')}>
          <DatePicker.RangePicker />
        </FormItem>
      </Form>
    </Modal>
  );
};

export default PreferentialFormModal;
