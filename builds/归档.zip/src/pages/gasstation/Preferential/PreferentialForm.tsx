import React, { useEffect, useState, useMemo } from "react";
import { Modal, Form, Input, notification, Select, Card } from "antd";
import _ from "lodash";
import { RouteChildrenProps } from "react-router-dom";
import Rules from "@/utils/rules";
import DetailWrapper from "@/components/DetailWrapper";
import { useHistory } from "@cyber-ccx/lib";

const { Option } = Select;
const FormItem = Form.Item;

interface PreferentialFormProps extends RouteChildrenProps {}

const PreferentialForm: React.FC<PreferentialFormProps> = ({ ...props }) => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const history = useHistory();

  return (
    <DetailWrapper title={"编辑用户"}>
      <Form form={form} labelCol={{ span: 3 }} wrapperCol={{ span: 6 }}>
        <FormItem label="菜单名" name="resourceName" {...Rules("required")}>
          <Input autoComplete={'off'} />
        </FormItem>
        <FormItem label="菜单图标" name="resourceIcon">
          <Input autoComplete={'off'} />
        </FormItem>
        <FormItem label="目标路径" name="routerUrl" {...Rules("required")}>
          <Input autoComplete={'off'} />
        </FormItem>
        <FormItem label="资源类型" name="type" {...Rules("required")}>
          <Select>
            <Option value={0}>菜单</Option>
            <Option value={2}>路由</Option>
          </Select>
        </FormItem>
        <FormItem
          label="序号"
          name="serialNumber"
          {...Rules("required", "number")}
        >
          <Input autoComplete={'off'} />
        </FormItem>
        <FormItem label="备注" name="resourceDesc">
          <Input autoComplete={'off'} />
        </FormItem>
      </Form>
    </DetailWrapper>
  );
};

export default PreferentialForm;
