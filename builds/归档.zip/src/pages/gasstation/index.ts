import Gasstation from "./Gasstation";
import Employee from "./Employee";
import Petrol from "./Petrol";
import Preferential from "./Preferential";
import Commission from "./Commission";
import League from "./League"; //$IMPORT$
import GasstationRule from "./GasstationRule";
export default () => [
  {
    resourceName: "加油站",
    routerUrl: "/gasstation",
    resourceIcon: "",
    type: "0",
    buttons: [],
    children: [
      Gasstation(),
      Employee(),
      Petrol(),
      Preferential(),
      Commission(),
      League(), //$MORE$
      GasstationRule(),
    ],
  },
];
