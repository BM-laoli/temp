import React, { useEffect, useState, useMemo } from 'react';
import { Modal, Form, Input, Table, InputNumber, message, Descriptions, Spin } from 'antd';
import _ from 'lodash';
import { MLModal } from '@cyber-ccx/lib';
import useSimpleReducer from '@/utils/hooks/useSimpleReducer';
import { observer } from 'mobx-react-lite';
import { useStore } from '@/models';
import useOnlyAsync from '@/utils/hooks/useOnlyAsync';

const FormItem = Form.Item;
declare type PriceType = defs.Oil & defs.ResPetrolPrice;

interface PetrolFormModalProps extends MLModal.FormModalComponent {}

const PetrolFormModal: React.FC<PetrolFormModalProps> = observer(({ query, ...props }) => {
  const { global } = useStore();
  const { modal } = props;
  const isNew = !modal.params;
  const params = modal.params;
  const [{ loading, submit }, dispatchState] = useSimpleReducer({ loading: false, submit: false });
  const [form] = Form.useForm();
  const readonly = params?.readonly;
  const [detail, setDetail] = useState<defs.ResPetrolPriceDto>();

  useEffect(() => {
    if (modal.isShow && !isNew) {
      // form.setFieldsValue(params.item);
      loadDetail();
    } else {
      form.resetFields();
    }
  }, [modal.isShow]);

  const loadDetail = async () => {
    const res: API.resPetrolPrice.getResPetrolPriceByStationId.Response = await API.resPetrolPrice.getResPetrolPriceByStationId.request({ stationId: params?.item?.stationId });
    if (res.success) {
      const data = res.data || {};
      data.priceList?.forEach((v) => {
        v.petrolPrice = v.petrolPrice ? v.petrolPrice / 100 : undefined;
        v.suggestPrice = v.suggestPrice ? v.suggestPrice / 100 : undefined;
        v.listingPrice = v.listingPrice ? v.listingPrice / 100 : undefined;
        v.preferentialPrice = v.preferentialPrice ? v.preferentialPrice / 100 : ((v?.listingPrice || 0) - (v?.petrolPrice || 0)) / 100;
      });
      setDetail(data);
      form.setFieldsValue(data);
    }
  };

  const handleSubmit = useOnlyAsync(async () => {
    form.validateFields().then(async (formData) => {
      const data = {
        ...formData,
        priceList: formData.priceList?.map((v) => ({
          ...v,
          petrolPrice: Math.round(v.petrolPrice * 100),
          suggestPrice: Math.round(v.suggestPrice * 100),
          listingPrice: Math.round(v.listingPrice * 100),
          preferentialPrice: Math.round(v.preferentialPrice * 100),
        })),
      };
      const res: API.resPetrolPrice.resPetrolPriceSave.Response = await API.resPetrolPrice.resPetrolPriceSave.request(data);
      if (res.success) {
        message.success('保存成功');
        query?.refresh();
        cancel();
      }
    });
  });

  const cancel = () => {
    modal.close();
    setDetail(undefined);
  };

  const oils = useMemo(() => {
    const list = _.cloneDeep(global.oils);
    const priceList = (detail?.priceList || []).map((v) => {
      const o = list.find((item) => item.id === v.petrolId);
      return { ...v, ...o };
    });
    return priceList;
  }, [global.oils, detail]);

  const calcPrice = (index: number) => {
    const formData = form.getFieldsValue();
    const formPriceList = formData.priceList || [];
    const formItem = formPriceList[index];
    const preferentialPrice = (formItem?.listingPrice || 0) - (formItem?.petrolPrice || 0);
    form.setFields([{ name: ['priceList', index, 'preferentialPrice'], value: preferentialPrice }]);
  };

  return (
    <Modal
      title={`${isNew ? '新增' : readonly ? '预览' : '修改'}油品`}
      width={1400}
      visible={modal.isShow}
      okButtonProps={{ disabled: readonly }}
      onOk={handleSubmit}
      confirmLoading={loading}
      onCancel={cancel}
      className="form-page"
    >
      <Spin spinning={loading}>
        <Form form={form} labelCol={{ span: 4 }} wrapperCol={{ span: 18 }}>
          <FormItem name="stationId" hidden>
            <Input autoComplete={'off'} />
          </FormItem>
          <FormItem name="stationCode" hidden>
            <Input autoComplete={'off'} />
          </FormItem>
          <FormItem name="stationName" hidden>
            <Input autoComplete={'off'} />
          </FormItem>

          <FormItem>
            <Descriptions column={1} size="small" bordered labelStyle={{ width: '10em' }}>
              <Descriptions.Item label="油站名称">{params?.item?.stationName}</Descriptions.Item>
            </Descriptions>
          </FormItem>

          <Table dataSource={oils} tableLayout="fixed" rowKey="petrolId" size="small" bordered pagination={false}>
            <Table.Column<PriceType>
              title="油品"
              render={(_t, item, index) => (
                <>
                  <span>{item.petrolName}</span>
                  <Form.Item name={['priceList', index, 'petrolId']} initialValue={item.petrolId} noStyle hidden>
                    <Input autoComplete={'off'} />
                  </Form.Item>
                  <Form.Item name={['priceList', index, 'petrolName']} initialValue={item.petrolName} noStyle hidden>
                    <Input autoComplete={'off'} />
                  </Form.Item>
                  <Form.Item name={['priceList', index, 'id']} noStyle hidden>
                    <Input autoComplete={'off'} />
                  </Form.Item>
                </>
              )}
            />
            <Table.Column<PriceType>
              title="油站油品价格（元）"
              render={(_t, item, index) => (
                <Form.Item name={['priceList', index, 'petrolPrice']} initialValue={item.petrolPrice} rules={[{ required: true, message: '请输入油站油品价格' }]} wrapperCol={{ span: 24 }}>
                  <InputNumber min={0.01} precision={2} placeholder="请输入" style={{ width: '100%' }} onChange={() => calcPrice(index)} />
                </Form.Item>
              )}
            />
            <Table.Column<PriceType>
              title="油站油品发改委价格（元）"
              render={(_t, item, index) => (
                <Form.Item name={['priceList', index, 'suggestPrice']} initialValue={item.suggestPrice} rules={[{ required: true, message: '请输入油站油品发改委价格' }]} wrapperCol={{ span: 24 }}>
                  <InputNumber min={0.01} precision={2} placeholder="请输入" style={{ width: '100%' }} />
                </Form.Item>
              )}
            />
            <Table.Column<PriceType>
              title="挂牌价（元）"
              render={(_t, item, index) => (
                <Form.Item name={['priceList', index, 'listingPrice']} initialValue={item.listingPrice} rules={[{ required: true, message: '请输入挂牌价' }]} wrapperCol={{ span: 24 }}>
                  <InputNumber min={0.01} precision={2} placeholder="请输入" style={{ width: '100%' }} onChange={() => calcPrice(index)} />
                </Form.Item>
              )}
            />
            <Table.Column<PriceType>
              title="优惠价（元）"
              render={(_t, item, index) => (
                <Form.Item name={['priceList', index, 'preferentialPrice']} initialValue={item.preferentialPrice} rules={[{ required: true, message: '请输入优惠价' }]} wrapperCol={{ span: 24 }}>
                  <InputNumber disabled precision={2} placeholder="输入挂牌价和油站价格自动计算" style={{ width: '100%' }} />
                </Form.Item>
              )}
            />
          </Table>
        </Form>
      </Spin>
    </Modal>
  );
});

export default PetrolFormModal;
