import React, { useState, useEffect, useRef, useMemo } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag, Typography } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import PetrolFormModal from './PetrolFormModal';
import { yuan } from '@/utils';
import ExportButton from '@/components/ExportButton';
import StationSourceSelect from '@/components/StationSourceSelect';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface PetrolProps extends RouteChildrenProps {}

const Petrol: React.FC<PetrolProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();

  const [oils, setOils] = useState<defs.Oil[]>([]);

  React.useEffect(() => {
    loadOils();
  }, []);

  const loadOils = async () => {
    const res: API.dictionary.findPetrolList.Response = await API.dictionary.findPetrolList.request();
    if (res.success) {
      setOils(res.data || []);
    }
  };

  const btns = [
    <Button onClick={() => searchFrom.submit()}>查询</Button>,
    <ExportButton style={{ marginLeft: '15px' }} type={'primary'} query={listQuery} url="/excel/priceExportFile" title="油品价格" children="导出" />,
  ];

  const columns = useMemo(() => {
    const list = [
      { title: '油站名称', dataIndex: 'stationName', width: 300, ellipsis: true, key: 'stationName' },
    { title: '加油站来源', dataIndex: 'stationSourceDesc', width: 100, ellipsis: true, key: 'stationName' }];
    const oilList = oils.map((v) => ({
      title: v.petrolName,
      width: 120,
      ellipsis: true,
      key: `dyc-columns-${v.id}`,
      render: (_t: any, item: defs.ResPetrolPriceDto) => {
        const oil = (item.priceList || []).find((o: any) => o.petrolId === v.id);
        if (!oil) return '-';
        return yuan(oil?.petrolPrice);
      },
    }));
    const action = {
      title: '操作',
      fixed: 'right',
      width: 200,
      render: (_t: any, item: defs.ResPetrolPriceDto) => {
        return (
          <>
            <Button size="small" onClick={() => modal.open({ item })}>
              编辑
            </Button>
            <Button size="small" onClick={() => modal.open({ item, readonly: true })}>
              预览
            </Button>
            {/* <Button size="small" onClick={() => {}}>
              删除
            </Button> */}
          </>
        );
      },
    };
    return [...list, ...oilList, action];
  }, [oils]);

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="油站名称" name="stationName">
                <Input autoComplete={'off'} placeholder="请输入油站名称关键字" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="加油站来源" name="stationSource">
                <StationSourceSelect placeholder="请选择加油站来源" allowClear />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="油品列表"
          className={'full-table'}
          rowKeyIndex={'stationId'}
          api={API.resPetrolPrice.resPetrolStationPricePage.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            let params: any = {
              where: { ...data },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
          columns={columns}
        />
      </div>
      <PetrolFormModal modal={modal} query={listQuery} />
    </PageWrapper>
  );
};

export default Petrol;
