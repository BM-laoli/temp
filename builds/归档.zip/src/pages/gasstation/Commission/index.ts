import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "佣金管理",
    routerUrl: "/Commission",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./Commission")),
    children: [
      {
        needLogin: true,
        resourceName: "提现明细",
        routerUrl: "/CommissionForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./CommissionForm")),
      },
      //$MORE$
    ],
  },
];
