import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import CommissionFormModal from './CommissionFormModal';
import { yuan } from '@/utils';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface CommissionProps extends RouteChildrenProps {}

const Commission: React.FC<CommissionProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  const btns = [
    <Button onClick={() => searchFrom.submit()}>查询</Button>,
    // <Button style={{ marginLeft: '15px' }} type={'primary'} onClick={() => history.push('Commission/CommissionForm')}>
    //   新增
    // </Button>,
    // <Button style={{ marginLeft: '15px' }} type={'primary'} onClick={() => modal.open()}>
    //   新增(弹窗)
    // </Button>,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="加油员" name="userName">
                <Input autoComplete={'off'} placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="所属油站" name="stationName">
                <Input autoComplete={'off'} placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="佣金列表"
          className={'full-table'}
          rowKeyIndex={'userId'}
          api={API.commissionManage.pageList.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            let params: any = {
              where: { ...data },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
        >
          <DataColumn title="加油员" dataIndex="userName" />
          <DataColumn title="所属油站" dataIndex="stationName" />
          <DataColumn title="推荐人数" dataIndex="refereeNum" />
          <DataColumn title="累计加油金额" dataIndex="totalOilMoney" render={(item) => yuan(item)} />
          <DataColumn title="佣金总额" dataIndex="totalCommissionMoney" render={(item) => yuan(item)} />
          <DataColumn title="提现金额" dataIndex="totalCashOut" render={(item) => yuan(item)} />
          <DataColumn title="剩余金额" dataIndex="remainingCommision" render={(item) => yuan(item)} />
          <DataColumn
            title="操作"
            fixed="right"
            width={220}
            render={(item) => {
              console.log(item);
              return (
                <>
                  <Button size="small" onClick={() => modal.open({ item })}>
                    提现
                  </Button>
                  <Button size="small" onClick={() => history.push('Commission/CommissionForm', { ...item })}>
                    提现明细
                  </Button>
                </>
              );
            }}
          />
        </DataTable>
      </div>
      <CommissionFormModal modal={modal} query={listQuery} />
    </PageWrapper>
  );
};

export default Commission;
