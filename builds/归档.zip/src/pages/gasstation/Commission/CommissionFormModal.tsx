import React, { useEffect, useState, useMemo } from 'react';
import { Modal, Form, Input, notification, Select, InputNumber, message } from 'antd';
import _ from 'lodash';
import { MLModal, useHistory } from '@cyber-ccx/lib';
import Rules from '@/utils/rules';
import { observer } from 'mobx-react-lite';
import { useStore } from '@/models';
import useOnlyAsync from '@/utils/hooks/useOnlyAsync';

const FormItem = Form.Item;

interface CommissionFormModalProps extends MLModal.FormModalComponent {}

const CommissionFormModal: React.FC<CommissionFormModalProps> = observer(({ query, ...props }) => {
  const { modal } = props;
  const isNew = !modal.params;
  const params = modal.params;
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [form] = Form.useForm();
  const { global } = useStore();

  useEffect(() => {
    if (modal.isShow && !isNew) {
      form.setFieldsValue({ referee: params.item?.userId });
    } else {
      form.resetFields();
    }
  }, [modal.isShow]);

  const submit = useOnlyAsync(async () => {
    form.validateFields().then(async (formData) => {
      console.log(params?.item?.remainingCommision,333,formData.commissionMoney * 100);
      if(params?.item?.remainingCommision< Math.round(formData.commissionMoney * 100)){
        message.error('剩余金额不足！');
        return

      }
      const data = { ...formData, commissionMoney: Math.round(formData.commissionMoney * 100) };
      const res: API.commissionManage.withDrawCommission.Response = await API.commissionManage.withDrawCommission.request(data);
      if (res.success) {
        message.success('申请成功');
        query?.refresh();
        cancel();
      }
    });
  });

  const cancel = () => {
    modal.close();
  };

  const remainingCommisionYuan = useMemo(() => (params?.item?.remainingCommision || 0) / 100, [params?.item?.remainingCommision]);

  return (
    <Modal title={`提现`} width={600} visible={modal.isShow} onOk={submit} confirmLoading={loading} onCancel={cancel} className="form-page">
      <Form form={form} labelCol={{ span: 7 }} wrapperCol={{ span: 12 }}>
        <FormItem label="加油员">
          <Input autoComplete={'off'} value={params?.item?.userName} disabled />
        </FormItem>
        <FormItem name="referee" hidden>
          <Input autoComplete={'off'} />
        </FormItem>
        <FormItem label="提现金额（元）" name="commissionMoney" {...Rules('required')}>
          <InputNumber min={0.01} placeholder="请输入提现金额" style={{ width: '100%' }} />
        </FormItem>
        <FormItem label="操作员">
          <Input autoComplete={'off'} value={global.userInfo?.userName} disabled />
        </FormItem>
      </Form>
    </Modal>
  );
});

export default CommissionFormModal;
