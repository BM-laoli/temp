import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag, Switch } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import GasstationFormModal from './GasstationFormModal';
import AreaSelect from '@/components/AreaSelect';
import CardTypeSelect from '@/components/CardTypeSelect';
import ExportButton from '@/components/ExportButton';
import StationSourceSelect from '@/components/StationSourceSelect';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface GasstationProps extends RouteChildrenProps { }

const Gasstation: React.FC<GasstationProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  const btns = [
    <Button onClick={() => searchFrom.submit()} key="search">
      查询
    </Button>,
    <Button style={{ marginLeft: '15px' }} type={'primary'} onClick={() => history.push('Gasstation/GasstationForm')}>
      新增
    </Button>,
    <ExportButton
      style={{ marginLeft: '15px' }}
      type={'primary'}
      query={listQuery}
      formFormat={(data) => {
        const [startTimeStr, endTimeStr] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
        const [provinceCode, cityCode, regionCode] = data.areas || [];
        const params: any = { stationName: data.stationName, petrolCardType: data.petrolCardType, provinceCode, cityCode, regionCode, startTimeStr, endTimeStr };
        return params;
      }}
      url="/excel/stationExportFile"
      title="加油站"
      children="导出"
    />,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="创建日期" name="time">
                <RangePicker allowClear style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="加油站名称" name="stationName">
                <Input autoComplete={'off'} placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="所属区域" name="areas">
                <AreaSelect changeOnSelect allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="适用油卡" name="petrolCardType">
                <CardTypeSelect placeholder="请选择适用油卡" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="加油站来源" name="stationSource">
                <StationSourceSelect placeholder="请选择加油站来源" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="油卡锁定" name="isLockCard">
                <Select placeholder="全部" allowClear>
                  <Select.Option value={0}>不锁定</Select.Option>
                  <Select.Option value={1}>锁定</Select.Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="加油站列表"
          className={'full-table'}
          rowKeyIndex={'id'}
          api={API.resPetrolStation.getResPetrolStationByPage.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const [startTimeStr, endTimeStr] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
            const [provinceCode, cityCode, regionCode] = data.areas || [];
            const params: any = {
              where: { provinceCode, cityCode, regionCode, startTimeStr, endTimeStr, ...data },
              curPage: data.page,
              pageSize: data.rows,
            };

            return params;
          }}
        >
          <DataColumn title="油站编码" dataIndex="stationCode" width={180} tooltip />
          <DataColumn title="创建日期" dataIndex="joinTime" width={180} tooltip />
          <DataColumn title="油站名称" dataIndex="stationName" width={200} tooltip />
          <DataColumn title="适用油卡" dataIndex="petrolCardTypeStr" width={100} tooltip />
          <DataColumn title="所属区域" dataIndex="merName" width={200} tooltip />
          <DataColumn title="加油站来源" dataIndex="stationSourceStr" width={100} tooltip />
          <DataColumn title="油品" dataIndex="petrolNames" width={200} tooltip />
          {/* <DataColumn title="对接状态" dataIndex="isEnabled" width={80}  render={(type: number) => {
              return type == 0 ?'未对接' : (
                <div className="successColor">已对接</div>
              ) ;
            }} /> */}
          <DataColumn title="油卡锁定" width={80} dataIndex="isLockCard" render={(isLockCard, item) => {
            return <Switch checkedChildren="锁定" unCheckedChildren="不锁定" checked={!!isLockCard} onChange={() => {
              MLModal.openWarningModal(
                '提示',
                `是否${!isLockCard ? '锁定' : '不锁定'}该设置？`,
                { id: item.id, isLockCard: !isLockCard ? 1 : 0 },
                API.resPetrolStation.resPetrolStationLockCard.request,
                listQuery
              )
            }} />
          }} />
          <DataColumn title="油站状态" width={80}  dataIndex="isEnabled" render={(isEnabled, item) => {
            return isEnabled == 1 ? '启用' : '禁用'
          }} />
          <DataColumn title="是否显示" width={80}  dataIndex="isShow" render={(isShow, item) => {
            return <Switch checkedChildren="是" unCheckedChildren="否" checked={!!isShow} onChange={() => {
              MLModal.openWarningModal(
                '提示',
                `是否显示确认？`,
                { id: item.id, isShow: !isShow ? 1 : 0 },
                API.resPetrolStation.resPetrolStationShow.request,
                listQuery
              )
            }} />
          }} />
          <DataColumn
            title="操作"
            fixed="right"
            width={120}
            render={(item) => {
              return (
                <>
                  {!!item.thirdId ? '' :<Button size="small" onClick={() => history.push(`Gasstation/GasstationForm?id=${item.id}`)}>
                    编辑
                  </Button>}

                  <Button size="small" onClick={() => history.push(`Gasstation/GasstationForm?id=${item.id}&readonly=1`)}>
                    预览
                  </Button>
                  {/* <Button size="small" onClick={() => MLModal.openDeleteModal(item, API.resPetrolStation.delResPetrolStationById.request, listQuery)}>
                    删除
                  </Button> */}
                  {/* {item.stationSource !== 2 && (
                    <Button
                      size="small"
                      onClick={() =>
                        MLModal.openWarningModal(
                          '提示',
                          `确认【${item.isEnabled ? '关闭' : '开启'}】${item.stationName}吗？`,
                          { id: item.id, isEnabled: item.isEnabled ? 0 : 1 },
                          API.resPetrolStation.resPetrolStationEnable.request,
                          listQuery
                        )
                      }
                    >
                      {item.isEnabled ? '关闭' : '开启'}
                    </Button>
                  )} */}
                </>
              );
            }}
          />
        </DataTable>
      </div>
      <GasstationFormModal modal={modal} />
    </PageWrapper>
  );
};

export default Gasstation;
