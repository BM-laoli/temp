/*
 * @Author: TigerLord
 * @Date: 2023-01-10 14:25:25
 * @LastEditTime: 2023-01-10 16:23:53
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/pages/gasstation/Gasstation/GasStationBillFormModal.tsx
 */
import React, { useEffect, useState, useMemo } from "react";
import { Modal, Form, Input, notification, Select, message } from "antd";
import _ from "lodash";
import { MLModal, useHistory } from "@cyber-ccx/lib";
import Rules from "@/utils/rules";
import { yuan } from "@/utils";

const { Option } = Select;
const FormItem = Form.Item;

interface GasStationBillFormModalProps extends MLModal.FormModalComponent {}

const GasStationBillFormModal: React.FC<GasStationBillFormModalProps> = ({
  query,
  ...props
}) => {
  const { modal } = props;
  const isNew = !modal.params;
  const params = modal.params;
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [form] = Form.useForm();
  const [cashData, setCashData] = useState<any>();

  useEffect(() => {
    if ( modal.isShow && params.stationId) {
      console.log('params.stationId', params.stationId);
      
      loadDetail();
    }
    form.resetFields()
    // if (modal.isShow && !isNew) {
    //   form.setFieldsValue(params.item);
    //   console.log(params);
      
    // } else {
    //   form.resetFields();
    // }
  }, [modal.isShow]);

  const loadDetail = async () => {
    const data = {
      id: params.stationId,
    };
    const cash: API.fuelFee.findStationAccount.Response = await API.fuelFee.findStationAccount.request(data);
    if (cash.success && cash.data) {
      console.log('sssss', cash.data);
      
      setCashData(cash.data)
    }
  };
  const handleInput = (e) => {
    // e.persist();
    const val = e.target.value
      const value: any = (val.match(/^\d*(\.?\d{0,2})/g)[0])|| null
      if (value > 9999999) {
        form.setFieldsValue({ rechargeMoney: 9999999 });
      } else {
        form.setFieldsValue({ rechargeMoney: value });
      }
      
  }
  const submit = async () => {

    form
      .validateFields()
      .then(async (formData) => {
        const data = {
          ...formData,
          rechargeMoney: (formData.rechargeMoney * 100).toFixed(0),
          stationId: params.stationId,
        };
      setLoading(true);
      const res = await API.fuelFee.rechargeStationAccount.request(data);
      setLoading(false);
      if (res.success) {
        message.success(`设置成功`);
        query?.refresh();
        cancel();
      }
    })
  };

  const cancel = () => {
    modal.close();
  };

  return (
    <Modal
      title={`预充值`}
      width={600}
      visible={modal.isShow}
      onOk={submit}
      confirmLoading={loading}
      onCancel={cancel}
      className="form-page"
    >
      <Form form={form} labelCol={{ span: 7 }} wrapperCol={{ span: 12 }}>
        <FormItem label="预充值金额" name="rechargeMoney" {...Rules('priceTwo', "required")}>
          <Input autoComplete={'off'} max={9999999} onChange={ e => handleInput(e)}/>
        </FormItem>
        <FormItem label="账户当前余额">
          <label>¥ { yuan(cashData?.remainingSum)} </label>
        </FormItem>
        <FormItem label="备注" name="remark" >
          <Input autoComplete={'off'}/>
        </FormItem>
      </Form>
    </Modal>
  );
};

export default GasStationBillFormModal;
