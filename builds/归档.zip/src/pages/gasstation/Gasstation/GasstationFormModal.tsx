import React, { useEffect, useState, useMemo } from 'react';
import { Modal, Form, Input, notification, Select, Radio, Space, Button, Checkbox, Divider, message } from 'antd';
import _ from 'lodash';
import { MLModal, useHistory } from '@cyber-ccx/lib';
import Rules from '@/utils/rules';
import FormMapAddress from '@/components/form-components/form-map-address';
import FormUploadImage from '@/components/form-components/form-upload-image';
import { CloseOutlined, PlusOutlined } from '@ant-design/icons';
import useSimpleReducer from '@/utils/hooks/useSimpleReducer';
import AreaSelect from '@/components/AreaSelect';

const { Option } = Select;
const FormItem = Form.Item;

interface GasstationFormModalProps extends MLModal.FormModalComponent {}

const GasstationFormModal: React.FC<GasstationFormModalProps> = ({ query, ...props }) => {
  const { modal } = props;
  const isNew = !modal.params;
  const params = modal.params;
  const history = useHistory();
  const [form] = Form.useForm();

  const [oils, setOils] = useState<defs.Oil[]>([]);
  const oilOptions = useMemo(() => oils.map((v) => ({ label: v.petrolName || '', value: v.id || '' })), [oils]);

  const [{ loading, submit }, dispatchState] = useSimpleReducer({ loading: false, submit: false });
  const readonly = params?.readonly;

  useEffect(() => {
    loadDicts();
  }, []);

  useEffect(() => {
    if (modal.isShow) {
      if (isNew) {
        form.setFieldsValue({ stationDeviceList: [{}] });
      } else {
        loadDetail();
      }
    } else {
      form.resetFields();
    }
  }, [modal.isShow]);

  const loadDetail = async () => {
    const res: API.resPetrolStation.getResPetrolStationById.Response = await API.resPetrolStation.getResPetrolStationById.request({ id: params.item.id });
    if (res.success) {
      const detail = res.data || {};
      form.setFieldsValue({
        ...detail,
        stationImgList: detail.stationImgList?.map((v, i) => ({ resourceId: v.bigImgId || i.toString(), fileUrl: v.bigImgAddr })),
        areas: [detail.provinceCode, detail.cityCode, detail.regionCode],
        petrolIds: detail.petrolIds?.split(','),
      });
    }
  };

  const loadDicts = async () => {
    const res: API.dictionary.findPetrolList.Response = await API.dictionary.findPetrolList.request();
    if (res.success) {
      setOils(res.data || []);
    }
  };

  const handleSubmit = async () => {
    form
      .validateFields()
      .then(async (formData) => {
        dispatchState({ submit: true });
        const [provinceCode, cityCode, regionCode] = formData.areas;
        const data = {
          ...formData,
          provinceCode,
          cityCode,
          regionCode,
          stationImgList: formData.stationImgList.map((v) => ({ bigImgAddr: v.fileUrl })),
          petrolIds: formData.petrolIds.join(','),
        };
        const res: API.resPetrolStation.save.Response = await API.resPetrolStation.save.request(data);
        if (res.success) {
          message.success('保存成功');
          cancel();
        }
      })
      .finally(() => {
        dispatchState({ submit: false });
      });
  };

  const cancel = () => {
    modal.close();
  };

  return (
    <Modal title={`${isNew ? '新增' : '修改'}加油站`} width={1200} visible={modal.isShow} onOk={handleSubmit} confirmLoading={submit} onCancel={cancel} className="form-page">
      <Form form={form} labelCol={{ span: 4 }} wrapperCol={{ span: 18 }}>
        <FormItem name="id" hidden>
          <Input autoComplete={'off'} disabled={readonly} />
        </FormItem>
        <FormItem label="油站名称" name="stationName" {...Rules('required')}>
          <Input autoComplete={'off'} disabled={readonly} />
        </FormItem>
        <FormItem label="油站图片" name="stationImgList" rules={[{ type: 'array', min: 1, required: true }]}>
          <FormUploadImage crop />
        </FormItem>
        <FormItem label="适用油卡" name="petrolCardType" {...Rules('required')}>
          <Radio.Group disabled={readonly}>
            <Radio value={0}>车队油卡</Radio>
            <Radio value={1}>云途油卡</Radio>
            <Radio value={2}>实体油卡</Radio>
          </Radio.Group>
        </FormItem>
        <FormItem label="油站地址" name="detailAddr" {...Rules('required')}>
          <FormMapAddress onChange={(a, p) => console.log(a, p)} disabled={readonly} />
        </FormItem>
        <FormItem label="所属区域" name="areas" {...Rules('required')}>
          <AreaSelect disabled={readonly} />
        </FormItem>
        <FormItem label="油站来源" name="stationSource" {...Rules('required')}>
          <Radio.Group disabled={readonly}>
            <Radio value={0}>自有加油撬</Radio>
            <Radio value={1}>自有加盟</Radio>
            <Radio value={2}>万金油</Radio>
            <Radio value={3}>传化</Radio>
            <Radio value={4}>路歌</Radio>
            <Radio value={5}children="G7" />
            <Radio value={6} children="星油" />
            <Radio value={7} children="团油" />
          </Radio.Group>
        </FormItem>

        <FormItem label={<></>} colon={false}>
          <Form.List name="stationDeviceList">
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, fieldKey, ...restField }, i) => (
                  <Space key={key} style={{ display: 'flex', marginBottom: 8 }} align="baseline">
                    <Form.Item {...restField} label="加油撬编号" name={[name, 'deviceCode']} {...Rules('required')}>
                      <Input autoComplete={'off'} placeholder="请输入加油撬编号" disabled={readonly} />
                    </Form.Item>
                    <Form.Item {...restField} label="油品" name={[name, 'petrolId']} {...Rules('required')}>
                      <Select options={oilOptions} placeholder="请选择油品" disabled={readonly} style={{ width: 200 }} />
                    </Form.Item>
                    <Form.Item {...restField} name={[name, 'isSelfDevice']} {...Rules('required')}>
                      <Radio.Group disabled={readonly} style={{ width: 200 }}>
                        <Radio value={1}>自有</Radio>
                        <Radio value={0}>租用</Radio>
                      </Radio.Group>
                    </Form.Item>
                    {i > 0 && !readonly && <Button danger icon={<CloseOutlined />} onClick={() => remove(name)} />}
                  </Space>
                ))}
                {!readonly && (
                  <Form.Item>
                    <Button type="dashed" onClick={() => add()} block icon={<PlusOutlined />} children="添加加油撬" />
                  </Form.Item>
                )}
              </>
            )}
          </Form.List>
        </FormItem>
        <FormItem label="油品" name="petrolIds" {...Rules('required')}>
          <Checkbox.Group options={oilOptions} disabled={readonly} />
        </FormItem>
        <FormItem label="油站联系人" name="contactName" {...Rules('required')}>
          <Input autoComplete={'off'} disabled={readonly} />
        </FormItem>
        <FormItem label="手机号" name="contactPhone" {...Rules('required', 'phone')}>
          <Input autoComplete={'off'} disabled={readonly} />
        </FormItem>

        <Divider />

        <FormItem label="开户银行" name="openAddr">
          <Input autoComplete={'off'} disabled={readonly} />
        </FormItem>
        <FormItem label="开户地址" name="openAddr">
          <Input autoComplete={'off'} disabled={readonly} />
        </FormItem>
        <FormItem label="银行账号" name="bankAccount">
          <Input autoComplete={'off'} disabled={readonly} />
        </FormItem>
      </Form>
    </Modal>
  );
};

export default GasstationFormModal;
