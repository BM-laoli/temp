import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag,Switch } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import AreaSelect from '@/components/AreaSelect';
import CardTypeSelect from '@/components/CardTypeSelect';
import ExportButton from '@/components/ExportButton';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface GasstationProps extends RouteChildrenProps {}

const Gasstation: React.FC<GasstationProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        {/* <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="创建日期" name="time">
                <RangePicker allowClear style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="加油站名称" name="stationName">
                <Input autoComplete={'off'} placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="所属区域" name="areas">
                <AreaSelect changeOnSelect allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="适用油卡" name="petrolCardType">
                <CardTypeSelect placeholder="请选择适用油卡" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="油站来源" name="stationSource">
                <Select placeholder="清选择" allowClear>
                  <Select.Option value={0} children="自有加油撬" />
                  <Select.Option value={1} children="自有加盟" />
                  <Select.Option value={2} children="万金油" />
                  <Select.Option value={3} children="传化" />
                  <Select.Option value={4} children="路歌" />
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </SearchForm> */}
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="加油站列表"
          className={'full-table'}
          rowKeyIndex={'id'}
          api={API.resPetrolStationOrderby.findList.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const [startTimeStr, endTimeStr] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
            const [provinceCode, cityCode, regionCode] = data.areas || [];
            const params: any = {
              where: { provinceCode, cityCode, regionCode, startTimeStr, endTimeStr, ...data },
              curPage: data.page,
              pageSize: data.rows,
            };

            return params;
          }}
        >
          <DataColumn title="规则ID" dataIndex="id" width={180} tooltip />
          <DataColumn title="规则描述" dataIndex="ruleName"  tooltip />
          <DataColumn title="油站状态" dataIndex="isEnabled" width={90} render={(isEnabled, item) => {
            return <Switch checkedChildren="有效" unCheckedChildren="禁用" checked={!!isEnabled} onChange={() => {
              MLModal.openWarningModal(
                '提示',
                `是否${!isEnabled ? '有效' : '禁用'}该设置？`,
                { id: item.id, isEnabled: !isEnabled ? 1 : 0 },
                API.resPetrolStationOrderby.enabled.request,
                listQuery
              )
            }} />
          }} />
        </DataTable>
      </div>
    </PageWrapper>
  );
};

export default Gasstation;
