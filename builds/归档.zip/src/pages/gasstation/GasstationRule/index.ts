import loadable from '@loadable/component';
//$IMPORT$
export default () => [
  {
    needLogin: true,
    resourceName: '油站排序规则',
    routerUrl: '/GasstationRule',
    resourceIcon: 'TeamOutlined',
    type: '0',
    buttons: [],
    noparent: true,
    component: loadable(() => import('./GasstationRule')),
    children: [],
  },
];
