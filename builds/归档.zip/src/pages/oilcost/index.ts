import CompanyBill from "./CompanyBill";
import GasStationBill from "./GasStationBill";
import QiaoBill from "./QiaoBill";
import Overview from "./Overview";
import Invoice from "./Invoice"; //$IMPORT$

export default () => [
  {
    resourceName: "油费管理",
    routerUrl: "/oilcost",
    resourceIcon: "",
    type: "0",
    buttons: [],
    children: [
      Overview(),
      CompanyBill(),
      GasStationBill(),
      QiaoBill(),
      Invoice(), //$MORE$
    ],
  },
];
