import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "公司加油对账",
    routerUrl: "/CompanyBill",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./CompanyBill")),
    children: [
      {
        needLogin: true,
        resourceName: "对账单",
        routerUrl: "/CompanyBillForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./CompanyBillForm")),
      },
      //$MORE$
    ],
  },
];
