import React, { useEffect, useState, useMemo } from 'react';
import { Modal, Form, Input, notification, Select, Card, Row, Col, Button, Table } from 'antd';
import _ from 'lodash';
import { RouteChildrenProps, useLocation } from 'react-router-dom';
import Rules from '@/utils/rules';
import DetailWrapper from '@/components/DetailWrapper';
import { DataColumn, DataTable, SearchForm, useHistory, useQuery, useSearchForm } from '@cyber-ccx/lib';
import { PageBlock } from '@/components/PageWrapper';
import { useStore } from '@/models';
import { observer } from 'mobx-react-lite';
import CardTypeSelect from '@/components/CardTypeSelect';
import OilSelect from '@/components/OilSelect';
import GasStationSelect from '@/components/GasStationSelect';
import { yuan, ml2litre } from '@/utils';
import { Random } from 'mockjs';
import ExportButton from '@/components/ExportButton';
import OrgSelect from '@/components/OrgSelect';

const { Option } = Select;
const FormItem = Form.Item;

interface CompanyBillFormProps extends RouteChildrenProps { }

const CompanyBillForm: React.FC<CompanyBillFormProps> = ({ ...props }) => {
  const [loading, setLoading] = useState(false);
  const searchFrom = useSearchForm();
  const listQuery = useQuery();
  const location = useLocation<any>();
  const [dataSource, setDataSource] = useState<defs.TheReconciliationSubsidiaryEntities[]>([]);

  const btns = [
    <Button key={1} onClick={() => searchFrom.submit()}>查询</Button>,
    <ExportButton
      key={2}
      style={{ marginLeft: '15px' }}
      type={'primary'}
      query={listQuery}
      formFormat={(data) => {
        const params: any = {
          ...data,
          cardType: location?.state?.petrolCardType,
          stationSource: location?.state?.stationSource,
          stationName: location?.state?.stationName,
          companyId: location?.state?.companyId,
          dateTime: location?.state?.dateTime,
        };
        return params;
      }}
      url="/fuel/fee/exportCompanyReconciliationDetail"
      title={`${location?.state?.companyName}-${location?.state?.dateTime}月份对账单`}
      children="导出"
    />,
  ];

  // React.useEffect(() => {
  //   loadDetail(listQuery.get());
  // }, [listQuery.get()]);

  const loadDetail = async (formData: any) => {
    setLoading(true);
    const data = {
      ...formData,
      companyId: location?.state?.companyId,
      cardType: location?.state?.petrolCardType,
      stationSource: location?.state?.stationSource,
      stationName: location?.state?.stationName,
      dateTime: location?.state?.dateTime,
    };
    const res: API.fuelFee.companyReconciliationDetailPageList.Response = await API.fuelFee.companyReconciliationDetailPageList.request(data);
    if (res.success) {
      setDataSource(res.data || []);
    }
    setLoading(false);
  };

  return (
    <DetailWrapper title={`${location?.state?.companyName} ${location?.state?.dateTime}月份对账单`}>
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={6}>
              <Form.Item label="车牌号" name="vehicleNum">
                <Input autoComplete={'off'} placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="加油型号" name="petrolId">
                <OilSelect placeholder="请选择" allowClear />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="加油站" name="stationId">
                <GasStationSelect placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
            <Col span={6}>
              <FormItem label="所属部门" name="deptId" {...Rules('required')}>
                <OrgSelect
                 placeholder="请选择所属部门" 
                  orgId={location?.state?.companyId}
                />
              </FormItem>
            </Col>
            <Col span={6}>
              <Form.Item label="订单号" name="orderSerialNo">
                <Input autoComplete={'off'} placeholder="请输入订单号" allowClear />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="油卡卡号" name="cardNum">
                <Input autoComplete={'off'} placeholder="请输入油卡卡号" allowClear />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <DataTable
        title="公司加油对账数据列表"
        className={'full-table'}
        rowKeyIndex={'resourceId'}
        rowKey={() => Random.guid()}
        api={API.fuelFee.companyReconciliationDetailPageList.request}
        query={listQuery}
        dataFormat={(res) => ({
          rows: res.data,
          total: res.count,
        })}
        formFormat={(data) => {
          const where: any = { 
            ...data,
            companyId: location?.state?.companyId,
            cardType: location?.state?.petrolCardType,
            stationSource: location?.state?.stationSource,
            stationName: location?.state?.stationName,
            dateTime: location?.state?.dateTime,
          }
          delete where.page
          delete where.rows
          const params: any = {
            where: { ...where},
            curPage: data.page,
            pageSize: data.rows,
          };
          return params;
        }}
      >
        <DataColumn title="加油日期" dataIndex="dateTime" />
        <DataColumn title="加油站" dataIndex="stationName" />
        <DataColumn title="部门" dataIndex="deptName" />
        <DataColumn title="加油订单号" dataIndex="orderSerialNo" />
        <DataColumn title="油卡卡号" dataIndex="petrolCardNum" />
        <DataColumn title="车牌号" dataIndex="vehicleNum" />
        <DataColumn title="驾驶员" dataIndex="driverName" />
        <DataColumn title="加油型号" dataIndex="petrolNames" />
        <DataColumn title="油卡类型" dataIndex="cardTypeName" />
        
        <DataColumn title="退款金额" dataIndex="refundTotalPrice" render={(item) => item ? yuan(item) : '-' } />
        <DataColumn title="退款时间" dataIndex="refundFinishedTime" render={(item) => item ? item : '-' } />
        <DataColumn title="对账金额" dataIndex="billMoney" render={(item) => yuan(item)} />

        <DataColumn title="加油量（升）" dataIndex="petrolCount" render={(t) => ml2litre(t)} />
        <DataColumn title="加油金额/抵扣运费（元）" dataIndex="actTotalPrice" width={180} render={(item) => yuan(item)} />
        <DataColumn title="加油员" dataIndex="stationEmpName" />
      </DataTable>
    </DetailWrapper>
  );
};

export default CompanyBillForm;
