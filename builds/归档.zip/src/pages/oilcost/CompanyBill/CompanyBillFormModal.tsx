import React, { useEffect, useState, useMemo } from "react";
import { Modal, Form, Input, notification, Select } from "antd";
import _ from "lodash";
import { MLModal, useHistory } from "@cyber-ccx/lib";
import Rules from "@/utils/rules";

const { Option } = Select;
const FormItem = Form.Item;

interface CompanyBillFormModalProps extends MLModal.FormModalComponent {}

const CompanyBillFormModal: React.FC<CompanyBillFormModalProps> = ({
  query,
  ...props
}) => {
  const { modal } = props;
  const isNew = !modal.params;
  const params = modal.params;
  const history = useHistory();
  const [loading, setLoading] = useState(false);
  const [form] = Form.useForm();

  useEffect(() => {
    if (modal.isShow) {
      loadDetail();
    }
    if (modal.isShow && !isNew) {
      form.setFieldsValue(params.item);
    } else {
      form.resetFields();
    }
  }, [modal.isShow]);

  const loadDetail = async () => {};

  const submit = async () => {};

  const cancel = () => {
    modal.close();
  };

  return (
    <Modal
      title={`${isNew ? "新增" : "修改"}资源`}
      width={600}
      visible={modal.isShow}
      onOk={submit}
      confirmLoading={loading}
      onCancel={cancel}
      className="form-page"
    >
      <Form form={form} labelCol={{ span: 7 }} wrapperCol={{ span: 12 }}>
        <FormItem label="菜单名" name="resourceName" {...Rules("required")}>
          <Input autoComplete={'off'} />
        </FormItem>
        <FormItem label="菜单图标" name="resourceIcon">
          <Input autoComplete={'off'} />
        </FormItem>
        <FormItem label="目标路径" name="routerUrl" {...Rules("required")}>
          <Input autoComplete={'off'} />
        </FormItem>
        <FormItem label="资源类型" name="type" {...Rules("required")}>
          <Select>
            <Option value={0}>菜单</Option>
            <Option value={2}>路由</Option>
          </Select>
        </FormItem>
        <FormItem
          label="序号"
          name="serialNumber"
          {...Rules("required", "number")}
        >
          <Input autoComplete={'off'} />
        </FormItem>
        <FormItem label="备注" name="resourceDesc">
          <Input autoComplete={'off'} />
        </FormItem>
      </Form>
    </Modal>
  );
};

export default CompanyBillFormModal;
