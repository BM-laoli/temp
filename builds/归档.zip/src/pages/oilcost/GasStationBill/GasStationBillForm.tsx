import React, { useEffect, useState, useMemo } from 'react';
import { Modal, Form, Input, notification, Select, Card, Button, Col, Row, Table, DatePicker } from 'antd';
import _ from 'lodash';
import { RouteChildrenProps, useLocation } from 'react-router-dom';
import DetailWrapper from '@/components/DetailWrapper';
import { DataColumn, DataTable, SearchForm,useFormModal, useHistory, useQuery, useSearchForm } from '@/components/table-wy';
import CardTypeSelect from '@/components/CardTypeSelect';
import { PageBlock } from '@/components/PageWrapper';
import CompanySelect from '@/components/CompanySelect';
import OilSelect from '@/components/OilSelect';
import { Random } from 'mockjs';
import { yuan, ml2litre } from '@/utils';
import ExportButton from '@/components/ExportButton';
import GasStationBillFormModal from './GasStationBillFormModal';

const { Option } = Select;
const FormItem = Form.Item;
const RangePicker = DatePicker.RangePicker;

interface GasStationBillFormProps extends RouteChildrenProps {
}

const GasStationBillForm: React.FC<GasStationBillFormProps> = ({ ...props }) => {
  const [loading, setLoading] = useState(false);
  const searchFrom = useSearchForm();
  const listQuery = useQuery();
  const location = useLocation<any>();
  const modal = useFormModal();
  
  const [dataSource, setDataSource] = useState<defs.TheReconciliationSubsidiaryEntities[]>([]);
  const [cashData, setCashData] = useState<any>();
  const btns = [
    <Button key={1} onClick={() => searchFrom.submit()}>查询</Button>,
    <ExportButton
      key={2}
      style={{ marginLeft: '15px' }}
      type={'primary'}
      query={listQuery}
      formFormat={(data) => {
        const params: any = {
          ...data,
          stationSource: location?.state?.stationSource,
          stationName: location?.state?.stationName,
          stationId: location?.state?.stationId,
          dateTime: location?.state?.dateTime,
        };
        return params;
      }}
      url="/fuel/fee/exportStationReconciliationDetail"
      title={`${location?.state?.stationName}-${location?.state?.dateTime}月份对账单`}
      children="导出"
    />,
    <Button key={3} disabled={location?.state?.stationSource !== 1} style={{ marginLeft: '15px' }} type={'primary'} onClick={() => modal.open({stationId: location?.state?.stationId, cashData: cashData})}>
      预充值
    </Button>,
    
  ];
  console.log('petrolCardType', location?.state);
  
  React.useEffect(() => {
    loadDetail(listQuery.get());
  }, [listQuery.get()]);

  const loadDetail = async (formData: any) => {
    setLoading(true);
    const [startDate, endDate] = [formData.time?.[0]?.format('YYYY-MM-DD 00:00:00'), formData.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
    const data = {
      ...formData,
      startDate,
      endDate,
      stationId: location?.state?.stationId,
      stationSource: location?.state?.stationSource,
      stationName: location?.state?.stationName,
      dateTime: location?.state?.dateTime,
    };
    const cash: API.fuelFee.findStationAccountStat.Response = await API.fuelFee.findStationAccountStat.request(data);
    if (cash.success && cash.data) {
      console.log('sssss', cash.data);
      
      setCashData(cash.data)
    }
    // const res: API.fuelFee.stationReconciliationDetail.Response = await API.fuelFee.stationReconciliationDetail.request(data);
    // if (res.success) {
    //   setDataSource(res.data || []);
    // }
    
    setLoading(false);
  };

  return (
    <DetailWrapper title={`${location?.state?.stationName} ${location?.state?.dateTime}月份对账单`}>
      {location?.state?.stationId && (
        <PageBlock style={{ borderBottom: '1px solid rgb(238, 238, 238)' }}>
          <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between'  }}>
            <div style={{ flex: 1 }}>
              <span style={{ marginLeft: 30 }}>本月预充值金额：{yuan(Number(cashData?.totalSum))}元</span>
              <span style={{ marginLeft: 30 }}>本月消费金额：{yuan(Number(cashData?.totalConsume))}元</span>
              <span style={{ marginLeft: 30 }}>本月返点金额：{yuan(Number(cashData?.actRebate))}元</span>
              <span style={{ marginLeft: 30 }}>本月结算金额：{yuan(Number(cashData?.settleMoney))}元</span>
            </div>
            <div style={{ width: 200 }}>
              <span style={{ marginLeft: 30 }}>当前余额：{yuan(Number(cashData?.remainingSum))}元</span>
            </div>
          </div>
        </PageBlock>
      )}
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="车牌号" name="vehicleNum">
                <Input autoComplete={'off'} placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="加油型号" name="petrolId">
                <OilSelect placeholder="请选择" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="油卡类型" name="cardType">
                <CardTypeSelect placeholder="请选择" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="所属公司" name="companyId">
                <CompanySelect placeholder="请选择" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="交易日期" name="time">
                <RangePicker  />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="交易类型" name="opType">
                <Select placeholder={'全部'} allowClear>
                  <Option value={0}>充值</Option>
                  <Option value={1}>消费</Option>
                  <Option value={2}>退款</Option>
                </Select>
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <DataTable
        className={'full-table'}
        rowKeyIndex={'resourceId'}
        rowKey={() => Random.guid()}
        api={API.fuelFee.stationReconciliationDetailPageList.request}
        query={listQuery}
        dataFormat={(res) => ({
          rows: res.data,
          total: res.count,
        })}
        formFormat={(data) => {
          const [startDate, endDate] = [data.time?.[0]?.format('YYYY-MM-DD 00:00:00'), data.time?.[1]?.format('YYYY-MM-DD 23:59:59')];
          const where: any = {
            startDate,
            endDate,
            stationId: location?.state?.stationId,
            stationSource: location?.state?.stationSource,
            stationName: location?.state?.stationName,
            dateTime: location?.state?.dateTime,
            ...data,
          };
          delete where.page
          delete where.rows
          delete where.time
          const params: any = {
            where,
            curPage: data.page,
            pageSize: data.rows,
          };
          return params;
        }}
      >
        <DataColumn title="交易日期" dataIndex="dateTime" />
        <DataColumn title="所属公司" dataIndex="companyName" />
        <DataColumn title="车牌号" dataIndex="vehicleNum" />
        <DataColumn title="驾驶员" dataIndex="driverName" />
        <DataColumn title="加油型号" dataIndex="petrolNames" />
        <DataColumn title="油卡类型" dataIndex="cardTypeName" />
        <DataColumn title="加油量（升）" dataIndex="petrolCount" render={(t) =>  t ? ml2litre(t) : '-' } />
        <DataColumn title="交易类型" dataIndex="opTypeDesc" />
        <DataColumn title="加油金额/抵扣运费（元）" dataIndex="actTotalPrice" width={180} render={(item) => item ? yuan(item) : '-' } />
        <DataColumn title="加油员" dataIndex="stationEmpName" />
        <DataColumn title="退款金额" dataIndex="refundTotalPrice" render={(item) => item ? yuan(item) : '-' } />
        <DataColumn title="退款时间" dataIndex="refundFinishedTime" render={(item) => item ? item : '-' } />
        <DataColumn title="对账金额" dataIndex="billMoney" render={(item) =>yuan(item)} />
        <DataColumn title="返点金额" dataIndex="actRebate" render={(item) => item ? yuan(item) : '-' } />
        <DataColumn title="结算金额" dataIndex="settleMoney" render={(item) => item ? yuan(item) : '-' } />
        <DataColumn title="备注" dataIndex='remark' />
        <DataColumn title="操作员" dataIndex="operatorName" />
      </DataTable>
      {/* <Table dataSource={dataSource} rowKey={() => Random.guid()} loading={loading} pagination={false} size="small" tableLayout="fixed" bordered>
        <Table.Column title="交易日期" dataIndex="dateTime" />
        <Table.Column title="所属公司" dataIndex="companyName" />
        <Table.Column title="车牌号" dataIndex="vehicleNum" />
        <Table.Column title="驾驶员" dataIndex="driverName" />
        <Table.Column title="加油型号" dataIndex="petrolNames" />
        <Table.Column title="油卡类型" dataIndex="cardTypeName" />
        <Table.Column title="加油量（升）" dataIndex="petrolCount" render={(t) =>  t ? ml2litre(t) : '-' } />
        <Table.Column title="交易类型" dataIndex="opTypeDesc" />
        <Table.Column title="加油金额/抵扣运费（元）" dataIndex="actTotalPrice" width={180} render={(item) => item ? yuan(item) : '-' } />
        <Table.Column title="加油员" dataIndex="stationEmpName" />
        <Table.Column title="返点金额" dataIndex="actRebate" render={(item) => item ? yuan(item) : '-' } />
        <Table.Column title="结算金额" dataIndex="settleMoney" render={(item) => item ? yuan(item) : '-' } />
        <Table.Column title="操作员" dataIndex="operatorName" />
      </Table> */}
      <GasStationBillFormModal modal={modal} query={listQuery} />

    </DetailWrapper>
  );
};

export default GasStationBillForm;
