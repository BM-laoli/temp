import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "加油站对账",
    routerUrl: "/GasStationBill",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./GasStationBill")),
    children: [
      {
        needLogin: true,
        resourceName: "对账单",
        routerUrl: "/GasStationBillForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./GasStationBillForm")),
      },
      //$MORE$
    ],
  },
];
