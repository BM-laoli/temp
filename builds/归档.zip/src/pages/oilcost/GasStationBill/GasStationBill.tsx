import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import GasStationBillFormModal from './GasStationBillFormModal';
import StationSourceSelect from '@/components/StationSourceSelect';
import CardTypeSelect from '@/components/CardTypeSelect';
import GasStationSelect from '@/components/GasStationSelect';
import { Random } from 'mockjs';
import ExportButton from '@/components/ExportButton';
import moment from 'moment';
const Option = Select.Option;
const RangePicker = DatePicker.RangePicker;

interface GasStationBillProps extends RouteChildrenProps {}

const GasStationBill: React.FC<GasStationBillProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const modal = useFormModal();
  const listQuery = useQuery();
  const btns = [
    <Button key={1} onClick={() => searchFrom.submit()}>查询</Button>,
    <ExportButton
      key={2}
      style={{ marginLeft: '15px' }}
      type={'primary'}
      query={listQuery}
      formFormat={(data) => {
        const where: any = { };
        if (data.time) {
          where.year = data.time.year();
          where.month = data.time?.month() + 1;
        } else {
          data.time = moment(new Date().toLocaleDateString(), 'YYYY-MM')
          where.year = data.time.year();
          where.month = data.time?.month() + 1;
        }
        const params: any = { ...where, ...data  };
        return params;
      }}
      url="/fuel/fee/exportStationReconciliationDetail"///fuel/fee/exportStationReconciliation
      title="加油站对账"
      children="导出"
    />,
    // <Button style={{ marginLeft: '15px' }} type={'primary'} onClick={() => history.push('GasStationBill/GasStationBillForm')}>
    //   新增
    // </Button>,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={6}>
              <Form.Item label="对账月份" name="time">
                <DatePicker picker="month" placeholder="请选择" allowClear defaultValue={moment(new Date().toLocaleDateString(), 'YYYY-MM')} style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="油站名称" name="stationName">
                <Input placeholder="请输入油站名称关键字"  allowClear />
                {/* <GasStationSelect placeholder="请输入油站名称关键字" allowClear /> */}
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="适用油卡" name="cardType">
                <CardTypeSelect placeholder="请选择适用油卡" allowClear />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="加油站来源" name="stationSource">
                <StationSourceSelect placeholder="请选择加油站来源" allowClear />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
          title="数据列表"
          className={'full-table'}
          rowKeyIndex={'resourceId'}
          rowKey={() => Random.guid()}
          api={API.fuelFee.stationReconciliationPageList.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const where: any = {};
            if (data.time) {
              where.year = data.time.year();
              where.month = data.time?.month() + 1;
            } else {
              data.time = moment(new Date().toLocaleDateString(), 'YYYY-MM')
              where.year = data.time.year();
              where.month = data.time?.month() + 1;
            }
            const params: any = {
              where: { ...where, ...data, },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
        >
          <DataColumn title="对账月份" dataIndex="dateTime" />
          <DataColumn title="加油站来源" dataIndex="stationSourceDesc" />
          <DataColumn title="油站名称" dataIndex="stationName" />
          <DataColumn title="适用油卡" dataIndex="cardTypeName" />
          <DataColumn title="加油型号" dataIndex="petrolNames" />
          <DataColumn
            title="操作"
            fixed="right"
            width={220}
            render={(item) => {
              return (
                <>
                  <Button size="small" onClick={() => history.push(`GasStationBill/GasStationBillForm`, { ...item })}>
                    对账单
                  </Button>
                </>
              );
            }}
          />
        </DataTable>
      </div>
    </PageWrapper>
  );
};

export default GasStationBill;
