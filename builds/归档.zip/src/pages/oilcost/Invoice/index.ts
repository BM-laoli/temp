import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "开票管理",
    routerUrl: "/Invoice",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./Invoice")),
    children: [
      {
        needLogin: true,
        resourceName: "开票明细",
        routerUrl: "/InvoiceForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./InvoiceForm")),
      },
      //$MORE$
    ],
  },
];
