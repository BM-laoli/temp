import loadable from "@loadable/component";
//$IMPORT$

export default () => [
  {
    needLogin: true,
    resourceName: "加油总览",
    routerUrl: "/Overview",
    resourceIcon: "TeamOutlined",
    type: "0",
    buttons: [],
    noparent: true,
    component: loadable(() => import("./Overview")),
    children: [
      {
        needLogin: true,
        resourceName: "新增Overview",
        routerUrl: "/OverviewForm",
        resourceIcon: "",
        type: "2",
        buttons: [],
        component: loadable(() => import("./OverviewForm")),
      },
      //$MORE$
    ],
  },
];
