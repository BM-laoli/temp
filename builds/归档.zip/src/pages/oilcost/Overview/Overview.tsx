import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag, Card, Statistic, Space, Typography, Empty } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import { ArrowUpOutlined, ArrowDownOutlined } from '@ant-design/icons';
import * as echarts from 'echarts';
import { LineSeriesOption } from 'echarts/charts';

interface OverviewProps extends RouteChildrenProps { }

const Overview: React.FC<OverviewProps> = (props) => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<defs.ComeOnTheOverviewScreenObjects>();

  const chart1 = useRef<echarts.ECharts>();
  const chart1element = useRef<HTMLDivElement>(null);
  const chart2 = useRef<echarts.ECharts>();
  const chart2element = useRef<HTMLDivElement>(null);
  const chart3 = useRef<echarts.ECharts>();
  const chart3element = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chart1element.current) chart1.current = echarts.init?.(chart1element.current);
    if (chart2element.current) chart2.current = echarts.init?.(chart2element.current);
    if (chart3element.current) chart3.current = echarts.init?.(chart3element.current);

    loadData();

    return () => {
      chart1.current?.dispose();
      chart2.current?.dispose();
      chart3.current?.dispose();
    };
  }, []);

  useEffect(() => {
    if (!!data) {
      d1();
      d2();
      d3();
    }
  }, [data]);

  const loadData = async () => {
    setLoading(true);
    const res: API.fuelFee.getChartData.Response = await API.fuelFee.getChartData.request({});
    if (res.success) {
      setData(res.data);
    }
    setLoading(false);
  };

  const d1 = () => {
    const charData = data?.chartLineDto as any;
    const series = charData?.yline?.map((v) => {
      const datas = v.data?.map(child => {
        return child = child ? child : 0
      })
      return {
        name: v.name,
        type: 'line',
        stack: 'Total',
        data: datas,
        areaStyle: {},
        emphasis: { focus: 'series' }
      }
    }) || [];
    console.log(series, 3332);
    const option = {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'cross',
          label: {
            backgroundColor: '#6a7985'
          }
        }
      },
      legend: {
        data: charData?.xline?.map((v) => v.name) || [],
      },
      grid: { left: '5%', right: '5%', bottom: '5%', containLabel: true },
      xAxis: [
        {
          type: 'category',
          boundaryGap: false,
          data: charData?.xline || [],
        },
      ],
      yAxis: {
        type: 'value',
        axisLabel: { formatter: '{value}L' },
      },
      series: series,
    };

    chart1.current?.setOption(option);
  };

  const d2 = () => {
    const chartData = data?.chartBarDto;
    const option = {
      tooltip: { trigger: 'axis' },
      xAxis: {
        type: 'category',
        data: chartData?.xline || [],
      },
      yAxis: {
        type: 'value',
        axisLabel: { formatter: '{value}L' },
      },
      grid: { left: '5%', right: '5%', bottom: '5%', containLabel: true },
      series: [
        {
          type: 'bar',
          data: chartData?.yline || [],
          barWidth: 50,
        },
      ],
    };
    chart2.current?.setOption(option);
  };

  const d3 = () => {
    const chartData = data?.chartLineSingleDto;
    const option = {
      tooltip: { trigger: 'axis' },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: chartData?.xline || [],
      },
      yAxis: {
        type: 'value',
        axisLabel: { formatter: '{value}L' },
      },
      grid: { left: '5%', right: '5%', bottom: '5%', containLabel: true },
      series: [
        {
          data: chartData?.yline || [],
          type: 'line',
        },
      ],
    };
    chart3.current?.setOption(option);
  };

  return (
    <PageWrapper className="list-page">
      <PageBlock>
        <Row gutter={16}>
          <Col span={8}>
            <div className='moneyStatisticWrap'>
              <div className='ms' style={{ width: '100%' }}>
                <div className='moneyStatistic'>{data?.companyHeadVo?.countNum ?? 0}</div>
                <div className='moneyTitle'>合作公司数</div>
              </div>
            </div>
          </Col>
          <Col span={8}>
            <div className='moneyStatisticWrap'>
              <div className='ms' style={{ width: '100%' }}>
                <div className='moneyStatistic'>{data?.stationHeadVo?.countNum ?? 0}</div>
                <div className='moneyTitle'>合作加油站数</div>
              </div>
            </div>
          </Col>
          <Col span={8}>
            <div className='moneyStatisticWrap'>
              <div className='ms' style={{ width: '100%' }}>
                <div className='moneyStatistic'>{`${data?.fuelChargeHeadVo?.countNum ?? 0}L`}</div>
                <div className='moneyTitle'>累计加油量</div>
              </div>
            </div>
          </Col>
          {/* <Col span={8}>
            <div style={{ width: '100%', height: 190, padding: 5, display: 'flex', border: '1px solid #f0f0f0', background: '#fff' }}>
              <div style={{ width: 142, background: '#D25141', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <Typography.Title level={5} style={{ color: '#fff', marginBottom: 30 }} children="合作公司数" />
                <img src={require('@/assets/images/Overview/01company.png')} style={{ width: 70, height: 77 }} />
              </div>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <Typography.Title style={{ fontSize: 90, margin: 0 }} children={data?.companyHeadVo?.countNum ?? 0} />
              </div>
            </div>
          </Col>
          <Col span={8}>
            <div style={{ width: '100%', height: 190, padding: 5, display: 'flex', border: '1px solid #f0f0f0', background: '#fff' }}>
              <div style={{ width: 142, background: '#DAA759', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <Typography.Title level={5} style={{ color: '#fff', marginBottom: 40 }} children="合作加油站数" />
                <img src={require('@/assets/images/Overview/02gas.png')} style={{ width: 70, height: 60 }} />
              </div>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <Typography.Title style={{ fontSize: 90, margin: 0 }} children={data?.stationHeadVo?.countNum ?? 0} />

              </div>
            </div>
          </Col>
          <Col span={8}>
            <div style={{ width: '100%', height: 190, padding: 5, display: 'flex', border: '1px solid #f0f0f0', background: '#fff' }}>
              <div style={{ width: 142, background: '#F9C498', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <Typography.Title level={5} style={{ color: '#fff', marginBottom: 30 }} children="累计加油量" />
                <img src={require('@/assets/images/Overview/03calculator.png')} style={{ width: 60, height: 70 }} />
              </div>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <Typography.Title style={{ fontSize: 90, margin: 0 }} children={`${data?.fuelChargeHeadVo?.countNum ?? 0}L`} />
              
              </div>
            </div>
          </Col> */}
        </Row>

        <Card title="加油总量排名前10的公司" size="small" style={{ marginTop: 16 }}>
          {!data?.chartLineDto?.yline?.length && (
            <div style={{ position: 'absolute', width: '100%', height: '100%', left: 0, top: 0, background: '#fff', zIndex: 999 }}>
              <Empty description={false} imageStyle={{ height: 'auto' }} image={<img src={require('@/assets/images/Overview/pic_abnormal_no data_02.png')} style={{ width: 1010, height: 486 }} />} />
            </div>
          )}
          <div ref={chart1element} style={{ height: 400 }} />
        </Card>

        <Row gutter={16} style={{ marginTop: 16 }}>
          <Col span={12}>
            <Card title="加油总量排名前10的加油站" size="small">
              <div ref={chart2element} style={{ height: 400 }} />
            </Card>
          </Col>
          <Col span={12}>
            <Card title="最近6个月加油总量" size="small">
              <div ref={chart3element} style={{ height: 400 }} />
            </Card>
          </Col>
        </Row>
      </PageBlock>
    </PageWrapper>
  );
};

export default Overview;
