import React, { useState, useEffect, useRef } from 'react';
import { observer } from 'mobx-react-lite';
import _ from 'lodash';
import { RouteChildrenProps } from 'react-router-dom';
import { Button, DatePicker, Input, Form, Row, Col, Select, Tag } from 'antd';
import PageWrapper, { PageBlock } from '@/components/PageWrapper';
import {useSearchForm, DataTable, DataColumn, MLModal,useFormModal, useHistory, SearchForm,useQuery} from "@/components/table-wy";
import { Random } from 'mockjs';
import ExportButton from '@/components/ExportButton';
import GasStationSelect from '@/components/GasStationSelect';
import moment from 'moment';

interface QiaoBillProps extends RouteChildrenProps {}

const QiaoBill: React.FC<QiaoBillProps> = (props) => {
  const history = useHistory();
  const searchFrom = useSearchForm();
  const listQuery = useQuery();
  const btns = [
    <Button key={1} onClick={() => searchFrom.submit()}>查询</Button>,
    <ExportButton
      style={{ marginLeft: '15px' }}
      key={2}
      type={'primary'}
      query={listQuery}
      formFormat={(data) => {
        const where: any = {};
        if (data.time) {
          where.year = data.time.year();
          where.month = data.time?.month() + 1;
        } else {
          data.time = moment(new Date().toLocaleDateString(), 'YYYY-MM')
          where.year = data.time.year();
          where.month = data.time?.month() + 1;
        }
        const params: any = { ...where, stationId: data.stationId, deviceCode: data.deviceCode };
        return params;
      }}
      url="/fuel/fee/exportRefuelingSkidReconciliation"
      title="加油撬对账"
      children="导出"
    />,
  ];

  return (
    <PageWrapper className="list-page">
      <PageBlock className={'search-form'}>
        <SearchForm formControl={searchFrom} query={listQuery} btns={btns}>
          <Row gutter={[16, 0]}>
            <Col span={8}>
              <Form.Item label="对账月份" name="time">
                <DatePicker picker="month" placeholder="请选择" allowClear defaultValue={moment(new Date().toLocaleDateString(), 'YYYY-MM')} style={{ width: '100%' }} />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="所属油站" name="stationId">
                <GasStationSelect placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item label="加油撬编号" name="deviceCode">
                <Input autoComplete={'off'} placeholder="请输入关键字" allowClear />
              </Form.Item>
            </Col>
          </Row>
        </SearchForm>
      </PageBlock>
      <div className="list-content">
        <DataTable
           
          className={'full-table'}
          rowKeyIndex={'resourceId'}
          rowKey={() => Random.guid()}
          api={API.fuelFee.refuelingSkidReconciliationPageList.request}
          query={listQuery}
          dataFormat={(res) => ({
            rows: res.data,
            total: res.count,
          })}
          formFormat={(data) => {
            const where: any = {};
            if (data.time) {
              where.year = data.time.year();
              where.month = data.time?.month() + 1;
            } else {
              data.time = moment(new Date().toLocaleDateString(), 'YYYY-MM')
              where.year = data.time.year();
              where.month = data.time?.month() + 1;
            }
            const params: any = {
              where: { ...where, stationId: data.stationId, deviceCode: data.deviceCode },
              curPage: data.page,
              pageSize: data.rows,
            };
            return params;
          }}
        >
          <DataColumn title="对账月份" dataIndex="dateTime" />
          <DataColumn title="所属油站" dataIndex="stationName" />
          <DataColumn title="加油撬编号" dataIndex="deviceCode" />
          <DataColumn title="加油型号" dataIndex="petrolNames" />
          <DataColumn
            title="操作"
            fixed="right"
            width={220}
            render={(item) => {
              return (
                <>
                  <Button size="small" onClick={() => history.push(`QiaoBill/QiaoBillForm`, { ...item })}>
                    对账单
                  </Button>
                </>
              );
            }}
          />
        </DataTable>
      </div>
    </PageWrapper>
  );
};

export default QiaoBill;
