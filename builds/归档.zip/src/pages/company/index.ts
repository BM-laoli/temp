import Info from "./Info";
import Cars from "./Cars";
import Driver from "./Driver";
import Card from "./Card";
import AssociationSet from "./AssociationSet"; //$IMPORT$

export default () => [
  {
    resourceName: "合作公司",
    routerUrl: "/company",
    resourceIcon: "",
    type: "0",
    buttons: [],
    children: [
      Info(),
      Cars(),
      Driver(),
      Card(),
      AssociationSet(), //$MORE$
    ],
  },
];
