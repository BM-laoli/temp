import loadable from '@loadable/component';

export default () => [
  {
    needLogin: false,
    resourceName: '/Help',
    routerUrl: '/Help',
    resourceIcon: 'TeamOutlined',
    type: '0',
    buttons: [],
    noparent: true,
    component: loadable(() => import('./Help')),
    children: [
      //$MORE$
    ],
  },
];
