/*
 * @Author: TigerLord
 * @Date: 2022-09-06 15:28:29
 * @LastEditTime: 2022-10-20 11:35:37
 * @LastEditors: your name
 * @Description: 功能说明：——
 * @FilePath: /ytzx-console/src/pages/h5/Agreement/Agreement.tsx
 */
import React, { useState } from 'react';
import useQuery from '@/utils/hooks/useQuery';

import './style.less';

const DownloadCard: React.FC = () => {
  const { t } = useQuery<{ t: any }>();
  const [data, setData] = useState<defs.SysConfigEntity>();

  React.useEffect(() => {
    const ary = ['云途油卡用户章程', '云途加油用户章程', '云途油卡隐私条款', '云途加油隐私条款', '云途油卡帮助中心', '云途加油帮助中心'];
    const type = Number(t);
    document.title = ary[type] || '';

    init()
  }, []);

  const init = async () => {
    await loadData();
    (window as any)?.ReactNativeWebView?.postMessage?.('success')
  }

  const loadData = async () => {
    const sysConfigType = Number(t);
    const res = await API.dictionary.findBySysConfigType.request({ sysConfigType });
    if (res.success) {
      setData(res.data);
    }
  };

  return (
    <div className="wrapper">
      <div className="content" dangerouslySetInnerHTML={{ __html: data?.textArea || '' }}></div>
    </div>
  );
};

export default DownloadCard;
