import loadable from '@loadable/component';
//$IMPORT$

export default () => [
  {
    needLogin: false,
    resourceName: 'Agreement',
    routerUrl: '/Agreement',
    resourceIcon: 'TeamOutlined',
    type: '0',
    buttons: [],
    noparent: true,
    component: loadable(() => import('./Agreement')),
    children: [
      //$MORE$
    ],
  },
];
