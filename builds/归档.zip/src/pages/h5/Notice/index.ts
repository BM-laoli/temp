import loadable from '@loadable/component';

export default () => [
  {
    needLogin: false,
    resourceName: '/Notice',
    routerUrl: '/Notice',
    resourceIcon: 'TeamOutlined',
    type: '0',
    buttons: [],
    noparent: true,
    component: loadable(() => import('./Notice')),
    children: [
      //$MORE$
    ],
  },
];
