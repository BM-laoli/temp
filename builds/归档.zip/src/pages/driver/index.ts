import League from "./League";
import Audit from "./Audit"; //$IMPORT$

export default () => [
  {
    resourceName: "司机加盟",
    routerUrl: "/driver",
    resourceIcon: "",
    type: "0",
    buttons: [],
    children: [
      League(),
      Audit(), //$MORE$
    ],
  },
];
