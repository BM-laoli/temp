import Motorcade from "./Motorcade";
import Yuntu from "./Yuntu";
import Wanjinyou from "./Wanjinyou";
import Overview from "./Overview";
import Entity from "./Entity"; //$IMPORT$

export default () => [
  {
    resourceName: "油卡管理",
    routerUrl: "/electron",
    resourceIcon: "",
    type: "0",
    buttons: [],
    children: [
      Overview(),
      Motorcade(),
      Yuntu(),
      Entity(), //$MORE$
      Wanjinyou(),
      
    ],
  },
];
