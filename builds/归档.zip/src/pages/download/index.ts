import card from "./card";
import refuel from "./refuel"; //$IMPORT$

export default () => [
  {
    resourceName: "download",
    routerUrl: "/download",
    resourceIcon: "",
    type: "0",
    buttons: [],
    children: [
      card(),
      refuel(), //$MORE$
    ],
  },
];
