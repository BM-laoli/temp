import moment from 'moment';

export const per = (n: number) => {
  return `${(n * 100).toFixed(2)}%`;
};

export const per1000 = (n: number) => {
  return `${(n / 1000).toFixed(2)}‰`;
};

export const price = (n = 0) => {
  return n.toFixed(2);
};

export const yuan = (n: string | number = 0) => {
  const num = Number(n);
  return price(num / 100);
};

/** 毫升转升 */
export const ml2litre = (val: string | number = 0,row?:any,index?:number, fixed: number = 2) => {
  const n = Number(val) || 0;
  return (n / 1000).toFixed(fixed);
};

export const time = (n: any) => (n ? moment(n).format('YYYY-MM-DD HH:mm:ss') : '');

export const addThousandSeprator = (strOrNum) => {
  return parseFloat(strOrNum).toFixed(2).toString().split('.').map((x,idx) => {
      if(!idx) {
          return x.split('')
                  .reverse()
                  .map((xx,idxx) => (idxx && !(idxx % 3)) ? (xx + ',') : xx )
                  .reverse()
                  .join('')
      } else {
          return x;
      }
  }).join('.')
}