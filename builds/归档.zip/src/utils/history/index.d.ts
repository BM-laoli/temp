import { History } from 'history';
export interface AGHistory extends History {
    /**
     * 得到url的参数
     */
    getQuery: () => {
        [k: string]: string;
    };
    /**
     * 增量设置url的参数，如果参数和当前参数一致不会触发设置
     * @param data
     * @param isRef 是否强制刷新，查询条件不变也会触发刷新
     * @param isRemove 是否删除空值字段
     */
    setQuery: (data: any, isRef?: boolean, isRemove?: boolean) => void;
    /**
     * 专用于刷新table，清除查询条件，只保留每页条数，重置页码到1页
     */
    refTable: () => void;
    serialization: (form: any, isRemove?: boolean) => string;
}
declare let init: (basename?: string) => void;
declare const aghistory: AGHistory;
export default aghistory;
export { init };
export declare const useHistory: () => AGHistory;
