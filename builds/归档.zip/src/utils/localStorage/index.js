const storage = window.localStorage;
class LocalStorage {
    /** 设置键值，该方法是异步 */
    static set(k, v) {
        let _v = v ? JSON.stringify(v) : "";
        return storage.setItem(k, _v);
    }
    /** 获取值，该方法是异步 */
    static get(k) {
        let _v = storage.getItem(k);
        return _v ? JSON.parse(_v) : null;
    }
    static remove(k) {
        return storage.removeItem(k);
    }
}
export default LocalStorage;
