import OSS from 'ali-oss';
let _ossclient = null;
export default {
    /**
     * 初始化oss设置
     * @param config
     */
    init(config) {
        _ossclient = new OSS(config);
    },
    /**
     * 上传文件
     * @param path
     * @param file
     */
    upload(path, file) {
        if (_ossclient === null) {
            throw new Error('请先调用init方法初始化OSS设置');
        }
        return _ossclient.put(path, file, { headers: {
                'Content-Disposition': 'attachment'
            } });
    }
};
